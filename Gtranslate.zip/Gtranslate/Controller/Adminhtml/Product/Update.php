<?php
namespace Ced\Gtranslate\Controller\Adminhtml\Product;

use Magento\Framework\Controller\ResultFactory;

class Update extends \Magento\Backend\App\Action
{
    public function __construct(
        \Magento\Backend\App\Action\Context $context
    ) {
        parent::__construct($context);
    }

    public function execute()
    {

    }
}
