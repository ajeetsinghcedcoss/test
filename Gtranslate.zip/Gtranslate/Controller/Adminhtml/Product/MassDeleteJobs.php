<?php
namespace Ced\Gtranslate\Controller\Adminhtml\Product;

use Magento\Framework\Controller\ResultFactory;

class MassDeleteJobs extends \Magento\Backend\App\Action
{
    public function __construct(
        \Magento\Backend\App\Action\Context $context
    ) {
        parent::__construct($context);
    }

    public function execute()
    {
        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $model = $this->_objectManager->create('Ced\Gtranslate\Model\CronScheduler');
        $connection = $model->getCollection()->getConnection();
        $tableName = $model->getCollection()->getMainTable();
        $connection->truncateTable($tableName);
        $this->messageManager->addSuccessMessage(' Cron Scheduler Entries Truncated');
        $this->_redirect('gtranslate/cron/jobs');
        return;
    }
}
