<?php
namespace Ced\Gtranslate\Controller\Adminhtml\Product;

class index extends \Magento\Backend\App\Action
{
    public $resultPageFactory;

    public $bulk_upload_batch = 10;

    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory
    ) {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
    }

    public function execute()
    {

        //$this->_objectManager->create('Ced\Gtranslate\Cron\UpdateInventoryPrice')->execute();
        $this->_initAction()->_setActiveMenu(
            'Ced_Gtranslate::gtranslate'
        )->_addBreadcrumb(
            __('Gtranslate Product'),
            __('Gtranslate Product')
        );
        $this->_view->getPage()->getConfig()->getTitle()->prepend(__('Gtranslate Product'));
        $this->_view->renderLayout();
    }
    public function _initAction()
    {
        $this->_view->loadLayout();
        $this->_addBreadcrumb(__('Gtranslate Product'), __('Gtranslate Product'));
        return $this;
    }
}
