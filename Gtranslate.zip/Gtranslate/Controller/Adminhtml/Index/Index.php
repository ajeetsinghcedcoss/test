<?php

namespace Ced\Gtranslate\Controller\Adminhtml\Index;

class Index extends \Magento\Backend\App\Action
{
    public function execute()
    {

        /** @var \Magento\Framework\Controller\Result\Raw $result */
        $this->_initAction()->_setActiveMenu(
            'Ced_Gtranslate::gtranslate'
        )->_addBreadcrumb(
            __('Import Product'),
            __('Import Product')
        );
        $this->_view->getPage()->getConfig()->getTitle()->prepend(__('Import Product'));
        $this->_view->renderLayout();
    }

    public function _initAction()
    {
        $this->_view->loadLayout();
        $this->_addBreadcrumb(__('Import Product'), __('Import Product'));
        $this->_addBreadcrumb(__('Import Product'), __('Import Product'));
        return $this;
    }
}
