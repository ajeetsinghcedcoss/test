<?php

namespace Ced\Gtranslate\Controller\Adminhtml\Index;


class Ajaxfileimport extends \Magento\Backend\App\Action
{
    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    public $resultPageFactory;

    public $resultJsonFactory;

    public $dataHelper;

    public $registry;

    public $session;


    public $directoryList;
    public $filesystem;
    public $file;
    public $csv;


    /**
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
        \Ced\Gtranslate\Helper\Data $data,
        \Magento\Framework\App\Filesystem\DirectoryList $directoryList,
        \Magento\Framework\Filesystem $filesystem,
        \Magento\Framework\Filesystem\Io\File $file,
        \Magento\Framework\File\Csv $csv,
        \Magento\Framework\Registry $registry

    ) {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
        $this->resultJsonFactory = $resultJsonFactory;
        $this->dataHelper = $data;
        $this->registry = $registry;
        $this->session = $context->getSession();
        $this->directoryList = $directoryList;
        $this->filesystem = $filesystem;
        $this->file = $file;
        $this->csv = $csv;


    }

    /**
     * @return string
     */
    public function execute()
    {
        $resultJson = $this->resultJsonFactory->create();
        $postData = $this->getRequest()->getParams();

        if(isset($postData['index'])) {
            $result = $this->_objectManager->create('Magento\Backend\Model\Session')->getGtranslateSyncProducts();


            if(is_array($result['page']['products'])){
                foreach ($result['page']['products'][$postData['index']] as $products ){
                    $responseData[] = $this->dataHelper->processRequest(null,$products);
                }
            } else {
                $responseData = $this->dataHelper->processRequest($postData['index'],$result['result']);
            }
            if (isset($responseData['success'])) {
                $response = [
                    'success' => $responseData['success'] ,
                    'msg' =>
                        isset($responseData['msg']) ?
                            $responseData['msg'] : $responseData['success']
                ];
            }
            if (isset($responseData['error'])) {
                $response = [
                    'success'=> $responseData['error'],
                    'msg' => isset($responseData['msg']) ?
                        $responseData['msg'] : $responseData['error']
                ];
            }
            if($responseData[0]){
                foreach ($responseData as $key => $value){
                    if (isset($value['success'])) {
                        $response = [
                            'success' => $value['success'] ,
                            'msg' =>
                                isset($value['msg']) ?
                                    $value['msg'] : $value['success']
                        ];
                    }
                    if (isset($value['success'])) {
                        $response = [
                            'success' => $value['success'] ,
                            'msg' =>
                                isset($value['msg']) ?
                                    $value['msg'] : $value['success']
                        ];
                    }
                }
            }
            return $resultJson->setData($response);
        }


        $result = array();
        if($this->getRequest()->getParam('file') !== null && $_FILES !== null){
            $path = $_FILES['keyterms']['tmp_name'];
            $data = $this->csv->getData($path);
            $result = $this->dataHelper->prepareProductData($data);
            if(!is_array($result)) {
                $this->messageManager->addErrorMessage('Invalid File  Exception :'. $result);
                $resultRedirect = $this->resultFactory->create('redirect');
                $resultRedirect->setUrl($this->_redirect->getRefererUrl());
                return $resultRedirect;

            }
            $page = [];
            $page['total'] = count($result);
            $page['products'] = ($result);
            $page['count'] = count($result);
            $page['products'] = array_chunk($result, 1);
            $capturer = $this->_objectManager
                ->create('Ced\Gtranslate\Model\CronScheduler');
            $capturer->setFilters(json_encode($postData));
            $capturer->setCount(json_encode($page['total']));
            $capturer->setAdditionalData(json_encode($page));
            $capturer->setStatus('Queued');
            $capturer->save();
            $result = [
                'page' => $page ,
                'result' => array_chunk($result, 1)
            ];

        }

        //$this->_objectManager->create('Magento\Backend\Model\Session')->unsAliexpressFilters()->setAliexpressFilters($searchFilters);
        $this->registry->register('productids', count($result));
        $this->session->setGtranslateSyncProducts($result);
        $resultPage = $this->resultPageFactory->create();
        $resultPage->getConfig()->getTitle()->prepend(__('Import Products'));
        return $resultPage;



    }
}
