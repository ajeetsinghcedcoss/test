<?php
/**
 * Created by PhpStorm.
 * User: cedcoss
 * Date: 6/3/18
 * Time: 7:31 PM
 */

namespace Ced\Gtranslate\Model\Source;

class ProductAttribute implements \Magento\Framework\Option\ArrayInterface
{


    /**
     * Options getter
     *
     * @return array
     */
    public function toOptionArray()
    {
        return [
            [
                'label' => 'Name',
                'value' => 'name'
            ],
            [
                'label' => 'Description',
                'value' => 'description'
            ],
            [
                'label' =>'Short Description',
                'value' =>'short_description'
            ],
            [
                'label' => 'Categories',
                'value' =>'categories'
            ],
            [
                'label' => 'attributes',
                'value' =>'attributes'
            ],
            [
                'label' => 'brand',
                'value' =>'brand'
            ]
        ];

    }
}
