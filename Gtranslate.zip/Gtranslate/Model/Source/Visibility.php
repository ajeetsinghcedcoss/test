<?php

namespace Ced\Gtranslate\Model\Source;

use Magento\Catalog\Model\Product\Attribute\Repository;

class Visibility implements \Magento\Framework\Option\ArrayInterface
{
    public $_productAttributeRepository;

    public function __construct(
        \Magento\Catalog\Model\Product\Attribute\Repository $productAttributeRepository
    ) {
        $this->_productAttributeRepository = $productAttributeRepository;
    }


    /**
     * Options getter
     *
     * @return array
     */
    public function toOptionArray()
    {
        $options = [];
        $allOptions = $this->_productAttributeRepository->get('visibility')->getOptions();
        foreach ($allOptions as $option) {
            $temp['label'] = $option->getLabel();
            $temp['value'] = $option->getValue();
            $options[] = $temp;
        }

        return array_reverse($options, true);
    }
}
