<?php
/**
 * Created by PhpStorm.
 * User: cedcoss
 * Date: 6/3/18
 * Time: 7:31 PM
 */

namespace Ced\Gtranslate\Model\Source;

class Stores implements \Magento\Framework\Option\ArrayInterface
{
    public  $_storeManager;
    public function __construct(
        \Magento\Store\Model\StoreManagerInterface $storeManager
    ) {

        $this->_storeManager = $storeManager;
    }
    /**
     * Options getter
     *
     * @return array
     */
    public function toOptionArray()
    {
        $storeManagerDataList = $this->_storeManager->getStores();
        $options = array();

        foreach ($storeManagerDataList as $key => $value) {
            $options[] = ['label' => $value['name'].' - '.$value['code'], 'value' => $key];
        }
        return $options;
    }
}
