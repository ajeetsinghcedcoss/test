<?php
/**
 * Created by PhpStorm.
 * User: cedcoss
 * Date: 6/3/18
 * Time: 7:31 PM
 */

namespace Ced\Gtranslate\Model\Source;

class Selprice implements \Magento\Framework\Option\ArrayInterface
{

    /**
     * Options getter
     *
     * @return array
     */
    public function toOptionArray()
    {
        return [
            [
                'label' => 'Default Price',
                'value' => 'final_price'
            ],
            [
                'label' =>'Increase By Fixed Price',
                'value' =>'plus_fixed'
            ],
            [
                'label' => 'Increase By Fixed Percentage',
                'value' =>'plus_per'
            ],
            [
                'label' => 'Decrease By Fixed Price',
                'value' =>'min_fixed'
            ],
            [
                'label' => 'Decrease By Fixed Percentage',
                'value' =>'min_per'
            ]/*,
            [
                'label' => 'set individually for each product',
                'value' =>'differ'
            ],*/
        ];
    }
}
