<?php
/**
 * Created by PhpStorm.
 * User: cedcoss
 * Date: 6/3/18
 * Time: 7:31 PM
 */

namespace Ced\Gtranslate\Model\Source;

class Language implements \Magento\Framework\Option\ArrayInterface
{

    /**
     * Options getter
     *
     * @return array
     */
    public function toOptionArray()
    {
        return [
            [
                'label' => 'Default (English )',
                'value' => 'english'
            ],
            [
                'label' => 'Afrikaans',
                'value' => 'af'
            ],
            [
                'label' =>'Albanian',
                'value' =>'sq'
            ],
            [
                'label' => 'Amharic',
                'value' =>'am'
            ],
            [
                'label' => 'Arabic',
                'value' =>'ar'
            ],
            [
                'label' => 'Armenian',
                'value' =>'hy'
            ],
             [
                'label' => 'Azeerbaijani',
                'value' =>'az'
            ],
             [
                'label' => 'Basque',
                'value' =>'eu'
            ],
             [
                'label' => 'Bengali',
                'value' =>'bn'
            ],
             [
                'label' => 'Bosnian',
                'value' =>'bs'
            ],
             [
                'label' => 'Bulgarian',
                'value' =>'bg'
            ],
             [
                'label' => 'Catalan',
                'value' =>'ca'
            ],
             [
                'label' => 'Cebuano',
                'value' =>'ceb'
            ],
             [
                'label' => 'Corsican',
                'value' =>'co'
            ],
             [
                'label' => 'Croatian',
                'value' =>'hr'
            ],
             [
                'label' => 'Czech',
                'value' =>'cs'
            ],
             [
                'label' => 'Danish',
                'value' =>'da'
            ],
             [
                'label' => 'Dutch',
                'value' =>'nl'
            ],
             [
                'label' => 'Esperanto',
                'value' =>'eo'
            ],
             [
                'label' => 'Finnish',
                'value' =>'fi'
            ],
            [
                'label' => 'French',
                'value' =>'fr'
            ],
            [
                'label' => 'Frisian',
                'value' =>'fy'
            ],
            [
                'label' => 'Galician',
                'value' =>'gl'
            ],
            [
                'label' => 'Georgian',
                'value' =>'ka'
            ]
        ];
    }
}
