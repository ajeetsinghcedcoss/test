<?php
namespace Ced\Gtranslate\Observer;
 
use \Psr\Log\LoggerInterface;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
 
class Predispatch implements ObserverInterface
{
    
    protected $logger;
    protected $_objectManager;
    protected $_responseFactory;
    protected $_url;
    /** @var \Magento\Framework\Message\ManagerInterface */
    protected $messageManager;
   
    public function __construct(
        LoggerInterface $logger,
        \Magento\Framework\ObjectManagerInterface $objectManager,
        \Magento\Framework\App\ResponseFactory $responseFactory,
        \Magento\Framework\UrlInterface $url,
        \Magento\Framework\Message\ManagerInterface $managerInterface
    ) {
        $this->messageManager = $managerInterface;
        $this->_responseFactory = $responseFactory;
        $this->_url = $url;
        $this->logger = $logger;
        $this->_objectManager = $objectManager;
    }
 
    public function execute(Observer $observer)
    {

        $options = $observer->getEvent()->getRequest()->getParams();
        $productId = $options['product'];

        $helper = $this->_objectManager->get('Ced\Gtranslate\Helper\Data');

        $storeId = $this->_objectManager->get('Magento\Store\Model\StoreManagerInterface')->getStore()->getId();

        $productRepository = $this->_objectManager->get('Magento\Catalog\Api\ProductRepositoryInterface');

        $product = $productRepository->getById($productId, false, $storeId);
        if ($product->getIsAliexpress() && $product->getAsin()) {
            $qty = isset($options['qty']) ? $options['qty'] : 1;
            $response = $helper->addToCart($product, $qty);
            $checkoutSession = $this->_objectManager->get('Magento\Checkout\Model\Session');
            $redirect = $this->_objectManager->get('Magento\Framework\App\Response\RedirectInterface');
            if ($response['success']) {
                $this->messageManager->addSuccess(__(
                    'You added %1 to your Aliexpress shopping cart.',
                    $product->getName()
                ));

                if (!$observer->getEvent()->getRequest()->isAjax()) {
                    $this->_responseFactory->create()->setRedirect($redirect->getRefererUrl())->sendResponse();
                } else {
                     echo '{"backUrl":"'.$redirect->getRefererUrl().'"}';
                }
            } else {
                if (isset($response['errors']['Error']['Message'])) {
                    $this->messageManager->addError(__(
                        $response['errors']['Error']['Message']
                    ));
                }
                if (!$observer->getEvent()->getRequest()->isAjax()) {
                    $this->_responseFactory->create()->setRedirect($redirect->getRefererUrl())->sendResponse();
                } else {
                    echo '{"backUrl":"'.$redirect->getRefererUrl().'"}';
                    //echo '[]';
                }
            }
            
           // $customRedirectionUrl = $this->_url->getUrl('checkout/cart');
           // $this->_responseFactory->create()->setRedirect($customRedirectionUrl)->sendResponse();
            /* die use for stop excaution */
            
            exit();
        }
         return $this;
    }
}
