<?php

namespace Ced\Gtranslate\Block;

class Link extends Cart
{

    public $_template = 'link.phtml';
}
