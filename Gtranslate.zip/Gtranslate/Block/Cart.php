<?php

namespace Ced\Gtranslate\Block;

use Magento\Framework\View\Element\Template;

class Cart extends Template
{

    public $cartdata=false;
    public $_helper;
    public $_template = 'cart.phtml';
    public function __construct(
        Template\Context $context,
        \Ced\Gtranslate\Helper\Data $helper,
        array $data = []
    ) {
       
        $this->_helper = $helper;
        parent::__construct($context, $data);
    }



    public function getCart()
    {
        if (!$this->cartdata) {
            $this->cartdata = $this->_helper->getCart();
        }

        return isset($this->cartdata['cart']) ? $this->cartdata['cart'] : '';
    }
    public function getPurchaseUrl()
    {
       
        if (!$this->cartdata) {
            $this->cartdata = $this->_helper->getCart();
        }
        return isset($this->cartdata['response']['Cart']['PurchaseURL']) ? $this->cartdata['response']['Cart']['PurchaseURL']:false;
    }
    public function getProduct()
    {
        $productId = $this->getRequest()->getParam('id');
        return $this->_helper->getProduct($productId);
    }
    public function isAliexpressProduct()
    {
        $product = $this->getProduct();
        if ($product->getIsAliexpress() && $product->getAsin()) {
            return true;
        }
        return false;
    }
    public function getAliexpressUrl()
    {
        $productId = $this->getRequest()->getParam('id');
        $product = $this->_helper->getProduct($productId);
        return $product->getAliexpressProductUrl();
    }
}
