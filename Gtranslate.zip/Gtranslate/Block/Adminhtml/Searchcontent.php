<?php
namespace Ced\Gtranslate\Block\Adminhtml;

use Magento\Framework\View\Element\Template;

class Searchcontent extends Template
{

    public $objectManager;
    public $_productAttributeRepository;

    public function __construct(
        Template\Context $context,
        \Magento\Framework\ObjectManagerInterface $objectManager,
        \Magento\Catalog\Model\Product\Attribute\Repository $productAttributeRepository,
        array $data = []
    ) {
        $this->objectManager = $objectManager;
        $this->_productAttributeRepository = $productAttributeRepository;
        parent::__construct($context, $data);
    }

    public function getAliexpressCategories()
    {
        $optionValue = [
            "All","Baby","Beauty","Blended","Books","Collectibles","Electronics","Fashion","FashionBaby","FashionBoys",
            "FashionGirls","FashionMen","FashionWomen","GiftCards","Grocery","HealthPersonalCare","HomeGarden",
            "Industrial","KindleStore","LawnAndGarden","Luggage","MP3Downloads","Magazines","Merchants","MobileApps",
            "Movies","Music","MusicalInstruments","OfficeProducts","PCHardware","PetSupplies","Software",
            "SportingGoods","Tools","Toys","UnboxVideo","VideoGames","Wine","Wireless"
               ];
        return $optionValue;
    }

    public function getFirstandLastPage()
    {
        $searchData = $this->objectManager->create('Magento\Backend\Model\Session')->getGtranslateSyncProducts();

        $page = $searchData['page'];
        /*$page['total'] = isset($response['result']['totalResults']) && !empty($response['result']['totalResults'])?
            $response['result']['totalResults'] : 1;
        $page['count'] = $response['result']['totalResults'];//TODO do a api call to get total items and divide by 5*/

        return $page;
    }

    public function getAllMagentoWebsites()
    {
        $websites = [];
        $allWebsites = $this->_storeManager->getWebsites();
        foreach ($allWebsites as $web) {
            $websites[$web->getId()] = $web->getName();
        }
        return $websites;
    }

    public function getAllVisibility()
    {
        $options = [];
        $allOptions = $this->_productAttributeRepository->get('visibility')->getOptions();
        foreach ($allOptions as $option) {
            $options[$option->getValue()] = $option->getLabel();
        }
        return array_reverse($options, true);
    }

    public function getBlockFormKey()
    {
        return $this->objectManager->get('Magento\Framework\Data\Form\FormKey')->getFormKey();
    }

    public function getTotalProductSyncCount()
    {
        $helper = $this->objectManager->create('Ced\Gtranslate\Helper\Data');
        $aliexpressAsin = $helper->getAliexpressProducts()->makeApiReady();
        $data['count'] = count($aliexpressAsin);
        return $data;
    }
}
