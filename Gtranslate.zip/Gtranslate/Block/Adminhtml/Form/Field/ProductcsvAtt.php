<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Ced\Gtranslate\Block\Adminhtml\Form\Field;

use Magento\Framework\Api\SearchCriteriaBuilder;


/**
 * HTML select element block with customer groups options
 */
class ProductcsvAtt extends \Magento\Framework\View\Element\Html\Select
{

    private  $searchCriteriaBuilder;


    /**
     * Construct
     *
     * @param \Magento\Framework\View\Element\Context $context
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\View\Element\Context $context,
        SearchCriteriaBuilder $searchCriteriaBuilder,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
    }


    /**
     * @return array|null
     */
    protected function _getProductFilds()
    {
        $array = ['Product SKU', 'Title', 'Product Url', 'Price', 'Main Image' , 'Additional Images 600', 'Description', 'Specification', 'Warranty & Returns'];

        return $array;
    }

    /**
     * @param $value
     * @return mixed
     */
    public function setInputName($value)
    {
        return $this->setName($value);
    }

    /**
     * @return string
     */
    public function _toHtml()
    {
        if (!$this->getOptions()) {
            foreach ($this->_getProductFilds() as  $method) {
                $this->addOption($method, addslashes($method));
            }
        }
        return parent::_toHtml();
    }
}
