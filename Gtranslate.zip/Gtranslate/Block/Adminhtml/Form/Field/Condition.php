<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Ced\Gtranslate\Block\Adminhtml\Form\Field;

use Magento\Framework\Api\SearchCriteriaBuilder;

/**
 * HTML select element block with customer groups options
 */
class Condition extends \Magento\Framework\View\Element\Html\Select
{
    /**
     * @var
     */
    private $_condition;



    private $searchCriteriaBuilder;

    private $_shipMethod;

    /**
     * Construct
     *
     * @param \Magento\Framework\View\Element\Context $context
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\View\Element\Context $context,
        SearchCriteriaBuilder $searchCriteriaBuilder,
        //        \Ced\Walmart\Model\Source\ShippingOverrides\ShipMethod $shipMethod,
        array $data = []
    ) {
        parent::__construct($context, $data);
//        $this->_shipMethod = $shipMethod;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
    }


    /**
     * @return array|null
     */
    protected function _getCondition()
    {
        if ($this->_condition === null) {
            /*$shipMethod = $this->_shipMethod->toOptionArray();
            $this->_condition = $shipMethod;*/
            $this->_condition = [
                [
                    'label' => 'greater than',
                    'value' => '>'
                ],
                [
                    'label' => 'less than',
                    'value' => '<'
                ],
                [
                    'label' => 'Equal To',
                    'value' => '=='
                ]/*,
                [
                    'label' => 'Price',
                    'value' => 'Price'
                ],*/
            ];
        }

        return $this->_condition;
    }

    /**
     * @param $value
     * @return mixed
     */
    public function setInputName($value)
    {
        return $this->setName($value);
    }

    /**
     * @return string
     */
    public function _toHtml()
    {
        if (!$this->getOptions()) {
            foreach ($this->_getCondition() as $method) {
                $this->addOption($method['value'], addslashes($method['label']));
            }
        }
        return parent::_toHtml();
    }
}
