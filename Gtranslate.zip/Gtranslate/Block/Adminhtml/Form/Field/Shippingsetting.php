<?php

namespace Ced\Gtranslate\Block\Adminhtml\Form\Field;

class Shippingsetting extends \Magento\Config\Block\System\Config\Form\Field\FieldArray\AbstractFieldArray
{
    /**
     * @var
     */
    protected $_property;

    /**
     * @var
     */
    protected $_value;

    protected $_condition;

    protected $_label;

    /**
     * Retrieve group column renderer
     *
     * @return shipping
     */
    protected function _getLabelRenderer()
    {
        if (!$this->_label) {
            $this->_label = $this->getLayout()->createBlock(
                //'Magento\CatalogInventory\Block\Adminhtml\Form\Field\Customergroup',
                'Ced\Gtranslate\Block\Adminhtml\Form\Field\Label',
                '',
                ['data' => ['is_render_to_js_template' => true]]
            );
            $this->_label->setClass('label_select');//shipping_region_select
        }
        return $this->_label;
    }


    /**
     * Retrieve group column renderer
     *
     * @return shipping
     */
    protected function _getPropertyRenderer()
    {
        if (!$this->_property) {
            $this->_property = $this->getLayout()->createBlock(
                'Ced\Gtranslate\Block\Adminhtml\Form\Field\Property',
                '',
                ['data' => ['is_render_to_js_template' => true]]
            );
            $this->_property->setClass('_property_select');
        }
        return $this->_property;
    }

    /**
     * Retrieve group column renderer
     *
     * @return shipping
     */
    protected function _getValueRenderer()
    {
        if (!$this->_value) {
            $this->_value = $this->getLayout()->createBlock(
                'Ced\Gtranslate\Block\Adminhtml\Form\Field\Value',
                '',
                ['data' => ['is_render_to_js_template' => true]]
            );
            $this->_value->setClass('value_select');
        }
        return $this->_value;
    }

    /**
     * Retrieve group column renderer
     *
     * @return shipping
     */
    protected function _getConditionRenderer()
    {
        if (!$this->_condition) {
            $this->_condition = $this->getLayout()->createBlock(
                'Ced\Gtranslate\Block\Adminhtml\Form\Field\Condition',
                '',
                ['data' => ['is_render_to_js_template' => true]]
            );
            $this->_condition->setClass('condition_select');
        }
        return $this->_condition;
    }

    /**
     * Prepare to render
     *
     * @return void
     */
    protected function _prepareToRender()
    {
        $this->addColumn(
            'property',
            ['label' => __('Property'), 'renderer' => $this->_getPropertyRenderer()]
        );
        $this->addColumn(
            'condition',
            ['label' => __('Condition'), 'renderer' => $this->_getConditionRenderer()]
        );
        //$this->addColumn('charges', ['label' => __('Charges')]);
        $this->addColumn(
            'Value',
            ['label' => __('Value'), /*'renderer' => $this->_getValueRenderer()*/]
        );
        $this->addColumn(
            'label',
            ['label' => __('Label'), /*'renderer' => $this->_getLabelRenderer()*/]
        );
        $this->_addAfter = false;
        $this->_addButtonLabel = __('Add Rule');
    }

    /**
     * Prepare existing row data object
     *
     * @param \Magento\Framework\DataObject $row
     * @return void
     */
    protected function _prepareArrayRow(\Magento\Framework\DataObject $row)
    {
        $optionExtraAttr = [];

        $optionExtraAttr['option_' . $this->_getPropertyRenderer()->calcOptionHash($row->getData('property'))] =
            'selected="selected"';

        $optionExtraAttr['option_' . $this->_getConditionRenderer()->calcOptionHash($row->getData('condition'))] =
            'selected="selected"';
        /*$optionExtraAttr['option_' . $this->_getShippingMethodRenderer()->calcOptionHash($row->getData('value'))] =
            'selected="selected"';
        $optionExtraAttr['option_' . $this->_getMagentoAttributeCodeRenderer()->calcOptionHash($row->getData('label'))] =
            'selected="selected"';*/
        $row->setData(
            'option_extra_attrs',
            $optionExtraAttr
        );
    }
}
