<?php

namespace Ced\Gtranslate\Block\Adminhtml\Form\Field;

class AttributeMapping extends \Magento\Config\Block\System\Config\Form\Field\FieldArray\AbstractFieldArray
{
    /**
     * @var
     */
    protected $_shippingRegion;

    /**
     * @var
     */
    protected $_shippingMethod;

    protected $_magentoAttr;

    protected  $_enabledRenderer;

    /**
     * @return \Magento\Framework\View\Element\BlockInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    protected function _getEnabledRenderer()
    {
        if (!$this->_enabledRenderer) {
            $this->_enabledRenderer = $this->getLayout()->createBlock(
                'Ced\Walmart\Block\Adminhtml\Form\Field\Enabled',
                '',
                ['data' => ['is_render_to_js_template' => true]]
            );
            $this->_enabledRenderer->setClass('shipping_region_select');
        }
        return $this->_enabledRenderer;
    }


    /**
     * Retrieve group column renderer
     *
     * @return \Magento\Framework\View\Element\BlockInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    protected function _getShippingRegionRenderer()
    {
        if (!$this->_shippingRegion) {
            $this->_shippingRegion = $this->getLayout()->createBlock(
                'Ced\Walmart\Block\Adminhtml\Form\Field\ShippingRegion',
                '',
                ['data' => ['is_render_to_js_template' => true]]
            );
            $this->_shippingRegion->setClass('shipping_region_select');
        }
        return $this->_shippingRegion;
    }

    /**
     * Retrieve group column renderer
     *
     * @return \Magento\Framework\View\Element\BlockInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    protected function _getShippingMethodRenderer()
    {
        if (!$this->_shippingMethod) {
            $this->_shippingMethod = $this->getLayout()->createBlock(
                'Ced\Gtranslate\Block\Adminhtml\Form\Field\ProductcsvAtt',
                '',
                ['data' => ['is_render_to_js_template' => true]]
            );
            $this->_shippingMethod->setClass('shipping_method_select');
        }
        return $this->_shippingMethod;
    }

    /**
     * Retrieve group column renderer
     *
     * @return \Magento\Framework\View\Element\BlockInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    protected function _getMagentoAttributeCodeRenderer()
    {
        if (!$this->_magentoAttr) {
            $this->_magentoAttr = $this->getLayout()->createBlock(
                'Ced\Gtranslate\Block\Adminhtml\Form\Field\MagentoAttributes',
                '',
                ['data' => ['is_render_to_js_template' => true]]
            );
            $this->_magentoAttr->setClass('shipping_method_select');
        }
        return $this->_magentoAttr;
    }

    /**
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    protected function _prepareToRender()
    {
        $this->addColumn(
            'gtranslate_field',
            ['label' => __('Gtranslate Product Field'), 'renderer' => $this->_getShippingMethodRenderer()]
        );
        $this->addColumn(
            'magento_attribute',
            ['label' => __('Magento Attibute'), 'renderer' => $this->_getMagentoAttributeCodeRenderer()]
        );
        $this->_addAfter = false;
        $this->_addButtonLabel = __('Add');
    }

    /**
     * @param \Magento\Framework\DataObject $row
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    protected function _prepareArrayRow(\Magento\Framework\DataObject $row)
    {
        $optionExtraAttr = [];

        $optionExtraAttr['option_' . $this->_getShippingMethodRenderer()->calcOptionHash($row->getData('gtranslate_field'))] =
            'selected="selected"';
        $optionExtraAttr['option_' . $this->_getMagentoAttributeCodeRenderer()->calcOptionHash($row->getData('magento_attribute'))] =
            'selected="selected"';
        $row->setData(
            'option_extra_attrs',
            $optionExtraAttr
        );


    }
}
