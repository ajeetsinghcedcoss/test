<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @category  Ced
 * @package   Ced_Gtranslate
 * @author    CedCommerce Core Team <connect@cedcommerce.com >
 * @copyright Copyright CedCommerce (http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 */

namespace Ced\Gtranslate\Helper;

use Magento\Framework\App\Filesystem\DirectoryList;
use Symfony\Component\Config\Definition\Exception\Exception;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    const DEFAULT_QTY = 'affiliate/general_product/default_qty';
    const DEFAULT_STATUS = 'affiliate/general_product/default_status';
    const DEFAULT_VISIBILITY = 'affiliate/general_product/default_visibility';

    public $logger;

    public $over1000;
    public $over2500;
    public $oversized;
    public $overweight;
    public $extraOverweight;
    public $extraOversized;
    public $personal;
    public $clothing;
    public $electronics;
    public $books;
    public $adMaterials;
    public $foodstuff;
    public $vitaminsSupplement;
    public $makeup;
    public $furniture;
    public $handicraft;
    public $cellphoneAccesories;
    public $headphones;
    public $toysVideogames;
    public $configurableFactory;
    public $entity;
    public $aliexpressHelper;
    public $stockRegistry;
    public $confighelper;

    protected $_config;
    protected $storeManager;
    protected $_objectManager;
    protected $_productFactory;
    protected $_aliexpressProducts;

    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Backend\App\ConfigInterface $config,
        \Magento\Framework\ObjectManagerInterface $objectManager,
        \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $productCollectionFactory,
        \Magento\ConfigurableProduct\Model\Product\Type\ConfigurableFactory $configurableFactory,
        \Magento\Eav\Model\Entity $entity,
        \Magento\Catalog\Model\ResourceModel\Eav\AttributeFactory $eavattribute,
        \Magento\Eav\Api\AttributeOptionManagementInterface $attributeOptionManagement,
        \Magento\Eav\Api\Data\AttributeOptionLabelInterfaceFactory $optionLabelFactory,
        \Magento\Eav\Api\Data\AttributeOptionInterfaceFactory $optionFactory,
        \Magento\ConfigurableProduct\Model\Product\Type\Configurable\AttributeFactory $attributeFactory,
        \Ced\Gtranslate\Helper\Aliexpress\Aliexpress $aliexpressHelper,
        \Magento\CatalogInventory\Api\StockRegistryInterface $stockRegistry,
        \Ced\Gtranslate\Helper\Logger $logger
    )
    {
        parent::__construct($context);
        $this->_config = $config;
        $this->_objectManager = $objectManager;
        $this->storeManager = $storeManager;
        $this->over1000 = $this->scopeConfig->getValue('gtranslate/shipping_rules/over_1000');
        $this->over2500 = $this->scopeConfig->getValue('gtranslate/shipping_rules/over_2500');
        $this->oversized = $this->scopeConfig->getValue('gtranslate/shipping_rules/oversized');
        $this->overweight = $this->scopeConfig->getValue('gtranslate/shipping_rules/overweight');
        $this->extraOverweight = $this->scopeConfig->getValue('gtranslate/shipping_rules/extra_overweight');
        $this->extraOversized = $this->scopeConfig->getValue('gtranslate/shipping_rules/extra_oversized');
        $this->personal = $this->scopeConfig->getValue('gtranslate/shipping_rules/personal');
        $this->clothing = $this->scopeConfig->getValue('gtranslate/commodities/clothing');
        $this->electronics = $this->scopeConfig->getValue('gtranslate/commodities/electronics');
        $this->books = $this->scopeConfig->getValue('gtranslate/commodities/books');
        $this->adMaterials = $this->scopeConfig->getValue('gtranslate/commodities/ad_materials');
        $this->foodstuff = $this->scopeConfig->getValue('gtranslate/commodities/foodstuff');
        $this->vitaminsSupplement = $this->scopeConfig->getValue('gtranslate/commodities/vitamins_supplement');
        $this->makeup = $this->scopeConfig->getValue('gtranslate/commodities/makeup');
        $this->furniture = $this->scopeConfig->getValue('gtranslate/commodities/furniture');
        $this->handicraft = $this->scopeConfig->getValue('gtranslate/commodities/handicraft');
        $this->cellphoneAccesories = $this->scopeConfig
            ->getValue('gtranslate/commodities/cellphone_accesories');
        $this->headphones = $this->scopeConfig->getValue('gtranslate/commodities/headphones');
        $this->toysVideogames = $this->scopeConfig->getValue('gtranslate/commodities/toys_videogames');
        $this->shippingConfig = $this->scopeConfig->getValue('gtranslate/shipping_rules/shipping_type');
        $this->_productFactory = $productCollectionFactory;
        $this->configurableFactory = $configurableFactory;
        $this->eavAttribute = $eavattribute;
        $this->entity = $entity;
        $this->attributeOptionManagement = $attributeOptionManagement;
        $this->optionLabelFactory = $optionLabelFactory;
        $this->optionFactory = $optionFactory;
        $this->configAttribute = $attributeFactory;
        $this->aliexpressHelper = $aliexpressHelper;
        $this->stockRegistry = $stockRegistry;
        $this->logger = $logger;
        $this->confighelper = $this->_objectManager->create('Ced\Gtranslate\Helper\Config');
    }

    /**
     * @param $path
     * @return mixed
     */
    public function getStoreConfigValue($path)
    {
        return $this->_config->getValue($path);
    }

    /**
     * Function for getting Config value of current store
     *
     * @param string $path ,
     */
    public function getStoreConfig($path, $storeId = null)
    {
        $store = $this->storeManager->getStore($storeId);
        return $this->scopeConfig->getValue($path, 'store', $store->getCode());
    }

    public function processRequest($targetIndex = '', $productsData = [])
    {
        return $this->createNewProduct($productsData);
    }


    public function validateProductData($data) {

        $returnData = [];
        $array = [
            'productId' => 'Product SKU',
            'name' => 'Title',
            'gtranslate_product_url' => 'Product Url',
            'price' => 'Price',
            'GalleryURL' => 'Main Image',
            'short_description' => 'Description',
            'description' => 'Description',
            'warranty_returns' => 'Warranty & Returns',
            'specification' => 'Specification',
            'warranty_price_option' => 'Warranty Options',
            'categories' => [
                'Category'
            ],
            'inventory' => 'Inventory',
            'LargeImage' => [
                'Additional Images 600',
                // 'Additional Images 75',
            ]
        ];

        foreach ($array as $key => $value) {
            if(is_array($value)) {
                foreach ($value as $val) {
                    if(isset($data[$val]) && !empty($data[$val])){
                        $images = array_filter(explode(';', $data[$val]));
                        if(isset($returnData['GalleryURL'])) {
                            $key = array_search($returnData['GalleryURL'], $images);
                            if (false !== $key) {
                                unset($images[$key]);
                            }
                        }

                        $returnData[$key] =  $images;
                    }
                }
            }else {
                $returnData[$key] = isset($data[$value]) ? $data[$value] :'';
            }
        }
        return $returnData;

    }


    public function createNewProduct($data)
    {

        // validateProductData return mapped data
        $data = $this->validateProductData($data);

        try {
            if ($data) {
                $itemId = 'Product with Product ID ';
                $productIDs = '';
                $count = 0;
                $importCount = false;
                $spanishStoreId = false;

                $englishStoreId = $this->scopeConfig->getValue('gtranslate/general_product/store');
                $englishStoreId =  empty($englishStoreId) ? 0 : $englishStoreId;
                $store = ['english' => $englishStoreId];


                $count++;
                //$spanishProduct = $data;
                $_product = $this->_objectManager->create('Magento\Catalog\Model\Product')
                    ->setStoreId($englishStoreId);
                if ($_product->getIdBySku($data['productId'])) {

                    $itemId .= $data['productId'] . ' has been already imported';
                    $productIDs .= $data['productId'];

                    return [
                        'success' => true,
                        'msg' => $itemId.' ',
                        'item_id' => $productIDs
                    ];

                }
                try {
                    if (isset($data['warranty_price_option']) && !empty($data['warranty_price_option'])) {


                        $msg = $this->createConfigProduct(
                            $data,
                            $store
                        );

                        if ($msg == $data['productId']) {
                            $importCount = true;
                            if ((sizeof($data) == $count)) {
                                $itemId .= $data['productId'] . ' has been successfully imported';
                                $productIDs .= $data['productId'];
                            } else {
                                $itemId .= $data['productId'] . ', ';
                                $productIDs .= $data['productId'] . ', ';
                            }

                        } else {
                            $itemId .= $msg;
                        }
                    } else {
                        $_product->setName($data['name']);
                        $_product->setTypeId('simple');
                        $_product->setAttributeSetId($_product->getDefaultAttributeSetId());
                        $_product->setSku($data['productId']);
                        $_product->setVisibility(4);
                        $_product->setStatus(1);
                        $qty = $this->getStoreConfig('gtranslate/general/product_default_qty');// : ?  1;
                        if(!$qty) {
                            $qty = isset($data['inventory']) ? $data['inventory'] : 1;
                        }
                        if(!$qty) {
                            $qty = 1;
                        }
                        $_product->setWebsiteIds([1]);
                        $price = $this->getPrice($data['price']);

                        $_product->setPrice($price);
                        $_product->setStockData(['qty' => $qty, 'manage_stock' => 1, 'is_in_stock' => 1]);
                        $counter = 0;
                        if (isset($data['LargeImage'])) {
                            if (is_array($data['LargeImage'])) {
                                foreach ($data['LargeImage'] as $key => $imageUrl) {
                                    $imageUrl = str_replace("https", "http", $imageUrl);
                                    $mediaDirectory = $this->_objectManager->get('Magento\Framework\Filesystem')
                                            ->getDirectoryRead(DirectoryList::MEDIA)
                                            ->getAbsolutePath() . 'catalog/product/' . $data['productId'] . '_' . $counter . '.jpg';
                                    if ($this->get_http_response_code($imageUrl) == "200") {
                                        file_put_contents($mediaDirectory, file_get_contents(trim($imageUrl)));
                                        $_product->addImageToMediaGallery($mediaDirectory, ['image', 'small_image', 'thumbnail'], false, false);
                                    }
                                    $counter++;
                                }
                            } else {
                                $imageUrl = $data['LargeImage'];
                                $imageUrl = str_replace("https", "http", $imageUrl);
                                $mediaDirectory = $this->_objectManager->get('Magento\Framework\Filesystem')
                                        ->getDirectoryRead(DirectoryList::MEDIA)
                                        ->getAbsolutePath() . 'catalog/product/' . $data['productId'] . '.jpg';
                                if ($this->get_http_response_code($imageUrl) == "200") {
                                    file_put_contents($mediaDirectory, file_get_contents(trim($imageUrl)));
                                    $_product->addImageToMediaGallery($mediaDirectory, ['image', 'small_image', 'thumbnail'], false, false);
                                }
                            }
                        }
                        if (isset($data['GalleryURL'])) {
                            $mediaDirectory = $this->_objectManager->get('Magento\Framework\Filesystem')
                                ->getDirectoryRead(DirectoryList::MEDIA)->getAbsolutePath();
                            $imagePath = $mediaDirectory . '/catalog/product/' . 'GalleryURL_' . $data ['productId'] . '.jpg';
                            if ($this->get_http_response_code($data['GalleryURL']) == "200") {
                                file_put_contents($imagePath, file_get_contents(trim($data['GalleryURL'])));
                                $_product->addImageToMediaGallery($imagePath, ['image', 'small_image', 'thumbnail'], false, false);
                            }
                        }

                        $check = '';
                        if ((int)$data['price'] > (int)$this->over1000) {
                            $check = "Ordinary Over $1,000";
                        }
                        if ((int)$data['price'] > (int)$this->over2500) {
                            $check = "Ordinary Over $2,500";
                        }

                        if (isset($data['brand'])) {
                            $_product->setBrand($data['brand']);
                        }
                        if (isset($data['short_description'])) {
                            $_product->setShortDescription($data['short_description']);
                        }
                        if (isset($data['description'])) {
                            $_product->setDescription($data['description']);
                        }
                        if (isset($data['warranty_returns'])) {
                            $warranty = $this->replaceSpacilChar($data['warranty_returns']);
                            $_product->setCedWarrantyReturns($warranty);
                        }

                        if (isset($data['specification'])) {
                            $specification = $this->replaceSpacilChar($data['specification']);
                            $_product->setCedSpecification($specification);
                        }

                        $_product->setData('ced_is_gtranslate', 1);
                        $_product->setGtranslateProductUrl($data['gtranslate_product_url']);
                        $_product->setUrlKey($data['productId']);

                        // set category Ids
                        if (isset($data['categories']) && !empty($data['categories'])) {
                            $categoryArray = $data['categories'];
                            $spanishCategoryArray = [];

                            $allCatIds = $this->getAllCatIds($categoryArray, $spanishCategoryArray, $store);
                            $_product->setCategoryIds($allCatIds);

                        }

                        $lbsRate = 2.20462;
                        $weight = isset($data['weight']) ? explode(' ', $data['weight']) : null;
                        if ($weight) {
                            $weight = $lbsRate * (float)str_replace('kg', '', $weight[0]);
                        }
                        $data['weight'] = $weight;
                        // $_product->setCedShippingType($this->prepareShippingType($data));

                        $_product->setWeight($weight)->setSearchbystore(57);
                        // save product
                        $_product->save();
                        // set spanish store product data

                        $importCount = true;
                        if ((sizeof($data) == $count)) {
                            $itemId .= $data['productId'] . ' has been successfully imported';
                            $productIDs .= $data['productId'];
                        } else {
                            $itemId .= $data['productId'] . ', ';
                            $productIDs .= $data['productId'] . ', ';
                        }
                    }
                } catch (\Exception $e) {

                    $this->logger->error($e->getMessage(), ['path' => __METHOD__, 'exception' => $e->getTraceAsString()]);
                }

            }
        } catch (\Exception $e) {

            $this->logger->addError($e->getMessage(), ['path' => __METHOD__]);
        }

        return (($responseData = !empty($itemId) && ($importCount)) ?
            [
                'success' => true,
                'msg' => $itemId,
                'item_id' => $productIDs
            ] :
            [
                'success' => true,
                'msg' => 'no new product imported',
                'item_id' => false
            ]);
    }

    public function createConfigProduct(
        $data,
        $store
    )
    {

        $description = isset($data['description']) ? $data['description'] :'';
        $short_description = isset($data['short_description']) ? $data['short_description'] :'';
        $brand = isset($data['brand']) ? $data['brand'] :'';
        $lbsRate = 2.20462;
        $price = $this->getPrice($data['price']);
        $weight = isset($data['weight']) ? $data['weight'] : 0;
        $weight = explode(' ', $weight);
        $weight = $lbsRate * (float)str_replace('kg', '', $weight[0]);
        $data['weight'] = $weight;
        $this->prepareShippingType($data);
        $associatedProductIds = [];
        try {
            if (!empty($data['productId'])) {
                $productObj = $this->_objectManager->create('Magento\Catalog\Model\Product')
                    ->setStoreId($store['english']);
                $prodObj = $productObj->loadByAttribute('sku', $data['productId']);
                if (empty($prodObj)) {
                    $attributes = [];
                    $imageUrl = '';

                    if (isset($data['warranty_price_option'])) {

                        $warrantyPriceOptions = trim($data['warranty_price_option'], '"]');
                        $warrantyPriceOptions = trim($warrantyPriceOptions, '["');
                        $warrantyPriceOptions = array_filter(explode('"', $warrantyPriceOptions));
                        $warrantyPriceOptions[] = 'No Warranty';

                        // more than one variations
                        foreach ($warrantyPriceOptions as $key => $variationValue) {
                            $arr1 = [];
                            //config attribute create
                            if ($variationValue) {
                                // foreach ($variation['attributes'] as $key2 => $attributeValue) {
                                $att = 'Warranty Price';
                                $attributeCode = str_replace(
                                    " ",
                                    '_',
                                    strtolower($att)
                                );

                                $optionArray = [
                                    'value' => [
                                        "option_0" => [
                                            0 => $variationValue,
                                            $store['english'] => $variationValue,
                                        ]
                                    ]
                                ];

                                $attributeId = $this->eavAttribute->create()->getIdByCode(
                                    'catalog_product',
                                    $attributeCode
                                );

                                if (!$attributeId) {
                                    $attributeId = $this->getAttributeCreate(
                                        $attributeCode,
                                        $optionArray,
                                        $att,
                                        '',
                                        $store
                                    );
                                }
                                $optionsObj = $this->_objectManager->create('Magento\Eav\Model\Attribute')
                                    ->load($attributeId)
                                    ->getSource();
                                $options = $optionsObj->getAllOptions();

                                $optionCheck = [];
                                foreach ($options as $option) {
                                    $optionCheck[$option['label']] = '';
                                }

                                if (!isset($optionCheck[$variationValue])) {
                                    $optionId = $this->addAttributeOption(
                                        $attributeCode,
                                        $variationValue,
                                        '',
                                        $store
                                    );
                                } else {
                                    $optionId = $optionsObj->getOptionId($variationValue);
                                }
                                $arr1[$attributeCode] = $optionId;
                                $attributes[] = $attributeId;

                                // }
                                $imageUrl = '';
                            }
                            // create Variation products
                            $productObj = $this->_objectManager->create('Magento\Catalog\Model\Product')
                                ->setStoreId($store['english']);

                            $prodObj = $this->_objectManager->create('Magento\Catalog\Model\Product')
                                ->loadByAttribute('sku', $data['productId'].'-'.$key);
                            if (!empty($prodObj)) {
                                continue;
                            }

                            $arr2 = [
                                'name' => $data['name'],
                                'sku' => $data['productId'].'-'.$key,
                                'status' => 1,
                                'stock_data' => [
                                    'qty' => isset($data['inventory']) ? $data['inventory'] : 1,
                                    'manage_stock' => 1,
                                    'is_in_stock' => 1
                                ],
                                'visibility' => 1,
                                'website_ids' => [1],
                                'site_id' => 0,
                                'weight' => $weight,
                                'attribute_set_id' => 4,
                                'url_key' => $data['productId'].$key,
                                'type_id' => 'simple',
                                'price' => $price,
                                'meta_title' => html_entity_decode($data['name']),
                                'meta_keyword' => html_entity_decode($data['name']),
                                'meta_description' => html_entity_decode($data['name']),
                                'short_description' => $short_description,
                                'description' => $description
                            ];
                            $arr = array_merge_recursive($arr2, $arr1);

                            try {
                                if (isset($data['GalleryURL'])) {
                                    $mediaDirectory = $this->_objectManager->get('Magento\Framework\Filesystem')
                                        ->getDirectoryRead(DirectoryList::MEDIA)->getAbsolutePath();
                                    $imagePath = $mediaDirectory . '/catalog/product/' . 'GalleryURL_' . $data ['productId'] . '-'.$key.'.jpg';
                                    if ($this->get_http_response_code($data['GalleryURL']) == "200") {
                                        file_put_contents($imagePath, file_get_contents(trim($data['GalleryURL'])));
                                        $productObj->addImageToMediaGallery($imagePath, ['image', 'small_image', 'thumbnail'], false, false);
                                    }
                                }
                                $productObj->addData($arr)->setSearchbystore(57)->getResource()->save($productObj);

                            } catch (\Exception $e) {

                                $this->logger->error(
                                    $e->getMessage(),
                                    ['path' => __METHOD__, 'exception' => $e->getTraceAsString()]
                                );
                            }
                            $associatedProductIds[] = $productObj->getEntityId();
                        }
                    }

                    // Create Config Product
                    $configProduct = $this->_objectManager->create('Magento\Catalog\Model\Product')
                        ->setStoreId($store['english']);
                    $configProduct->setName($data['name']);
                    $configProduct->setTypeId('configurable');
                    $configProduct->setAttributeSetId(4);
                    $configProduct->setStatus(1);
                    $configProduct->setVisibility(4);
                    $configProduct->setWebsiteIds([1]);
                    $configProduct->setSiteId(0);
                    $configProduct->setSku($data['productId']);
                    $configProduct->setWeight($weight);
                    $configProduct->setPrice($price);
                    $configProduct->setUrlKey($data['productId']);
                    $configProduct->setMetaTitle($data['name']);
                    $configProduct->setMetaKeyword($data['name']);
                    $configProduct->setMetaDescription($data['name']);
                    $configProduct->setStockData(
                        [
                            'use_config_manage_stock' => 1,
                            'manage_stock' => 1,
                            'is_in_stock' => 1,
                            'qty' => 1
                        ]
                    );

                    if (isset($data['warranty_returns'])) {
                        $warranty = $this->replaceSpacilChar($data['warranty_returns']);
                        $configProduct->setCedWarrantyReturns($warranty);
                    }

                    if (isset($data['specification'])) {
                        $specification = $this->replaceSpacilChar($data['specification']);
                        $configProduct->setCedSpecification($specification);
                    }

                    $configProduct->setData('ced_is_gtranslate', 1);
                    $configProduct->setGtranslateProductUrl($data['gtranslate_product_url']);
                    $configProduct->setUrlKey($data['productId']);

                    if (isset($data['GalleryURL'])) {
                        $mediaDirectory = $this->_objectManager->get('Magento\Framework\Filesystem')
                            ->getDirectoryRead(DirectoryList::MEDIA)->getAbsolutePath();
                        $imagePath = $mediaDirectory . '/catalog/product/' . 'GalleryURL_' . $data ['productId'] . '.jpg';
                        if ($this->get_http_response_code($data['GalleryURL']) == "200") {
                            file_put_contents($imagePath, file_get_contents(trim($data['GalleryURL'])));
                            $configProduct->addImageToMediaGallery($imagePath, ['image', 'small_image', 'thumbnail'], false, false);
                        }
                    }

                    if (isset($data['LargeImage'])) {
                        $count = 0;
                        foreach ($data['LargeImage'] as $key => $imageUrl) {
                            // $imageUrl = str_replace("https", "http", $imageUrl);
                            $mediaDirectory = $this->_objectManager->get('Magento\Framework\Filesystem')
                                    ->getDirectoryRead(DirectoryList::MEDIA)
                                    ->getAbsolutePath() . 'catalog/product/' . $data['productId'] . '_' . $count++ . '.jpg';

                            if (filter_var(html_entity_decode($imageUrl), FILTER_VALIDATE_URL)) {
                                file_put_contents($mediaDirectory, file_get_contents((html_entity_decode($imageUrl))));
                                $configProduct->addImageToMediaGallery($mediaDirectory, ['image', 'small_image', 'thumbnail'], false, false);
                            }
                        }
                    }

                    $configProduct->setBrand($brand);
                    $configProduct->setShortDescription($short_description);
                    $configProduct->setDescription($description);
                    if(isset($data['dimension'])) {
                        $data['volume'] = eval('return ' . str_replace(['in', 'x'], ['', '*'], substr($data['dimension'], strpos($data['dimension'], '('))) . ';');
                        $configProduct->setHlw($data['volume'])->setSearchbystore(57);
                    }
                    if (isset($data['categories'])) {
                        $categoryArray = $data['categories'];
                        $spanishCategoryArray = [];
                        $allCatIds = $this->getAllCatIds($categoryArray, $spanishCategoryArray, $store);
                        $configProduct->setCategoryIds($allCatIds);

                    }
                    $configProduct->getResource()->save($configProduct);

                    $productId = $configProduct->getEntityId();

                    // Assign Variation in to Config Product
                    $position = 0;
                    $attributes = array_flip(array_flip($attributes));
                    foreach ($attributes as $attributeId) {
                        $data = [
                            'attribute_id' => $attributeId,
                            'position' => $position,
                            'product_id' => $productId];
                        $position++;
                        $this->configAttribute->create()->setData($data)->save();
                    }

                    $configProduct->setAffectConfigurableProductAttributes(4);
                    $this->configurableFactory->create()
                        ->setUsedProductAttributes($configProduct, $attributes);
                    $configProduct->setNewVariationsAttributeSetId(4);
                    $associatedProductIds = array_flip(array_flip($associatedProductIds));
                    //                $configProduct->setAssociatedProductIds($associatedProductIds);
                    $configProduct->setCanSaveConfigurableAttributes(true);
                    $configProduct->save();

                    $this->_objectManager->create('Magento\ConfigurableProduct\Model\ResourceModel\Product\Type\Configurable')
                        //                $this->_objectManager->create('\Magento\Catalog\Model\ResourceModel\Product\Relation')
                        ->saveProducts($configProduct, $associatedProductIds);
                    //                    ->addRelations($configProduct->getEntityId(),$associatedProductIds);
                    $msg = $configProduct->getSku();

                    return $msg;
                }else {
                    $msg = $prodObj->getSku();
                }

            }
        } catch (\Exception $exception) {

            $message = $exception->getMessage();
            $this->logger->error($message, ['path' => __METHOD__, 'exception' => $exception->getTraceAsString()]);
            return $message;
        }
    }

    public function replaceSpacilChar($string) {
        $convert = Array(
            'ä'=>'a',
            'Ä'=>'A',
            'á'=>'a',
            'Á'=>'A',
            'à'=>'a',
            'À'=>'A',
            'ã'=>'a',
            'Ã'=>'A',
            'â'=>'a',
            'Â'=>'A',
            'č'=>'c',
            'Č'=>'C',
            'ć'=>'c',
            'Ć'=>'C',
            'ď'=>'d',
            'Ď'=>'D',
            'ě'=>'e',
            'Ě'=>'E',
            'é'=>'e',
            'É'=>'E',
            'ë'=>'e',
        );

        $string = strtr($string , $convert );
        $string = preg_replace("/(<br\s*\/?>\s*)+/", "<br/>", $string);
        return $string;

    }

    public function getPrice($price)
    {

        $price = trim($price, '$');
        if (isset($price) && !empty($price)) {
            // $price = (float)$price;
            $priceType = $this->scopeConfig->getValue('gtranslate/general_product/product_price');

            if (isset($priceType) and !empty($priceType)) {
                switch ($priceType) {
                    case 'plus_fixed':
                        $fixedPrice = $this->scopeConfig->getValue('gtranslate/general_product/fix_price');
                        if (isset($fixedPrice) && is_numeric($fixedPrice) && $fixedPrice != '') {
                            $fixedPrice = (float)$fixedPrice;
                            if ($fixedPrice > 0) {
                                $price = (float)($price + $fixedPrice);
                            }
                        }
                        break;

                    case 'min_fixed':
                        $fixedPrice = $this->scopeConfig->getValue('gtranslate/general_product/fix_price');
                        if (isset($fixedPrice) && is_numeric($fixedPrice) && $fixedPrice != '') {
                            $fixedPrice = (float)$fixedPrice;
                            if ($fixedPrice > 0) {
                                $price = (float)($price - $fixedPrice);
                            }
                        }
                        break;

                    case 'plus_per':
                        $percentPrice = $this->scopeConfig->getValue('gtranslate/general_product/percentage_price');
                        if (isset($percentPrice) && is_numeric($percentPrice) && $percentPrice != '') {
                            $percentPrice = (float)$percentPrice;
                            if ($percentPrice > 0) {
                                $price = (float)($price + (($price / 100) * $percentPrice));
                            }
                        }
                        break;

                    case 'min_per':
                        $percentPrice = $this->scopeConfig->getValue('gtranslate/general_product/percentage_price');
                        if (isset($percentPrice) && is_numeric($percentPrice) && $percentPrice != '') {
                            $percentPrice = (float)$percentPrice;
                            if ($percentPrice > 0) {
                                $price = (float)($price - (($price / 100) * $percentPrice));
                            }
                        }
                        break;

                    default:
                        return (string)$price;
                }
            }
        }
        return (string)$price;
    }

    public function prepareShippingType($data)
    {
        $shippingType = unserialize($this->shippingConfig);
        $data['hazmat'] = true;
        /*echo '<pre>';
        print_r($data['price']);
        print_r($data['categories']);
        print_r($data['weight']);
        print_r($shippingType);*/
        $amShippingType = [];
        if ($shippingType != '') {
            foreach ($shippingType as $type) {
                if (isset($type['property'], $data[strtolower($type['property'])])) {
                    if ($type['property'] == 'Hazmat' && isset($data['categories'])) {
                        $categories = /*array_flip*/
                            ($data['categories']);

                        $options = explode(',', $type['Value']);
                        foreach ($options as $option) {
                            foreach ($categories as $categorie) {
                                if (trim(html_entity_decode($categorie, ENT_QUOTES)) == trim($option)) {
                                    $amShippingType[$type['label']] = '';
                                    break;
                                }
                            }
                        }
                        continue;
                    }
                    //                    if (eval('return' .$data[strtolower($type['property'])] . $type['condition'] . (float)$type['Value'] .';')) {

                    if ($type['property'] == 'Price' || $type['property'] == 'price') {
                        $data[strtolower($type['property'])] = str_replace(',', '', $data[strtolower($type['property'])]);
                    }
                    if ($this->compare($data[strtolower($type['property'])], $type['condition'], (float)$type['Value'])) {
                        $amShippingType[$type['label']] = $type['label'];
                    }
                }
            }
        }

        if (!empty($amShippingType)) {
            return implode(',', array_flip($amShippingType));
        }
        return '';
    }

    /*
     * Prepare Shipping Type
     */

    public function compare($expr1, $operator, $expr2)
    {
        switch (strtolower($operator)) {
            case '==':
                return $expr1 == $expr2;
            case '>':
                return $expr1 >= $expr2;
            case '<':
                return $expr1 <= $expr2;
            case '!=':
                return $expr1 != $expr2;
            case '&&':
            case 'and':
                return $expr1 && $expr2;
            case '||':
            case 'or':
                return $expr1 || $expr2;
            default:
                return false;
        }
    }

    /**
     * @param $attributeCode
     * @param $optionArray
     * @param $attributeUpperCase
     * @return object
     */
    public function getAttributeCreate($attributeCode, $optionArray, $attributeUpperCase, $spanishLabel = '', $store)
    {

        $frontend_label = [];
        if (isset($store['spanish']) && $store['spanish']) {
            $frontend_label = [
                0 => $attributeUpperCase,
                $store['english'] => $attributeUpperCase,
                $store['spanish'] => $spanishLabel
            ];
        } else {
            $frontend_label = [
                0 => $attributeUpperCase,
                $store['english'] => $attributeUpperCase,
            ];
        }
        $attributeData = [
            'attribute_code' => $attributeCode,
            'is_global' => 1,
            'frontend_label' => $frontend_label,
            'frontend_input' => 'select',
            'default_value_text' => '',
            'default_value_yesno' => 0,
            'default_value_date' => '',
            'default_value_textarea' => '',
            'is_unique' => 0,
            'attribute_set_id' => 4,
            'attribute_group_id' => 7,
            'apply_to' => 0,
            'group' => "Product Details",
            'is_required' => 0,
            'is_configurable' => 1,
            'is_searchable' => 1,
            'is_user_defined' => 1,
            'is_comparable' => 0,
            'is_visible_in_advanced_search' => 1,
            'is_used_for_price_rules' => 0,
            'is_wysiwyg_enabled' => 0,
            'is_html_allowed_on_front' => 1,
            'is_visible_on_front' => 0,
            'used_in_product_listing' => 0,
            'used_for_sort_by' => 0,
            'is_filterable' => 0,
            'is_filterable_in_search' => 0,
            'backend_type' => 'varchar',
            'option' => $optionArray,
            'default' => [
                '0' => 'option_0'
            ]
        ];
        $entityTypeID = $this->entity->setType('catalog_product')->getTypeId();
        $eavAttribute = $this->eavAttribute->create();
        $eavAttribute->addData($attributeData)->setEntityTypeId($entityTypeID)
            ->getResource()->save($eavAttribute);
        return $eavAttribute->getAttributeId();
    }

    /*codes for creating options if not exists*/

    /**
     * @param $attributeCode
     * @param $value
     * @return mixed
     */
    public function addAttributeOption($attributeCode, $value, $spanishValue = '', $store)
    {

        /**
         * @var \Magento\Eav\Model\Entity\Attribute\OptionLabel $optionLabel
         */
        $optionLabel = $this->optionLabelFactory->create();
        $optionLabel->setStoreId($store['english']);
        $optionLabel->setLabel($value);
        if (isset($store['spanish']) && $store['spanish']) {
            $optionLabelSpanish = $this->optionLabelFactory->create();
            $optionLabelSpanish->setStoreId($store['spanish']);
            $optionLabelSpanish->setLabel($spanishValue);
            $option = $this->optionFactory->create();
            $option->setLabel($value);
            $option->setStoreLabels(
                [
                    $optionLabel,
                    $optionLabelSpanish,
                ]
            );

        } else {
            $option = $this->optionFactory->create();
            $option->setLabel($value);
            $option->setStoreLabels(
                [
                    $optionLabel,
                ]
            );
        }
        $option->setSortOrder(0);
        $option->setIsDefault(false);

        $this->attributeOptionManagement->add(
            'catalog_product',
            $attributeCode,
            $option
        );


        $attribute = $this->_objectManager->create('Magento\Eav\Model\Config')->getAttribute('catalog_product', $attributeCode);
        $optionId = $attribute->getSource()->getOptionId($value);

        return $optionId;
    }

    /*codes for attribute creation and its options if not exist*/
    /**
     * @param $url
     * @return bool|string
     */
    public function get_http_response_code($url)
    {
        $headers = get_headers($url);
        return substr($headers[0], 9, 3);
    }

    public function getAllCatIds($categoryArray, $spanishCategoryArray = [], $store)
    {
        $allCatIds = [];
        $storeManager = $this->_objectManager->get('\Magento\Store\Model\StoreManagerInterface');
        /// Get Store ID
        if (!isset($categoryArray[0])) {
            return [];
        }
        $categoryFactory = $this->_objectManager->create('Magento\Catalog\Model\ResourceModel\Category\CollectionFactory');
        $categories = $categoryFactory->create()
            ->addAttributeToSelect('entity_id')
            ->addAttributeToFilter('name', $this->clearEntities($categoryArray[0]))
            ->addAttributeToFilter('level', 2)
            ->setStoreId($store['english']);
        $rootNodeId = $storeManager->getStore($store['english'])->getRootCategoryId();
        if (count($categories) == 0) {
            // create new category and insert product
            foreach ($categoryArray as $key => $cat) {
                if (isset($store['spanish']) && $store['spanish']) {
                    $rootNodeId = $this->createCategory(
                        $this->clearEntities($cat),
                        $this->clearEntities($spanishCategoryArray[$key]),
                        $rootNodeId,
                        $store
                    );
                } else {
                    $rootNodeId = $this->createCategory(
                        $this->clearEntities($cat),
                        '',
                        $rootNodeId,
                        $store
                    );
                }
                $allCatIds[] = $rootNodeId;
            }
        } else {
            // check if
            $cat = $categories->getData();
            $rootNodeId = $cat[0]['entity_id'];
            $parentCount = 0;
            foreach ($categoryArray as $key => $cat) {
                if ($parentCount == 0) {
                    $parentCount = 1;
                    $allCatIds[] = $rootNodeId;
                    continue;
                }
                if (isset($store['spanish']) && $store['spanish']) {
                    $rootNodeId = $this->verifyCategory($this->clearEntities($cat), $this->clearEntities($spanishCategoryArray[$key]), $rootNodeId, $store);
                } else {
                    $rootNodeId = $this->verifyCategory($this->clearEntities($cat), '', $rootNodeId, $store);
                }
                $allCatIds[] = $rootNodeId;
            }
        }
        return $allCatIds;
    }

    public function clearEntities($value)
    {
        return html_entity_decode($value, ENT_COMPAT, 'UTF-8');
    }

    /*
     * Get Response Code HTTP
     */

    public function createCategory($name, $spanishName = '', $rootNodeId, $store)
    {
        $rootCat = $this->_objectManager->create('Magento\Catalog\Model\Category');
        $parentId = $rootCat->load($rootNodeId);
        $url = strtolower(str_replace(' ', '-', $name));
        $category = $this->_objectManager->create('\Magento\Catalog\Model\Category');
        $category->setName($this->clearEntities($name))
            ->setIsActive(true)
            ->setUrlKey($url)
            ->setData('description', 'description')
            ->setParentId($parentId->getId())
            ->setStoreId($store['english'])
            ->setPath($parentId->getPath())
            ->save();
        if (isset($store['spanish']) && $store['spanish']) {
            $category->setStoreId($store['spanish'])
                ->setIsActive(true)
                ->setParentId($parentId->getId())
                ->setName($this->clearEntities($spanishName))
                ->save();
        }

        return $category->getEntityId();
    }

    /*
     * Clear Entities
     */

    /**
     * Varify Category Alredy Exist Or Not
     *
     * @param  $name
     * @param  $rootNodeId
     * @param  $storeId
     * @return array|string
     */
    public function verifyCategory($name, $spanishName = '', $rootNodeId, $store)
    {
        $objectManager = $this->_objectManager;
        $categoryRepository = $objectManager->create('Magento\Catalog\Model\CategoryRepository');
        $parentcategories = $categoryRepository->get($rootNodeId);
        $categories = $parentcategories->getChildrenCategories();
        $match = 1;
        $returnNodeId = null;
        foreach ($categories as $category) {
            $match = strcasecmp($name, $category->getName());
            if ($match == 0) {
                $returnNodeId = $category->getId();
                break;
            }
        }
        if ($match != 0) {
            return $this->createCategory($name, $spanishName, $rootNodeId, $store);
        } else {
            return $returnNodeId;
        }
    }

    public function getCommodities($options, $data, $option)
    {
        foreach ($options as $category) {
            if (in_array(trim($category), $data)) {
                return $option;
            }
        }
        return "";
    }

    public function getOptionid($value, $attributeCode)
    {
        $optionId = $this->_objectManager->create('Magento\Eav\Model\Config')->getAttribute('catalog_product', $attributeCode)->getSource()->getOptionId($value);
        return $optionId;
    }

    public function processSyncRequest($targetIndex)
    {
        $coreHelper = $this->_objectManager->create('Ced\Gtranslate\Helper\Aliexpress\Aliexpress');
        $sessionData = $this->_objectManager->create('Magento\Backend\Model\Session');
        $params = $sessionData->getAliexpressSyncProducts();
        $asins['asin'] = $params[$targetIndex];

        $affiliateProductData = $coreHelper->callOperation('search_asin', $asins);

        /*if (isset($affiliateProductData['error'])) {
            return $affiliateProductData;
        } else {
            $affiliateProductData = $this->updateProduct($affiliateProductData);
            return $affiliateProductData;
        }*/
    }

    public function updateProduct($productData)
    {
        $productRepository = $this->_objectManager->get('\Magento\Catalog\Model\ProductRepository');
        $asin = 'Product with ASIN ';
        $count = 0;
        foreach ($productData as $data) {
            $count++;
            try {
                $product = $productRepository->get($data['asin']);
                $price = $this->getPrice($data['price']);
                $product->setPrice($price);
                if (isset($data['LargeImage'])) {
                    $mediaDirectory = $this->_objectManager->get('Magento\Framework\Filesystem')
                            ->getDirectoryRead(DirectoryList::MEDIA)->getAbsolutePath() . 'catalog/product/' . $data['asin'] . '.jpg';
                    $url = $data['LargeImage'];
                    file_put_contents($mediaDirectory, file_get_contents($url));
                    $imagePath = $mediaDirectory; // path of the image
                    $product->addImageToMediaGallery($imagePath, ['image', 'small_image', 'thumbnail'], false, false);
                }

                $product->setShortDescription($data['short_description']);
                $product->setDescription($data['description']);

                if (isset($data['availability']) && ($data['availability'] == 1)) {
                    $product->setStatus(\Magento\Catalog\Model\Product\Attribute\Source\Status::STATUS_ENABLED);
                } else {
                    $product->setStatus(\Magento\Catalog\Model\Product\Attribute\Source\Status::STATUS_DISABLED);
                }

                if (isset($data['reviews'])) {
                    $product->setData('aliexpress_review_url', $data['reviews']);
                }


                $product->save();
                $asin .= (sizeof($productData) == $count) ? $data['asin'] . ' has been successfully synchronized' : $data['asin'] . ', ';
            } catch (Exception $e) {
            }
        }
        return ['success' => true, 'msg' => $asin];
    }

    public function prepareProductData($data = []) {

        $header = [];
        try {
            $returnData = [];
            foreach ($data as $rowdata) {
                if(!$header) {
                    $header = $rowdata;
                    continue;
                }
                $returnData[] = array_combine($header,$rowdata);
            }
            return $returnData;
        }catch (\Exception $e) {
            return $e->getMessage().' File Having Headers : '. implode(',', $header);
        }

    }

    public function extractValidCategories($categoryData)
    {
        $validCategory = [];
        $cat = preg_replace('/\s+/', '', $categoryData);
        $requiredCategory = explode(',', $cat);
        $catColection = $this->_objectManager->create('Magento\Catalog\Model\Category');
        foreach ($requiredCategory as $cat => $catValue) {
            if (empty($catValue)) {
                continue;
            }
            $category = $catColection->load($catValue);
            if ($category->getId()) {
                $validCategory[] = $category->getId();
            }
        }

        return $validCategory;
    }

    public function getProduct($id)
    {
        $product = $this->_objectManager->create('Magento\Catalog\Model\Product');
        return $product->load($id);
    }
}
