<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement (EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @category    Ced
 * @package     Ced_Walmart
 * @author 		CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright   Copyright CedCommerce (http://cedcommerce.com/)
 * @license      http://cedcommerce.com/license-agreement.txt
 */

namespace Ced\Gtranslate\Helper;

use Magento\Framework\App\Helper\Context;
use Magento\Setup\Exception;

class Config extends \Magento\Framework\App\Helper\AbstractHelper
{

    const SPANISH_ENABLE = 'gtranslate/general_product/spanish_enable';


    /**
     * Gtranslate product translation_settings  Setting constent
     */
     const TRANSLATION_ENABLE = 'gtranslate/translation_settings/enable';
     const TRANSLATION_API_KEY = 'gtranslate/translation_settings/translation_api_key';
     const TRANSLATION_LANGUAGE = 'gtranslate/translation_settings/language';
     const PRODUCT_ATTRIBUTE = 'gtranslate/translation_settings/product_attribute';
     const PRODUCT_STORE = 'gtranslate/translation_settings/product_store';

    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    public $scopeConfigManager;

    public function __construct(
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig ,
        Context $context
    ) {
        $this->scopeConfigManager = $scopeConfig;
        parent::__construct($context);
    }


    public function getTranslationEnable()
    {
        $status = $this->scopeConfig->getValue(self::TRANSLATION_ENABLE);
        return $status;
    }

    public function getTranslationApiKey()
    {
        $status = $this->scopeConfig->getValue(self::TRANSLATION_API_KEY);
        return $status;
    }

    public function getTranslationLanguage()
    {
        $status = $this->scopeConfig->getValue(self::TRANSLATION_LANGUAGE);
        return $status;
    }

    public function getTranslationProductAttribute()
    {
        $status = $this->scopeConfig->getValue(self::PRODUCT_ATTRIBUTE);
        return $status;
    }
    public function getProductStore()
    {
        $status = $this->scopeConfig->getValue(self::PRODUCT_STORE);
        return $status;
    }

    public function getSpanishEnable()
    {
        $status = $this->scopeConfig->getValue(self::SPANISH_ENABLE);
        return $status;
    }


}