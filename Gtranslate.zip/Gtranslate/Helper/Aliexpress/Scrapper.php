<?php

namespace Ced\Gtranslate\Helper\Aliexpress;

//require_once(__DIR__ . '/Aliexpress-API-master/simple_html_dom.php');

class Scrapper
{
    public function scrapProduct($url)
    {
        $data = false;
        try {
            $html = file_get_html($url);

            $links = [];
            foreach ($html->find('script') as $a) {
                if (strpos($a->innertext, 'skuProducts')) {
                    $variations_data = substr($a->innertext, strpos($a->innertext, 'var skuProducts='), strpos($a->innertext, 'var GaData'));
                    $variations_data = substr($variations_data, strpos($variations_data, '=') + 1, strpos($variations_data, 'var GaData'));
                    $variations_data = str_replace('var GaData = {', "", $variations_data);
                    $variations_data = str_replace('];', "]", $variations_data);
                    // print_r($variations_data);
                    $variation_products = json_decode($variations_data, true);
                }
                if (strpos($a->innertext, 'window.runParams.descUrl=')) {
                    $description = substr($a->innertext, strpos($a->innertext, 'window.runParams.descUrl='), strpos($a->innertext, 'window.runParams.crosslinkUrl'));
                    $description = substr($description, strpos($description, '=') + 1, strpos($description, 'window.runParams.crosslinkUrl'));
                    $description = substr($description, 0, strpos($description, '";'));
                    $description_url = str_replace('"//', "http://", $description);

                    $description = file_get_contents($description_url);
                    $description = str_replace("window.productDescription='", "", $description);
                    $description = substr($description, 0, strpos($description, "';"));
                }
                if (strpos($a->innertext, 'window.runParams.imageBigViewURL=')) {
                    $main_images = substr($a->innertext, strpos($a->innertext, 'window.runParams.imageBigViewURL='), (strpos($a->innertext, '];') - strpos($a->innertext, 'window.runParams.imageBigViewURL=')) + 1);

                    $main_images = trim(str_replace("window.runParams.imageBigViewURL=", "", $main_images));
                    $main_images = str_replace("[", "", $main_images);
                    $main_images = str_replace("]", "", $main_images);
                    $main_images = explode(",", $main_images);
                    foreach ($main_images as $images) {
                        $data['main_images'][] = trim(str_replace('"', '', $images));
                    }
                }
            }

            foreach ($html->find('h1[class="product-name"]') as $a) {
                $links[] = $this->clearEntities(trim($a->plaintext));
            }

            $title = isset($links[0]) ? $links[0] : '';

            $var1 = [];
            foreach ($html->find('a[id*="sku-1"]') as $a) {
                if ($a->title == "") {
                    $var1[$a->id] = strip_tags($a->innertext);
                } else {
                    $var1[$a->id] = strip_tags($a->title);
                    $var_img[$a->id] = $a->innertext;
                }
            }

            $var2 = [];
            foreach ($html->find('a[id*="sku-2"]') as $a) {
                // $var2[] = $a->title;
                if ($a->title == "") {
                    $var2[$a->id] = $a->innertext;
                } else {
                    $var2[$a->id] = strip_tags($a->title);
                    $var_img2[$a->id] = $a->innertext;
                }
            }

            $var3 = [];
            foreach ($html->find('a[id*="sku-3"]') as $a) {
                // $var2[] = $a->title;
                if ($a->title == "") {
                    $var3[$a->id] = strip_tags($a->innertext);
                } else {
                    $var3[$a->id] = strip_tags($a->title);
                    $var_img3[$a->id] = $a->innertext;
                }
            }

            $stringArray = [];
            $elements = $html->find('div[class="ui-breadcrumb"]');
            if (!empty($elements) and isset($elements[0])) {
                foreach ($html->find('div[class="ui-breadcrumb"]')[0]->children[0]->children as $childs) {
                    foreach ($childs as $a) {
                        if (is_object($a)) {
                            $string = strip_tags($a->innertext);
                            $stringArray = explode('&gt;', addcslashes($string, '>'));
                            $stringArray = array_map(function ($val) {
                                return trim($val);
                            }, $stringArray);
                            unset($stringArray[0]);
                            unset($stringArray[1]);
                            $stringArray = array_values($stringArray);
                        }
                    }
                }
            }


            $data['categories'] = $stringArray;

            $shipd = [];
            foreach ($html->find('li[class="packaging-item"]') as $a) {
                $shipd[] = $this->clearEntities($a->innertext);
            }

            $links = [];
            foreach ($html->find('span[id="j-sku-price"]') as $a) {
                $links[] = $this->clearEntities($a->innertext);
            }

            $price = $links[0];

            $length = count($var1);
            $xvar1 = "";
            $xvar2 = "";
            $xvar3 = "";

            // for ($i = 0; $i < $length-1; $i++) {
            //      $xvar1 =  $xvar1 . strip_tags($var1[$i]) . "|" ;
            // }
            // $xvar1 =  $xvar1 . strip_tags($var1[$i]) ;

            $url = explode("?", $url);
            $url = $url['0'];

            $data['url'] = $url;
            $data['title'] = $title;
            $data['price'] = $price;

            if (is_array($variation_products) && !empty($variation_products)) {
                $data['variation_products'] = $variation_products;
            }

            foreach ($html->find('span[class="percent-num"]') as $a) {
                $data['rating'][] = $this->clearEntities(trim($a->plaintext));
            }

            foreach ($html->find('span[class="order-num"]') as $a) {
                $data['orders'][] = $this->clearEntities(trim($a->plaintext));
            }

            // $data['variation1'] = $xvar1;
            $data['variation1'] = $var1;
            $data['variation2'] = $var2;
            $data['variation3'] = $var3;

            // $length = count($var2);
            // for ($i = 0; $i < $length-1; $i++) {
            //  $xvar2 =  $xvar2. strip_tags($var2[$i]) . "|" ;
            // }
            // $xvar2 =  $xvar2 . strip_tags($var2[$i]) ;

            // // $data['variation2'] = $xvar2;

            // $length = count($var3);
            // for ($i = 0; $i < $length-1; $i++) {
            //  $xvar3 =  $xvar3. strip_tags($var3[$i]) . "|" ;
            // }
            // $xvar3 =  $xvar3 . strip_tags($var3[$i]) ;

            // $data['variation3'] = $xvar3;


            foreach ($html->find('li[class="property-item"]') as $a) {
                $custom = explode(':', $a->plaintext);
                $data['property-item'][$this->clearEntities(trim($custom[0]))] = $this->clearEntities(trim($custom[1]));
            }

            foreach ($var1 as $key => $value) {
                $temp = 'img[title="' . $value . '"]';
                foreach ($html->find($temp) as $a) {
                    $data['images_variation1'][$a->parent->id] = $a->bigpic;
                    break;
                }
            }

            foreach ($var2 as $key => $value) {
                $temp = 'img[title="' . $value . '"]';
                foreach ($html->find($temp) as $a) {
                    $data['images_variation2'][$a->parent->id] = $a->bigpic;
                    break;
                }
            }

            foreach ($var3 as $key => $value) {
                $temp = 'img[title="' . $value . '"]';
                foreach ($html->find($temp) as $a) {
                    $data['images_variation3'][$a->parent->id] = $a->bigpic;
                    break;
                }
            }

            foreach ($html->find('ul[id*="j-sku-list"]') as $a) {
                $data['attribute_id'][] = $a->getAttribute('data-sku-prop-id');
            }

            /*foreach($html->find('[class="p-item-title"]') as $a) {
                $data['attributes'][] = $a->innertext;
            }*/

            foreach ($html->find('[id="j-product-info-sku"]') as $a) {
                foreach ($a->find('dt') as $aa) {
                    $data['attr_name'][] = $this->clearEntities(strip_tags($aa->innertext));
                }

                foreach ($a->find('ul[id*="j-sku-list"]') as $aa) {
                    $data['test']['attr_id'][] = $aa->getAttribute('data-sku-prop-id');
                    foreach ($aa->find('a[id*="sku-"]') as $aaa) {
                        if ($aaa->title == "") {
                            $data['attr_taxonomies'][$aa->getAttribute('data-sku-prop-id')][$aaa->id] = $this->clearEntities(strip_tags($aaa->title));
                        } else {
                            $data['attr_taxonomies'][$aa->getAttribute('data-sku-prop-id')][$aaa->id] = $this->clearEntities(strip_tags($aaa->title));
                            // $var1[$aaa->id] = strip_tags($aaa->title);
                            // $var_img[$aaa->id] = $aaa->innertext;
                        }
                    }
                }

                if (isset($data['attr_name']) && isset($data['attribute_id']) && is_array($data['attribute_id'])
                    && !empty($data['attribute_id']) && is_array($data['attr_name']) && !empty($data['attr_name'])) {
                    $data['variation_attributes'] = array_combine($data['attribute_id'], $data['attr_name']);
                }
                /*if( isset($description) && ( $description != "" || !empty($description) ) )
                    $data['description'] = $description;
                else*/
                $data['description'] = "Imported Products from Aliexpress";
            }
            foreach ($html->find('ul[class="product-packaging-list util-clearfix"]') as $aa) {
                foreach ($aa->find('li[class="packaging-item"]') as $aaa) {
                    foreach ($aaa->find('span[class="packaging-title"]') as $a) {
                        $packaging_title = trim($this->clearEntities($a->plaintext));
                    }
                    $packaging_title = str_replace(':', '', $packaging_title);
                    foreach ($aaa->find('span[class="packaging-des"]') as $a) {
                        $data[$packaging_title] = trim($this->clearEntities($a->plaintext));
                    }
                }
            }
        } catch (\Exception $e) {
        }

        return $data;
    }

    public function clearEntities($value)
    {
        return html_entity_decode($value, ENT_COMPAT, 'UTF-8');
    }
}
