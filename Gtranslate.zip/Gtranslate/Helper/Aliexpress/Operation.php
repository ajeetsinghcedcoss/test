<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement (EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @category  Ced
 * @package   Ced_Gtranslate
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE (http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 */
namespace Ced\Gtranslate\Helper\Aliexpress;

use AliexApi\Configuration\GenericConfiguration;
use AliexApi\AliexIO;
use AliexApi\Operations\GetProductDetail;
use AliexApi\Operations\ListProducts;

class Operation
{
    private $service = "AWSECommerceService"; // #todo : can provide option via confifuration to pick values
    private $responseGroup = "Images,ItemAttributes,Reviews,BrowseNodes,Offers,OfferSummary";
    private $availability = "Available";
    private $endPoint = ""; // get data from drop down configuration
    private $urlAppend = "/onca/xml";
    private $finalUrl = "";
    public $_curl;
    protected $_config;
    protected $aliexIO;
    protected $listproducts;
    protected $getProductDetail;

    public $secretKey;
    public $keyId;
    public $total;
    /**
     * @var \Magento\Framework\Json\DecoderInterface
     */
    protected $jsonDecoder;

    public function __construct(
        \Magento\Framework\HTTP\Adapter\Curl $curl,
        \Magento\Framework\Json\DecoderInterface $jsonDecoder,
        \Magento\Framework\Json\EncoderInterface $jsonEncoder,
        \Magento\Framework\ObjectManagerInterface $objectManager,
        \Magento\Backend\App\ConfigInterface $config,
        \Ced\Gtranslate\Helper\Logger $logger
    ) {
        $this->_resource = $curl;
        $this->total = false;
        $this->_config = $config;
        $this->jsonDecoder = $jsonDecoder;
        $this->jsonEncoder = $jsonEncoder;
        $this->_objectManager = $objectManager;
        $this->_logger = $logger;
        $this->_scopeConfigManager = $this->_objectManager
            ->get('\Magento\Framework\App\Config\ScopeConfigInterface');
        $this->apiKey = $this->_scopeConfigManager->getValue('gtranslate/general/api_key');
        $this->trackingId = $this->_scopeConfigManager->getValue('gtranslate/general/tracking_id');
    }

    public function send()
    {
        $url= $this->finalUrl;
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_FAILONERROR, 1);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_TIMEOUT, 15);
        $retValue = curl_exec($ch);
        curl_close($ch);
        $simpleXml = simplexml_load_string($retValue);
        $jsonResponse = $this->jsonEncoder->encode($simpleXml);
        $response  = $this->jsonDecoder->decode($jsonResponse, true);
        $this->_logger->info(date("Y-m-d H:i:s")." Aliexpress-Affiliate Call Before");
        sleep($this->throttleLimit);
        $this->_logger->info(date("Y-m-d H:i:s")." Aliexpress-Affiliate Call After");
        return $response;
    }

    public function searchAliexpressProduct($keyterms, $searchIndex = '', $itemPage = '', $brand = '')
    {
        if ($searchIndex != '') {
            $this->total = $searchIndex;
        }

        $response = $this->listPromotionProduct($keyterms, $itemPage);
        return $response;
    }

    public function searchAliexpressProductById($itemId)
    {
        $this->prepareAll(true);
        $this->getProductDetail->setFields(
            'totalResults,productId,productTitle,productUrl,imageUrl,allImageUrls,'
            . 'originalPrice,salePrice,discount,evaluateScore,commission,'
            . 'commissionRate,30daysCommission,volume,packageType,'
            . 'lotNum,validTime'
        );
        $this->getProductDetail->setProductId($itemId);
        $formattedResponse =  $this->aliexIO->runOperation($this->getProductDetail);

        $array = json_decode($formattedResponse, true);

        return $array;
    }

    protected function aliconfig($conf)
    {
        $conf
            ->setApiKey($this->apiKey)
            ->setTrackingKey($this->trackingId)
            ->setDigitalSign('');
        return $conf;
    }

    protected function prepareAll($bool = false)
    {
        $conf = new GenericConfiguration();
        $this->aliconfig($conf);
        $this->aliexIO = new AliexIO($conf);
        if ($bool) {
            $this->getProductDetail = new GetProductDetail();
            return;
        }
        $this->listproducts = new ListProducts();
    }

    protected function listPromotionProduct($keywords, $pageNumber = '', $brand = '')
    {
        $this->prepareAll();
        $this->listproducts->setFields(
            'totalResults,productId,productTitle,productUrl,imageUrl,allImageUrls,'
            . 'originalPrice,salePrice,discount,evaluateScore,commission,'
            . 'commissionRate,30daysCommission,volume,packageType,'
            . 'lotNum,validTime'
        );
        $this->listproducts->setKeywords($keywords);
        $this->listproducts->setPageSize(20);
        if ($pageNumber) {
            $this->listproducts->setPageNo($pageNumber);
        }
        $this->listproducts->setHighQualityItems('true');
        $formattedResponse =  $this->aliexIO->runOperation($this->listproducts);
		$response = [];
        $array = json_decode($formattedResponse, true);
        if (isset($array['result']['totalResults'])) {
            if ($pageNumber != '') {
                return $array;
            }
            $totalRecords = min($array['result']['totalResults'], $this->total);
            $i = 2;
            while ($i <= $totalRecords/20 /*&& $i <= $this->total*/) {
                $array = array_merge_recursive($array, $this->listPromotionProduct($keywords, $i));
                $i++;
            }
			$response = $array;
        }
        return $response;
    }

    public function categoryProducts($aObj, $browseNodeId, $categoryName, $page)
    {
        $timestamp = gmdate('Y-m-d\TH:i:s\Z');
        $requestData = [
            "AssociateTag" => $this->associateTag,
            "AWSAccessKeyId" => $this->keyId,
            "Service" => $this->service,
            "Operation" => "ItemSearch",
            "SearchIndex" => $categoryName,
            "BrowseNode" => $browseNodeId,
            "Timestamp" => $timestamp,
            "Availability" => $this->availability,
            "ResponseGroup" => $this->responseGroup,
            "ItemPage" => $page
        ];
        ksort($requestData);
        $urlContent = [];
        foreach ($requestData as $key => $value) {
            array_push($urlContent, rawurlencode($key)."=".rawurlencode($value));
        }
        $urlPre = join("&", $urlContent);
        $urlPost = "GET\n".$this->endPoint."\n".$this->urlAppend."\n".$urlPre;
        $signature = base64_encode(hash_hmac("sha256", $urlPost, $this->secretKey, true));
        $this->finalUrl = 'http://'.$this->endPoint.$this->urlAppend.'?'.$urlPre.'&Signature='.rawurlencode($signature);
        return $this;
    }

    public function getProductbyUrl($url)
    {
        $timestamp = gmdate('Y-m-d\TH:i:s\Z');
        $requestData = [
            "AssociateTag" => $this->associateTag,
            "AWSAccessKeyId" => $this->keyId,
            "Service" => $this->service,
            "Operation" => "ItemLookup",
            "ItemId" => '',
            "IdType" => "ASIN",
            "Timestamp" => $timestamp,
            "ResponseGroup" => $this->responseGroup,
        ];
        ksort($requestData);
        $urlContent = [];
        foreach ($requestData as $key => $value) {
            array_push($urlContent, rawurlencode($key)."=".rawurlencode($value));
        }
        $urlPre = join("&", $urlContent);
        $urlPost = "GET\n".$this->endPoint."\n".$this->urlAppend."\n".$urlPre;
        $signature = base64_encode(hash_hmac("sha256", $urlPost, $this->secretKey, true));
        $this->finalUrl = 'http://'.$this->endPoint.$this->urlAppend.'?'.$urlPre.'&Signature='.rawurlencode($signature);

        return $this;
    }

    public function init()
    {
        $this->_customerSession = $this->_objectManager->get('Magento\Customer\Model\Session');
        if (!$this->_customerSession->getCartId() || !$this->_customerSession->getCartHmac()) {
            if ($this->_customerSession->isLoggedIn()) {
                $customer = $this->_customerSession->getCustomer();
                $this->_customerSession->setCartId($customer->getCartId());
                $this->_customerSession->setCartHmac($customer->getCartHmac());
            }
        }
        return $this;
    }


    public function addToCart($asin, $qty)
    {

        if ($this->_customerSession->getCartId() && $this->_customerSession->getCartHmac()) {
            if ($this->_customerSession->isLoggedIn()) {
                $customer = $this->_customerSession->getCustomer();

                if ($this->_customerSession->getCartId()!=$customer->getCartId() || $this->_customerSession->getCartHmac()!=$customer->getCartHmac()) {
                    $customer->setCartHmac($this->_customerSession->getCartHmac());
                    $customer->setCartId($this->_customerSession->getCartId());
                    $customer->save();
                    $response = $this->addToAliexpressCart($asin, $qty);
                } else {
                    $response = $this->addToAliexpressCart($asin, $qty);
                }
            } else {
                $this->_logger->addDebug('guest customer cart id found in session');
                $response = $this->addToAliexpressCart($asin, $qty);
            }
        } else {
            if ($this->_customerSession->isLoggedIn()) {
                $customer = $this->_customerSession->getCustomer();
                if ($customer->getCartId() && $customer->getCartHmac()) {
                    /*cart id found in customer object */
                    $this->_customerSession->setCartId($customer->getCartId());
                    $this->_customerSession->setCartHmac($customer->getCartHmac());
                    $response = $this->addToAliexpressCart($asin, $qty);
                } else {
                    /* customer logged in and cart not saved in customer */
                    $this->_logger->addDebug('Customer logged in and cart not found for customer : Creating New Cart ');
                    $response = $this->createCart($asin, $qty);
                }
            } else {
                $this->_logger->addDebug('Guest Customer Creating New Cart ');
                /* customer not logged in and cart not found in session*/
                $response = $this->createCart($asin, $qty);
            }
        }

        return $response;

        return $this;
    }


    public function createCart($asin, $qty)
    {
        $timestamp = gmdate('Y-m-d\TH:i:s\Z');
        $requestData = [

            "AWSAccessKeyId" => $this->keyId,
            "Service" => $this->service,
            "Operation" => "CartCreate",
            "Item.1.ASIN" => $asin,
            "Item.1.Quantity" => $qty,
            "Timestamp" => $timestamp,
            "ResponseGroup" => 'Cart',
            "AssociateTag" => $this->associateTag,
        ];



        ksort($requestData);
        $urlContent = [];
        foreach ($requestData as $key => $value) {
            array_push($urlContent, rawurlencode($key)."=".rawurlencode($value));
        }

        $urlPre = join("&", $urlContent);
        $urlPost = "GET\n".$this->endPoint."\n".$this->urlAppend."\n".$urlPre;

        $signature = base64_encode(hash_hmac("sha256", $urlPost, $this->secretKey, true));

        $this->finalUrl = 'http://'.$this->endPoint.$this->urlAppend.'?'.$urlPre.'&Signature='.rawurlencode($signature);
        $response = $this->send();
        if (isset($response['Cart']) && isset($response['Cart']['Request']) && isset($response['Cart']['Request']['IsValid']) && isset($response['Cart']['CartId']) && !isset($response['Cart']['Request']['Errors'])) {
            $this->_customerSession->setCartId($response['Cart']['CartId']);
            $this->_customerSession->setCartHmac($response['Cart']['HMAC']);
            if ($this->_customerSession->isLoggedIn()) {
                $customer = $this->_customerSession->getCustomer();
                $customer->setCartId($response['Cart']['CartId']);
                $customer->setCartHmac($response['Cart']['HMAC']);
                $customer->save();
            }
            $cart = [];
            $summary_count = 0;
            if (isset($response['Cart']['CartItems']['CartItem'][0])) {
                foreach ($response['Cart']['CartItems']['CartItem'] as $itemData) {
                    $cart[$itemData['ASIN']] = $itemData;
                    $summary_count += $itemData['Quantity'];
                }
            } elseif (isset($response['Cart']['CartItems']['CartItem']['CartItemId'])) {
                $cart[$response['Cart']['CartItems']['CartItem']['ASIN']] = $response['Cart']['CartItems']['CartItem'];
                $summary_count += $response['Cart']['CartItems']['CartItem']['Quantity'];
            }
            if (isset($response['Cart']['CartItems'])) {
                return ['success'=> true,'cart'=>['summary_count'=>$summary_count,'items'=>$cart,'subtotal'=>$response['Cart']['CartItems']['SubTotal']],'response'=>$response];
            }

            return ['success'=> true,'cart'=>[],'response'=>$response];
        } elseif (isset($response['Cart']['Request']['Errors'])) {
            $this->_logger->addDebug(print_r($response, true));
            return ['success'=> true,'cart'=>[],'response'=>$response];
        } else {
            /* throw error */
            $this->_logger->addDebug(print_r($response, true));
            return ['success'=> false,'errors'=>$response['Cart']['Request']['Errors'],'response'=>$response];
        }
    }


    public function addToAliexpressCart($asin, $qty)
    {

        if ($cart = $this->getCart()) {
            if ($cart['success']) {
                $cart = isset($cart['cart']['items']) ? $cart['cart']['items'] : [];
                if (isset($cart[$asin])) {
                    if ($qty!=0) {
                        $qty = (int)$qty+(int)$cart[$asin]['Quantity'];
                    }
                    $cart = $this->modifyCart($asin, $qty, $cart[$asin]['CartItemId']);
                } else {
                    $cart = $this->addNewItemToCart($asin, $qty);
                }
                return $cart;
            } else {
                $this->_logger->addDebug('not found requested cart on aliexpress so create new cart');
                if ($response = $this->createCart($asin, $qty)) {
                    return $response;
                } else {
                    return $response;
                }
            }
        }
    }

    public function modifyCart($asin, $qty, $cartItemId)
    {
        if ($this->_customerSession->getCartId() && $this->_customerSession->getCartHmac()) {
            $timestamp = gmdate('Y-m-d\TH:i:s\Z');
            $requestData = [

                "AWSAccessKeyId" => $this->keyId,
                "Service" => $this->service,
                "Operation" => "CartModify",
                "CartId" => $this->_customerSession->getCartId(),
                "HMAC" => $this->_customerSession->getCartHmac(),
                "Item.1.ASIN" => $asin,
                "Item.1.Quantity" => $qty,
                "Item.1.CartItemId" => $cartItemId,
                "Timestamp" => $timestamp,
                "ResponseGroup" => 'Cart',
                "AssociateTag" => $this->associateTag,
            ];



            ksort($requestData);
            $urlContent = [];
            foreach ($requestData as $key => $value) {
                array_push($urlContent, rawurlencode($key)."=".rawurlencode($value));
            }

            $urlPre = join("&", $urlContent);
            $urlPost = "GET\n".$this->endPoint."\n".$this->urlAppend."\n".$urlPre;

            $signature = base64_encode(hash_hmac("sha256", $urlPost, $this->secretKey, true));

            $this->finalUrl = 'http://'.$this->endPoint.$this->urlAppend.'?'.$urlPre.'&Signature='.rawurlencode($signature);
            $response = $this->send();

            if (isset($response['Cart']) && isset($response['Cart']['Request']) && isset($response['Cart']['Request']['IsValid']) && isset($response['Cart']['CartId']) && !isset($response['Cart']['Request']['Errors'])) {
                $cart = [];
                $summary_count = 0;
                if (isset($response['Cart']['CartItems']['CartItem'][0])) {
                    foreach ($response['Cart']['CartItems']['CartItem'] as $itemData) {
                        $cart[$itemData['ASIN']] = $itemData;
                        $summary_count += $itemData['Quantity'];
                    }
                } elseif (isset($response['Cart']['CartItems']['CartItem']['CartItemId'])) {
                    $cart[$response['Cart']['CartItems']['CartItem']['ASIN']] = $response['Cart']['CartItems']['CartItem'];
                    $summary_count += $response['Cart']['CartItems']['CartItem']['Quantity'];
                }
                if (isset($response['Cart']['CartItems'])) {
                    return ['success'=> true,'cart'=>['summary_count'=>$summary_count,'items'=>$cart,'subtotal'=>$response['Cart']['CartItems']['SubTotal']],'response'=>$response];
                }

                return ['success'=> true,'cart'=>[],'response'=>$response];
            } else {
                return ['success'=> false,'errors'=>$response['Cart']['Request']['Errors'],'response'=>$response];
            }
        }
    }

    public function addNewItemToCart($asin, $qty)
    {
        if ($this->_customerSession->getCartId() && $this->_customerSession->getCartHmac()) {
            $timestamp = gmdate('Y-m-d\TH:i:s\Z');
            $requestData = [

                "AWSAccessKeyId" => $this->keyId,
                "Service" => $this->service,
                "Operation" => "CartAdd",
                "CartId" => $this->_customerSession->getCartId(),
                "HMAC" => $this->_customerSession->getCartHmac(),
                "Item.1.ASIN" => $asin,
                "Item.1.Quantity" => $qty,
                "Timestamp" => $timestamp,
                "ResponseGroup" => 'Cart',
                "AssociateTag" => $this->associateTag,
            ];

            ksort($requestData);
            $urlContent = [];
            foreach ($requestData as $key => $value) {
                array_push($urlContent, rawurlencode($key)."=".rawurlencode($value));
            }

            $urlPre = join("&", $urlContent);
            $urlPost = "GET\n".$this->endPoint."\n".$this->urlAppend."\n".$urlPre;

            $signature = base64_encode(hash_hmac("sha256", $urlPost, $this->secretKey, true));

            $this->finalUrl = 'http://'.$this->endPoint.$this->urlAppend.'?'.$urlPre.'&Signature='.rawurlencode($signature);
            $response = $this->send();

            if (isset($response['Cart']) && isset($response['Cart']['Request']) && isset($response['Cart']['Request']['IsValid']) && isset($response['Cart']['CartId']) && !isset($response['Cart']['Request']['Errors'])) {
                $cart = [];
                $summary_count = 0;
                if (isset($response['Cart']['CartItems']['CartItem'][0])) {
                    foreach ($response['Cart']['CartItems']['CartItem'] as $itemData) {
                        $cart[$itemData['ASIN']] = $itemData;
                        $summary_count += $itemData['Quantity'];
                    }
                } elseif (isset($response['Cart']['CartItems']['CartItem']['CartItemId'])) {
                    $cart[$response['Cart']['CartItems']['CartItem']['ASIN']] = $response['Cart']['CartItems']['CartItem'];
                    $summary_count += $response['Cart']['CartItems']['CartItem']['Quantity'];
                }
                if (isset($response['Cart']['CartItems'])) {
                    return ['success'=> true,'cart'=>['summary_count'=>$summary_count,'items'=>$cart,'subtotal'=>$response['Cart']['CartItems']['SubTotal']],'response'=>$response];
                }

                return ['success'=> true,'cart'=>[],'response'=>$response];
            } else {
                return ['success'=> false,'errors'=>$response['Cart']['Request']['Errors'],'response'=>$response];
            }
        }
    }


    public function getCart()
    {

        if ($this->_customerSession->getCartId() && $this->_customerSession->getCartHmac()) {
            $timestamp = gmdate('Y-m-d\TH:i:s\Z');
            $requestData = [

                "AWSAccessKeyId" => $this->keyId,
                "Service" => $this->service,
                "Operation" => "CartGet",
                "CartId" => $this->_customerSession->getCartId(),
                "HMAC" => $this->_customerSession->getCartHmac(),
                "Timestamp" => $timestamp,
                "ResponseGroup" => 'Cart',
                "AssociateTag" => $this->associateTag,
            ];



            ksort($requestData);
            $urlContent = [];
            foreach ($requestData as $key => $value) {
                array_push($urlContent, rawurlencode($key)."=".rawurlencode($value));
            }

            $urlPre = join("&", $urlContent);
            $urlPost = "GET\n".$this->endPoint."\n".$this->urlAppend."\n".$urlPre;

            $signature = base64_encode(hash_hmac("sha256", $urlPost, $this->secretKey, true));

            $this->finalUrl = 'http://'.$this->endPoint.$this->urlAppend.'?'.$urlPre.'&Signature='.rawurlencode($signature);
            $response = $this->send();

            if (isset($response['Cart']) && isset($response['Cart']['Request']) && isset($response['Cart']['Request']['IsValid']) && isset($response['Cart']['CartId']) && !isset($response['Cart']['Request']['Errors'])) {
                $cart = [];
                $summary_count = 0;
                if (isset($response['Cart']['CartItems']['CartItem'][0])) {
                    foreach ($response['Cart']['CartItems']['CartItem'] as $itemData) {
                        $cart[$itemData['ASIN']] = $itemData;
                        $summary_count += $itemData['Quantity'];
                    }
                } elseif (isset($response['Cart']['CartItems']['CartItem']['CartItemId'])) {
                    $cart[$response['Cart']['CartItems']['CartItem']['ASIN']] = $response['Cart']['CartItems']['CartItem'];
                    $summary_count += $response['Cart']['CartItems']['CartItem']['Quantity'];
                }
                if (isset($response['Cart']['CartItems'])) {
                    return ['success'=> true,'cart'=>['summary_count'=>$summary_count,'items'=>$cart,'subtotal'=>$response['Cart']['CartItems']['SubTotal']],'response'=>$response];
                }
                return ['success'=> true,'cart'=>[],'response'=>$response];
            } else {
                return ['success'=> false,'errors'=>$response['Cart']['Request']['Errors'],'response'=>$response];
            }
        }
        return ['success'=> true,'cart'=>[],'response'=>[]];
    }
}
