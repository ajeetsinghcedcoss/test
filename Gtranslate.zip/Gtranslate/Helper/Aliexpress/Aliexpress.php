<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement (EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @category  Ced
 * @package   Ced_Gtranslate
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE (http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 */

namespace Ced\Gtranslate\Helper\Aliexpress;
ini_set('display_errors', 1);

class Aliexpress
{
    const ACCESS_KEY_ID = 'gtranslate/general/api_key';
    const TRACKING_ID = 'gtranslate/general/tracking_id';
    const SECRET_ACCESS_KEY = 'gtranslate/general/secret_key';

    public $objectmanager;

    public $_aliexpressProductData;

    public $configHelper;

    /*
     * Public scrapper
     */
    public $scrapper;

    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Ced\Gtranslate\Helper\Aliexpress\Scrapper $scrapper,
        \Ced\Gtranslate\Helper\Config $configHelper

    )
    {
        $this->_objectManager = $context->getObjectManager();
        $this->scopeConfig = $scopeConfig;
        $this->scrapper = $scrapper;
        $this->configHelper = $configHelper;

    }

    public function callOperation($operation, $searchData = [])
    {
        if (!empty($operation)) {
            $searchObj = $this->_objectManager
                ->create('Ced\Gtranslate\Helper\Aliexpress\Operation');
        } else {
            return [
                'error' => 'Please fill api , tag and secret key from configuration',
                'msg' => 'Please specify operation to perform .'
            ];
        }

        switch ($operation) {
            case 'search_product':
                $itemPage = isset($searchData['item_page']) ? $searchData['item_page'] : 1;
                $category = isset($searchData['aliexpress_category']) ? $searchData['aliexpress_category'] : 'All';
                $brand = isset($searchData['brand']) ? $searchData['brand'] : 'none';
                $response = $searchObj->searchAliexpressProduct(
                    $searchData['keyterms'],
                    $category,
                    $itemPage,
                    $brand
                );

                if (!$response) {
                    return ['error' => 'Aliexpress : Throttle Limit Exceeded. Please try after some time.'];
                }
                $arrayResponse = $this->toArray($response);

                return $arrayResponse;
                break;
            case 'search_url':
                $url = $searchData['url'];
                $parts = explode('.html', $url);

                $itemId = substr($parts[0], strrpos($parts[0], '/') + 1);

                $response = $searchObj->searchAliexpressProductById($itemId);

                if (!$response) {
                    return [
                        'error' => 'Aliexpress : Throttle Limit Exceeded. Please try after some time.'
                    ];
                }
                $arrayResponse = $this->toArray($response, false, ['url' => $url, 'itemId' => $itemId]);
                return $arrayResponse;
                break;
            case 'search_file':
                        $searchData = trim($searchData);
                        $parts = explode('.html', $searchData);
                        $itemId = substr($parts[0], strrpos($parts[0], '/') + 1);
                        $response = $searchObj->searchAliexpressProductById($itemId);
                        if (!$response) {
                            return [
                                'error' => 'Aliexpress : Throttle Limit Exceeded. Please try after some time.'
                            ];
                        }
                        $arrayResponse[] = $this->toArray($response, false, ['url' => $searchData, 'itemId' => $itemId]);
                return $arrayResponse;
                break;
            case 'scrap_product':
                $response = [];

                $response['result']['products'] = $searchData;
                $arrayResponse = $this->toArray($response);

                return $arrayResponse;

                break;
            case 'scrap_partial' :
                $scrapper = $this->_objectManager
                    ->create('Ced\Gtranslate\Helper\Aliexpress\Scrapper');
                $response = $this->extractCustomInfo(
                    $scrapper->scrapProduct($searchData['aliexpress_product_url']),
                    array('productId' => $searchData['sku'])
                );
                return $response;
            default:
                return ['error' => 'Invalid aliexpress operation passed'];
                break;
        }
    }

    public function getConfigValue($path)
    {
        return $this->scopeConfig->getValue($path);
    }

    private function toArray($aliexpressResponse, $flag = true, $url = '')
    {
        $spanishItem = '';
        $englishItem = '';

        $arrayResponse = [];
        if ($flag) {
            if (isset($aliexpressResponse['result']['products'])) {
                foreach ($aliexpressResponse['result']['products'] as $item) {
                    if (isset($item['productUrl'])) {
                        $scrappedItem = $this->scrapper->scrapProduct($item['productUrl']);

                        $englishItem = $this->extractInfo($scrappedItem, $item);

                        if (!$this->configHelper->getSpanishEnable()) {
                            if ($this->configHelper->getTranslationEnable() && $this->configHelper->getTranslationLanguage() !== 'english') {
                                $spanishItem = $this->translate($englishItem);
                            }
                        } else {
                            $item['productUrl'] = str_replace('www', 'es', $item['productUrl']);
                            $scrappedItem = $this->scrapper->scrapProduct($item['productUrl']);

                            $spanishItem = $this->extractInfo($scrappedItem, $item);
                        }

                        //                        $arrayResponse[] = $this->clubResponse($spanishItem,$englishItem);
                        $arrayResponse[] = [
                            'spanish' => $spanishItem,
                            'english' => $englishItem
                        ];
                    }
                }
            } else {
                if (!isset($aliexpressResponse['errorCode'])) {
                    $arrayResponse['error'] = 'Aliexpress APi didnt gave any response for the query';
                    return $arrayResponse;
                }
                $arrayResponse['error'] = $this->getError($aliexpressResponse['errorCode']);
            }
        } else {
            if (isset($aliexpressResponse['result'])) {
                $item = $aliexpressResponse['result'];
                $scrappedItem = $this->scrapper->scrapProduct($item['productUrl']);
                $englishItem = $this->extractInfo($scrappedItem, $item);
                if (!$this->configHelper->getSpanishEnable()) {
                    if ($this->configHelper->getTranslationEnable() && $this->configHelper->getTranslationLanguage() !== 'english') {
                        $spanishItem = $this->translate($englishItem);
                    }
                } else {
                    $item['productUrl'] = str_replace('www', 'es', $item['productUrl']);
                    $scrappedItem = $this->scrapper->scrapProduct($item['productUrl']);
                    $spanishItem = $this->extractInfo($scrappedItem, $item);
                }
                $arrayResponse[] = [
                    'spanish' => $spanishItem,
                    'english' => $englishItem
                ];
            } elseif (isset($url['url'], $url['itemId'])) {
                $item = [];
                $scrappedItem = $this->scrapper->scrapProduct($url['url']);
                $item['productId'] = $url['itemId'];
                $item['price'] = isset($scrappedItem['price']) ? $scrappedItem['price'] : 0;
                $item['productUrl'] = $url['url'];
                $englishItem = $this->extractInfo($scrappedItem, $item);

                if (!$this->configHelper->getSpanishEnable()) {
                    if ($this->configHelper->getTranslationEnable() && $this->configHelper->getTranslationLanguage() !== 'english') {
                        $spanishItem = $this->translate($englishItem);
                    }
                } else {
                    $item['productUrl'] = str_replace('www', 'es', $item['productUrl']);
                    $scrappedItem = $this->scrapper->scrapProduct($item['productUrl']);
                    $spanishItem = $this->extractInfo($scrappedItem, $item);
                }

                $arrayResponse[] = [
                    'spanish' => $spanishItem,
                    'english' => $englishItem
                ];
            } else {
                $arrayResponse['error'] = $this->getError($aliexpressResponse['errorCode']);
            }
        }

        return $arrayResponse;
    }


    /*
     *
     */
    public function translate($scrappedItem)
    {

        $attributes = explode(',', $this->configHelper->getTranslationProductAttribute());

        foreach ($attributes as $attribute) {
            if (isset($scrappedItem[$attribute])) {

                if (is_array($scrappedItem[$attribute])) {
                    foreach ($scrappedItem[$attribute] as $key => $value) {
                        $scrappedItem[$attribute][$key] = $this->googleTransleteData($value);
                    }
                } else {
                    $scrappedItem[$attribute] = $this->googleTransleteData($scrappedItem[$attribute]);
                }

            } else if ($attribute == 'attributes' && isset($scrappedItem['variationData']['variant']['variantdata'])) {
                foreach ($scrappedItem['variationData']['variant']['variantdata'] as $key => $item) {
                    if (is_array($item) && isset($item['attributes'])) {
                        foreach ($item['attributes'] as $key1 => $value1) {

                            if (isset($value1['name'])) {
                                $scrappedItem['variationData']['variant']['variantdata'][$key]['attributes']
                                [$key1]['name'] = $this->googleTransleteData($value1['name']);
                            }
                            if (isset($value1['value'])) {
                                $scrappedItem['variationData']['variant']['variantdata'][$key]['attributes']
                                [$key1]['value'] = $this->googleTransleteData($value1['value']);
                            }

                        }
                    }
                }

            }
        }
        return $scrappedItem;
    }

    /*
     * Fucntion toArray
     */
    protected function extractInfo($scrappedItem, $item)
    {

        if (isset($item['productId']) || isset($scrappedItem['title'])) {
            try {
                $individualItem = [];
                $individualItem['name'] = isset($scrappedItem['title']) ? strip_tags($scrappedItem['title'])
                    : strip_tags($item['title']);
                $individualItem['name'] = html_entity_decode($individualItem['name'], ENT_COMPAT, 'UTF-8');
                $individualItem['productId'] = $item['productId'];
                $individualItem['aliexpress_product_url'] = $item['productUrl'];


                $fullDescription = $this->prepareDescription($scrappedItem);
                $individualItem['description'] = !empty($fullDescription['desc']) ? $fullDescription['desc'] : '';
                $individualItem['short_description'] = !empty($fullDescription['short_desc']) ?
                    $fullDescription['short_desc'] : '';
                $individualItem['categories'] = $scrappedItem['categories'];

                $price = 0.00;
                if (isset($item['discount'])
                    && (trim($item['discount']) != '0%')
                ) {
                    $salePrice = explode(' ', $item['salePrice']);
                    $salePrice['1'] = str_replace('$', '', $salePrice['1']);
                    $price = (float)$salePrice['1'];
                } elseif (isset($item['originalPrice'])) {
                    $salePrice = explode(' ', $item['originalPrice']);
                    $salePrice['1'] = str_replace('$', '', $salePrice['1']);
                    $price = (float)$salePrice['1'];
                } elseif (isset($scrappedItem['price'])) {
                    $price = $scrappedItem['price'];
                }
                $individualItem['price'] = $price;
                $mainImage = isset($scrappedItem['main_images'][0]) ? $scrappedItem['main_images'][0] : '';
                $individualItem['type'] = 'simple';
                $images = [];
                //check for variation , if found type = configurable
                if (isset($scrappedItem['variation1']) && !empty($scrappedItem['variation1'])) {
                    $individualItem['type'] = 'configurable';
                    $variant_products = (isset($scrappedItem['variation_products'])) ? $scrappedItem['variation_products'] : "";
                    $first_variation_sku = (isset($scrappedItem['variation1'])) ? $scrappedItem['variation1'] : "";
                    $second_variation_sku = (isset($scrappedItem['variation2'])) ? $scrappedItem['variation2'] : "";
                    $variantdata['description'] = (isset($scrappedItem['property-item'])) ? $scrappedItem['property-item'] : "";
                    $variantdata['attribute_name'] = (isset($scrappedItem['attr_name'])) ? $scrappedItem['attr_name'] : "";
                    $variantdata['images'] = (isset($scrappedItem['images_variation1'])) ? $scrappedItem['images_variation1'] : "";

                    $variants = ['variants' => ''];

                    foreach ($variant_products as $keyvar => $valuevar) {
                        $skuIds = explode(",", $valuevar['skuPropIds']); // getting defined skuids for product
                        foreach ($first_variation_sku as $keysku => $valsku) {
                            $temp = explode("-", $keysku);
                            $keysku1 = $temp['2'];
                            if (isset($second_variation_sku, $scrappedItem['attr_name'][1])) {
                                foreach ($second_variation_sku as $seckey => $secval) {
                                    $temp2 = explode("-", $seckey);
                                    $keysku2 = $temp2['2'];
                                    if (($keysku1 == $skuIds['0']) && ($keysku2 == $skuIds['1'])) {
                                        $calprice = isset($valuevar['skuVal']['skuCalPrice']) ?
                                            $valuevar['skuVal']['skuCalPrice'] : null;
                                        $calquan = isset($valuevar['skuVal']['availQuantity']) ?
                                            $valuevar['skuVal']['availQuantity'] : null;

                                        $secvaldata = str_replace("<span>", "", $secval);
                                        $secvaldata = str_replace("</span>", "", $secvaldata);
                                        $attr1 = str_replace(':', '', $scrappedItem['attr_name'][0]);
                                        $attr2 = str_replace(':', '', $scrappedItem['attr_name'][1]);

                                        $variantdata['variantdata'][] =
                                            [
                                                'attributes' => [
                                                    [
                                                        'name' => $attr1,
                                                        'value' => $valsku
                                                    ],
                                                    [
                                                        'name' => $attr2,
                                                        'value' => $secvaldata
                                                    ],
                                                ],
                                                'price' => $calprice,
                                                'qty' => $calquan,
                                                'child-sku' => $item['productId'] . '-' . $valsku . '-' . $secvaldata,
                                                'image' => isset($variantdata['images'][$keysku]) ? $variantdata['images'][$keysku] : $mainImage
                                            ];
                                        $variants['variant'] = [];
                                        $variants['variant'] = $variantdata;
                                    }
                                }
                            } elseif (isset($scrappedItem['attr_name'][0])) {
                                $calprice = isset($valuevar['skuVal']['skuCalPrice']) ?
                                    $valuevar['skuVal']['skuCalPrice'] : null;
                                $calquan = isset($valuevar['skuVal']['availQuantity']) ?
                                    $valuevar['skuVal']['availQuantity'] : null;


                                $attr1 = str_replace(':', '', $scrappedItem['attr_name'][0]);

                                $variantdata['variantdata'][] =
                                    [
                                        'attributes' => [
                                            [
                                                'name' => $attr1,
                                                'value' => $valsku
                                            ]
                                        ],
                                        'price' => $calprice,
                                        'qty' => $calquan,
                                        'child-sku' => $item['productId'] . '-' . $valsku,
                                        'image' => isset($variantdata['images'][$keysku]) ? $variantdata['images'][$keysku] : $mainImage
                                    ];
                                if (isset($variantdata['images'][$keysku])) {
                                    $images[$variantdata['images'][$keysku]] = $mainImage;
                                }
                                $variants['variant'] = $variantdata;
                            }
                        }
                    }
                    $individualItem['variationData'] = $variants;
                }

                if (isset($item['imageUrl'])) {
                    $individualItem['LargeImage'] = $this->getImageUrl($item);
                } elseif (!empty(array_flip($images))) {
                    $individualItem['LargeImage'] = array_flip($images);
                } elseif (isset($scrappedItem['main_images'])) {
                    $individualItem['LargeImage'] = $scrappedItem['main_images'];
                }

                $individualItem['availability'] = isset($scrappedItem['variation_products'][0]['skuVal']['inventory']) &&
                ($scrappedItem['variation_products'][0]['skuVal']['inventory'] > 0) ?
                    $scrappedItem['variation_products'][0]['skuVal']['inventory'] : '0';

                // ItemDimension including Height Weight Length
                $individualItem['dimension'] = isset($scrappedItem['Package Size']) ? $scrappedItem['Package Size'] :
                    $scrappedItem['Dimensiones del paquete'];
                $individualItem['weight'] = isset($scrappedItem['Package Weight']) ? $scrappedItem['Package Weight'] :
                    '';
                if ($individualItem['weight'] == '') {
                    $individualItem['weight'] = isset($scrappedItem['Peso del paquete']) ? $scrappedItem['Peso del paquete'] : '';
                }

                $individualItem['brand'] = isset($scrappedItem['property-item']['Brand Name']) ?
                    $scrappedItem['property-item']['Brand Name'] : '';
                if ($individualItem['brand'] == '') {
                    $individualItem['brand'] = isset($scrappedItem['property-item']['Nombre de la marca']) ?
                        $scrappedItem['property-item']['Nombre de la marca'] : '';
                }
            } catch (\Exception $e) {
                return false;
            }
            return $individualItem;
        }
    }

    protected function extractCustomInfo($scrappedItem, $item)
    {

        if (isset($item['productId']) || isset($scrappedItem['title'])) {
            try {
                $price = 0.00;
                if (isset($item['discount']) &&
                    (trim($item['discount']) != '0%')
                ) {
                    $salePrice = explode(' ', $item['salePrice']);
                    $salePrice['1'] = str_replace('$', '', $salePrice['1']);
                    $price = (float)$salePrice['1'];
                } elseif (isset($item['originalPrice'])) {
                    $salePrice = explode(' ', $item['originalPrice']);
                    $salePrice['1'] = str_replace('$', '', $salePrice['1']);
                    $price = (float)$salePrice['1'];
                } elseif ($scrappedItem['price']) {
                    $price = (float)$scrappedItem['price'];
                }
                $individualItem['price'] = $price;
                $individualItem['type'] = 'simple';
                $individualItem['qty'] = $scrappedItem['variation_products'];
                //check for variation , if found type = configurable
                if (isset($scrappedItem['variation1']) && !empty($scrappedItem['variation1'])) {
                    $individualItem['type'] = 'configurable';
                    $variant_products = (isset($scrappedItem['variation_products'])) ? $scrappedItem['variation_products'] : "";
                    $first_variation_sku = (isset($scrappedItem['variation1'])) ? $scrappedItem['variation1'] : "";
                    $second_variation_sku = (isset($scrappedItem['variation2'])) ? $scrappedItem['variation2'] : "";
                    $third_variation_sku = (isset($scrappedItem['variation3'])) ? $scrappedItem['variation3'] : "";
                    $variants = "";
                    foreach ($variant_products as $keyvar => $valuevar) {
                        $skuIds = explode(",", $valuevar['skuPropIds']); // getting defined skuids for product
                        foreach ($first_variation_sku as $keysku => $valsku) {
                            $temp = explode("-", $keysku);
                            $keysku1 = $temp['2'];
                            if (isset($second_variation_sku, $scrappedItem['attr_name'][1])) {
                                foreach ($second_variation_sku as $seckey => $secval) {
                                    $temp2 = explode("-", $seckey);
                                    $keysku2 = $temp2['2'];
                                    if (isset($third_variation_sku, $scrappedItem['attr_name'][2])) {
                                        foreach ($third_variation_sku as $thridkey => $thirdval) {
                                            $temp3 = explode("-", $thridkey);
                                            $keysku3 = $temp3['2'];
                                            if (($keysku1 == $skuIds['0']) && ($keysku2 == $skuIds['1']) && ($keysku3 == $skuIds['2'])) {
                                                $calprice = isset($valuevar['skuVal']['skuCalPrice']) ?
                                                    $valuevar['skuVal']['skuCalPrice'] : NULL;
                                                $calquan = isset($valuevar['skuVal']['availQuantity']) ?
                                                    $valuevar['skuVal']['availQuantity'] : NULL;
                                                $thirdvaldata = str_replace("<span>", "", $thirdval);
                                                $thirdvaldata = str_replace("</span>", "", $thirdvaldata);
                                                $secvaldata = str_replace("<span>", "", $secval);
                                                $secvaldata = str_replace("</span>", "", $secvaldata);
                                                $attr1 = str_replace(':', '', $scrappedItem['attr_name'][0]);
                                                $attr2 = str_replace(':', '', $scrappedItem['attr_name'][1]);
                                                $attr3 = str_replace(':', '', $scrappedItem['attr_name'][2]);
                                                $variantdata['variantdata'][] =
                                                    array(
                                                        'price' => $calprice,
                                                        'qty' => $calquan,
                                                        'child-sku' => $item['productId'] . '-' . $valsku . '-' . $secvaldata . '-' . $thirdvaldata,
                                                    );
                                                $variants = $variantdata;
                                            }
                                        }
                                    } else {
                                        if (($keysku1 == $skuIds['0']) && ($keysku2 == $skuIds['1'])) {
                                            $calprice = isset($valuevar['skuVal']['skuCalPrice']) ?
                                                $valuevar['skuVal']['skuCalPrice'] : NULL;
                                            $calquan = isset($valuevar['skuVal']['availQuantity']) ?
                                                $valuevar['skuVal']['availQuantity'] : NULL;
                                            $secvaldata = str_replace("<span>", "", $secval);
                                            $secvaldata = str_replace("</span>", "", $secvaldata);
                                            $attr1 = str_replace(':', '', $scrappedItem['attr_name'][0]);
                                            $attr2 = str_replace(':', '', $scrappedItem['attr_name'][1]);
                                            $variantdata[] =
                                                array(
                                                    'price' => $calprice,
                                                    'qty' => $calquan,
                                                    'child-sku' => $item['productId'] . '-' . $valsku . '-' . $secvaldata,
                                                );
                                            $variants = $variantdata;
                                        }
                                    }
                                }
                            } elseif (isset($scrappedItem['attr_name'][0])) {
                                $calprice = isset($valuevar['skuVal']['skuCalPrice']) ?
                                    $valuevar['skuVal']['skuCalPrice'] : NULL;
                                $calquan = isset($valuevar['skuVal']['availQuantity']) ?
                                    $valuevar['skuVal']['availQuantity'] : NULL;
                                $attr1 = str_replace(':', '', $scrappedItem['attr_name'][0]);
                                $variantdata['variantdata'][] =
                                    array(
                                        'price' => $calprice,
                                        'qty' => $calquan,
                                        'child-sku' => $item['productId'] . '-' . $valsku,
                                    );
                                $variants = $variantdata;
                            }
                        }
                    }
                    $individualItem['variationData'] = $variants;
                }
            } catch (\Exception $e) {
                // echo $e->getMessage();die;
                // Mage::log('Exception In  Aliexpress.php  extractCustomInfo function '.$e->getMessage(), NULL, 'aliexpress_exception.log', true);
            }
            return $individualItem;
        }
    }

    /*protected function clubResponse($spanishItem,$englishItem) {
        $custom = [];
        foreach ($englishItem as $key => $value ) {
            $custom[$key] = ['spanish' => ] ;
        }
    }*/

    /*
     * Fucntion toArrayForUrl
     */

    protected function prepareDescription($dataArray)
    {
        $description = [];
        $description['desc'] = '<ul>';
        $description['short_desc'] = '<p><strong><span>Feature : </span></strong></p>';
        foreach ($dataArray['property-item'] as $attr => $value) {
            if (!is_array($value)) {
                $description['desc'] = $description['desc'] .
                    "<li><b>" . html_entity_decode($attr, ENT_COMPAT, 'UTF-8') . "</b> : " .
                    html_entity_decode($value, ENT_COMPAT, 'UTF-8') . "</li></p>";
            }
        }
        $description['desc'] = $description['desc'] . '</ul>';
        return $description;
    }

    /**
     * @param array $imgArr
     * @return array
     */
    public function getImageUrl($imgArr = [])
    {
        $newImgArr = [];
        if (!empty($imgArr)) {
            if (isset($imgArr['imageUrl'])) {
                $newImgArr[$imgArr['imageUrl']] = $imgArr['imageUrl'];
            }
            if (isset($imgArr['allImageUrls'])) {
                $imgArr['allImageUrls'] = explode(',', $imgArr['allImageUrls']);
                foreach ($imgArr as $key => $path) {
                    if (!empty($path) && filter_var($path, FILTER_VALIDATE_URL)
                        && strpos($path, '.html') === false
                    ) {
                        $newImgArr[$path] = $path;
                    }
                }
            }
        }
        unset($imgArr);
        return $newImgArr;
    }

    /**
     * Get Error
     *
     * @param  string $error
     * @return string
     */
    public function getError($error)
    {
        $aError = [
            '20010000' => 'Call succeeds',
            '20020000' => 'System Error',
            '20030000' => 'Unauthorized transfer request',
            '20030010' => 'Required parameters',
            '20030020' => 'Invalid protocol format',
            '20030030' => 'API version input parameter error',
            '20030040' => 'API name space input parameter error',
            '20030050' => 'API name input parameter error',
            '20030060' => 'Fields input parameter error',
            '20030070' => 'Keyword input parameter error',
            '20030080' => 'Category ID input parameter error',
            '20030090' => 'Tracking ID input parameter error',
            '20030100' => 'Commission rate input parameter error',
            '20030110' => 'Original Price input parameter error',
            '20030120' => 'Discount input parameter error',
            '20030130' => 'Volume input parameter error',
            '20030140' => 'Page number input parameter error',
            '20030150' => 'Page size input parameter error',
            '20030160' => 'Sort input parameter error',
            '20030170' => 'Credit Score input parameter error',
        ];

        if (isset($aError[$error])) {
            return $aError[$error];
        } else {
            return 'Unknown error.';
        }
    }

    public function createCategory($options)
    {

        if (!isset($options['BrowseNode']['BrowseNodeId'])) {
            $options = $this->validateMultiCategories($options);
        }

        foreach ($options as $value) {
            $category[] = $value['Name'];
            if (isset($value['Ancestors'])) {
                $category = $this->getCategoryLevel($value['Ancestors'], $category);
            }
        }
        $category = array_reverse($category);
        return $category;
    }

    public function validateMultiCategories($categories)
    {
        foreach ($categories as $value) {
            foreach ($value as $node) {
                if (isset($node["Children"])) {
                    continue;
                }
                $adjustedArray["BrowseNode"] = $node;
            }
        }
        return $adjustedArray;
    }

    public function getCategoryLevel($variable, $category)
    {
        $category = isset($category) ? $category : [];
        foreach ($variable as $value) {
            $category[] = $value['Name'];
            if (isset($value['Ancestors'])) {
                $category = $this->getCategoryLevel($value['Ancestors'], $category);
            }
        }
        return $category;
    }

    protected function toArrayForUrl($scrappedItem)
    {
        $arrayResponse = [];
        $arrayResponse[] = $this->extractInfo($scrappedItem);
        return $arrayResponse;
    }

    public function googleTransleteData($text)
    {

        if (is_array($text)) {
            return $text;
        }
        $configHelper = $this->_objectManager->get('\Ced\Gtranslate\Helper\Config');
        $apiKey = $configHelper->getTranslationApiKey();
        $language = $configHelper->getTranslationLanguage();
        $url = 'https://www.googleapis.com/language/translate/v2?key=' . $apiKey . '&q=' . rawurlencode($text) . '&source=en&target=' . $language;

        $handle = curl_init($url);
        curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($handle);
        $responseDecoded = json_decode($response, true);
        curl_close($handle);

        return $responseDecoded['data']['translations'][0]['translatedText'];
    }

}
