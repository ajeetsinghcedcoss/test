<?php

/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement (EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @category  Ced
 * @package   Ced_Exporter
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CedCommerce (http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 */

namespace Ced\Exporter\Helper;

/**
 * Directory separator shorthand
 */
if (!defined('DS')) {
    define('DS', DIRECTORY_SEPARATOR);
}

use Magento\Framework\App\Helper\Context;

class Config extends \Magento\Framework\App\Helper\AbstractHelper
{
    const AUTH_TEST = 'api/authenticationtest';
    /**
     * Object Manager
     *
     * @var \Magento\Framework\ObjectManagerInterface
     */
    public $objectManager;

    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    public $scopeConfigManager;

    /**
     * @var \Magento\Framework\Filesystem\DirectoryList
     */
    public $dl;

    /**
     * @var $userId
     */
    public $userId;

    public $shippingMethod;

    public $shippingPrice;

    public $shippingMethods;

    public $additionalShippingPrice;

    /**
     * @var $apiKey
     */
    public $apiKey;

    /**
     * @var $endpoint
     */
    public $endpoint;

    /**
     * Debug Log Mode
     *
     * @var boolean
     */
    public $debugMode = true;

    public $config;

    public $endpoints;

    public $generator;

    public $curl;

    public $logger;

    /**
     * Config constructor.
     * @param Context $context
     * @param \Magento\Framework\Filesystem\DirectoryList $directoryList
     * @param \Magento\Framework\ObjectManagerInterface $objectManager
     * @param \Magento\Framework\Xml\GeneratorFactory $generator
     */
    public function __construct(
        Context $context,
        \Magento\Framework\Filesystem\DirectoryList $directoryList,
        \Magento\Framework\ObjectManagerInterface $objectManager,
        \Magento\Framework\Xml\GeneratorFactory $generator,
        \Magento\Framework\HTTP\Client\Curl $curl,
        \Ced\Exporter\Helper\Logger $logger,
        \Ced\Exporter\Helper\Endpoint $endpoint
    ) {
        parent::__construct($context);
        $this->scopeConfigManager = $context->getScopeConfig();
        $this->objectManager = $objectManager;
        $this->dl = $directoryList;
        $this->curl = $curl;
        $this->generator = $generator;
        $this->endpoint = $endpoint;
        $this->logger = $logger;
    }

    public function getGenerator()
    {
        return $this->generator;
    }


    public function getSourceId()
    {
        $password = $this->apiKey = $this->scopeConfigManager
            ->getValue("exporter_config/exporter_setting/source_id");
        return $password;
    }

    public function getDebugMode()
    {
        $debugMode = $this->scopeConfigManager->getValue(
            'exporter_config/exporter_setting/debug_mode'
        );
        return $debugMode;
    }

    public function getChunkSize()
    {
        $chunkSize = $this->scopeConfigManager->getValue(
            'exporter_config/exporter_product/chunk_product'
        );
        return $chunkSize;
    }


    public function getVat()
    {
        $vat = $this->scopeConfigManager->getValue(
            'exporter_config/exporter_product/vat'
        );
        if (empty($vat)) {
            $vat = '0.00';
        }
        return $vat;
    }



    public function isEnabled()
    {
        $enabled = $this->scopeConfigManager->getValue('exporter_config/exporter_setting/enable');
        return $enabled;
    }

    public function isValid()
    {
        $valid = $this->scopeConfigManager->getValue('exporter_config/exporter_setting/valid');
        return $valid;
    }


    public function getStore()
    {
        $storeId = $this->scopeConfigManager
            ->getValue("exporter_config/exporter_setting/storeid");
        if (isset($storeId) and !empty($storeId)) {
            return $storeId;
        }
        return '0';
    }

    public function getAttributeMappingFile()
    {
        return $this->throttle = $this->scopeConfigManager
            ->getValue("exporter_config/exporter_product/attribute_mapping_file");
    }
}
