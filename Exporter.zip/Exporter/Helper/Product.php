<?php

/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement (EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @category    Ced
 * @package     Ced_Exporter
 * @author      CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright   Copyright CedCommerce (http://cedcommerce.com/)
 * @license     http://cedcommerce.com/license-agreement.txt
 */

namespace Ced\Exporter\Helper;

/**
 * Directory separator shorthand
 */


use Magento\Setup\Exception;
use Magento\Store\Model\StoreManagerInterface;

if (!defined('DS')) {
    define('DS', DIRECTORY_SEPARATOR);
}

/**
 * Class Data For Exporter Authenticated Seller Api
 * @package Ced\Exporter\Helper
 */
class Product extends \Magento\Framework\App\Helper\AbstractHelper
{
    const ATTRIBUTE_TYPE_SKU = 'sku';

    const QUEUED_STATUS = 'QUEUED';

    const ATTRIBUTE_TYPE_NORMAL = 'normal';

    const APPROVAL_STATUS = 'waiting_for_approval';

    const EXPORTER_DIRECTORY = 'exporter';

    const EXPORTER_PRODUCT_STATUS = 'exporter_product_status';

    const MAGENTO_ATTRIBUTE_CODE = 'magento_attribute_code';

    const POSITIONS_ARRAY = [
        'class' => 0,
        'brand' => 1,
        'gtin' => 2,
        'manufacturerArtNo' => 3,
        'dimensions' => 4,
        'freightClass' => 5
    ];

    const DIMENTIONS_ATTRS = [];

    /**
     * Object Manager
     * @var \Magento\Framework\ObjectManagerInterface
     */
    public $objectManager;

    public $shippingDetails;

    public $_requiredAttribute = false;

    public $eavAttribute;

    /**
     * Json Parser
     * @var \Magento\Framework\Json\Helper\Data
     */
    public $json;

    /**
     * Xml Parser
     * @var \Magento\Framework\Convert\Xml
     */
    public $xml;

    /**
     * DirectoryList
     * @var \Magento\Framework\Filesystem\DirectoryList
     */
    public $directoryList;

    public $errorMessage;

    /**
     * Date/Time
     * @var $dateTime
     */
    public $dateTime;

    /**
     * File Manager
     * @var $fileIo
     */
    public $fileIo;

    /**
     * Exporter Logger
     * @var \Ced\Exporter\Helper\Logger
     */
    public $logger;

    public $directoryHelper;

    /**
     * @var Profile
     */
    public $profileHelper;

    /**
     * Selected Store Id
     * @var $selectedStore
     */
    public $selectedStore;

    /**
     * Api
     * @var $api
     */
    public $config;

    /**
     * @var mixed
     */
    public $registry;

    /**
     * Config Manager
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    public $scopeConfigManager;


    public $setBrand = false;

    /**
     * @var \Magento\Framework\Message\ManagerInterface
     */
    public $messageManager;

    /**
     * Feeds Model
     * @var \Ced\Exporter\Model\FeedsFactory
     */
    public $feeds;

    /**
     * @var \Magento\Catalog\Model\ProductFactory
     */
    public $product;

    public $collectionFactory;

    /**
     * @var string
     */
    public $apiAuthKey;
    public $urlBuilder;
    public $fulfillmentLagTime;
    public $ids = [];
    public $data = [];
    public $offer = [];
    public $key = 0;
    public $mpn = '';
    public $exporter;
    public $stockState;
    public $debugMode;
    public $generator;
    public $zip;
    public $apiClient;
    public $barcode;
    public $storeManagerInterface;
    public $identifire;
    public $offerPath;
    public $path;
    public $categoriesFactory;
    public $htmlToText;
    public $endpoint;
    public $category;
    public $priceCurrency;
    public $changefactory;
    public $currencyModel;
    public $state;
    public $productChangeFactory;
    public $emulation;

    public $csv;
    public $swatchesHelper;
    public $swatchesHelperMedia;
    protected $eavConfig;
    protected $productImageHelper;

    /**
     * Product constructor.
     * @param \Magento\Framework\App\Helper\Context $context
     * @param \Magento\Framework\ObjectManagerInterface $objectManager
     * @param \Magento\Framework\Json\Helper\Data $json
     * @param \Magento\Framework\Xml\Generator $generator
     * @param \Magento\Framework\Filesystem\DirectoryList $directoryList
     * @param \Magento\Framework\Filesystem\Io\File $fileIo
     * @param \Magento\Framework\Stdlib\DateTime\DateTime $dateTime
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Framework\UrlInterface $url
     * @param \Magento\Framework\Message\ManagerInterface $manager
     * @param \Magento\Catalog\Model\ProductFactory $product
     * @param \Magento\CatalogInventory\Api\StockStateInterface $stockState
     * @param \Ced\Exporter\Model\FeedsFactory $feedsFactory
     * @param Config $config
     * @param Logger $logger
     * @param Profile $profile
     */
    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        \Magento\Framework\ObjectManagerInterface $objectManager,
        \Magento\Framework\Json\Helper\Data $json,
        \Magento\Framework\Xml\Generator $generator,
        \Magento\Framework\Filesystem\DirectoryList $directoryList,
        \Magento\Framework\Filesystem\Io\File $fileIo,
        \Magento\Framework\Stdlib\DateTime\DateTime $dateTime,
        \Magento\Framework\Registry $registry,
        \Magento\Directory\Model\Currency $currencyModel,
        \Magento\Framework\Message\ManagerInterface $manager,
        \Magento\Store\Model\App\Emulation $emulation,
        \Magento\Catalog\Model\ProductFactory $product,
        \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $collectionFactory,
        \Magento\Eav\Model\Config $eavattribute,
        \Magento\Framework\Archive\Zip $zipArchive,
        \Magento\Directory\Helper\Data $directoryHelper,
        \Magento\CatalogInventory\Api\StockStateInterface $stockState,
        \Ced\Exporter\Model\ProductChangeFactory $changeFactory,
        \Magento\Framework\Pricing\PriceCurrencyInterface $priceCurrency,
        \Magento\Store\Model\StoreManagerInterface $storeManagerInterface,
        \Magento\Framework\App\State $state,
        \Ced\Exporter\Model\FeedsFactory $feedsFactory,
        \Ced\Exporter\Model\ResourceModel\ProductChange\CollectionFactory $productChangeFactory,
        \Ced\Exporter\Model\ResourceModel\Category\CollectionFactory $categoriesFactory,
        \Ced\Exporter\Helper\BarcodeValidator $barcodeValidator,
        \Ced\Exporter\Helper\Config $config,
        \Ced\Exporter\Helper\Endpoint $endpoint,
        \Ced\Exporter\Helper\Category $category,
        \Ced\Exporter\Helper\Logger $logger,
        \Ced\Exporter\Helper\Profile $profile,
        \Ced\Exporter\Model\Xml\GeneratorFactory $generatorFactory,
        \Ced\Exporter\Helper\Html2TextFactory $html2TextFactory,
        \Magento\Framework\File\Csv $csv,
        \Magento\Swatches\Helper\Data $swatchesHelper,
        \Magento\Swatches\Helper\Media $swatchesHelperMedia,
        \Magento\Eav\Model\Config $eavConfig,
        \Magento\Swatches\Model\Swatch $swatchModel,
        \Magento\Catalog\Helper\Image $productImageHelper
    )
    {
        parent::__construct($context);
        $this->objectManager = $objectManager;
        $this->productChangeFactory = $productChangeFactory;
        $this->state = $state;
        $this->emulation = $emulation;
        $this->eavAttribute = $eavattribute;
        $this->currencyModel = $currencyModel;
        $this->priceCurrency = $priceCurrency;
        $this->directoryHelper = $directoryHelper;
        $this->collectionFactory = $collectionFactory;
        $this->storeManagerInterface = $storeManagerInterface;
        $this->urlBuilder = $context->getUrlBuilder();
        $this->changefactory = $changeFactory;
        $this->json = $json;
        $this->category = $category;
        $this->xml = $generator;
        $this->endpoint = $endpoint;
        $this->directoryList = $directoryList;
        $this->fileIo = $fileIo;
        $this->dateTime = $dateTime;
        $this->scopeConfigManager = $context->getScopeConfig();
        $this->messageManager = $manager;
        $this->registry = $registry;
        $this->product = $product;
        $this->stockState = $stockState;
        $this->logger = $logger;
        $this->profileHelper = $profile;
        $this->feeds = $feedsFactory;
        $this->config = $config;
        $this->selectedStore = $config->getStore();
        $this->generator = $generatorFactory;
        $this->zip = $zipArchive;
        $this->barcode = $barcodeValidator;
        $this->categoriesFactory = $categoriesFactory;
        $this->debugMode = $config->getDebugMode();
        $this->htmlToText = $html2TextFactory;
        $this->csv = $csv;
        $this->swatchesHelper = $swatchesHelper;
        $this->swatchesHelperMedia = $swatchesHelperMedia;
        $this->eavConfig = $eavConfig;
        $this->swatchModel = $swatchModel;
        $this->productImageHelper = $productImageHelper;
    }

    /**
     * @param $path
     * @param string $code
     * @return bool|mixed|string
     * @throws \Magento\Framework\Exception\FileSystemException
     */
    public function loadFile($path, $code = '')
    {

        if (!empty($code)) {
            $path = $this->directoryList->getPath($code) . "/" . $path;
        }

        if ($this->fileIo->fileExists($path)) {
            $pathInfo = pathinfo($path);
            if ($pathInfo['extension'] == 'json') {
                $myfile = fopen($path, "r");
                $data = fread($myfile, filesize($path));
                fclose($myfile);
                if (!empty($data)) {
                    try {
                        $data = $this->json->jsonDecode($data);
                        return $data;
                    } catch (\Exception $e) {
                        if ($this->debugMode == true) {
                            $this->logger->debug($e->getMessage(), ['path' => __METHOD__]);
                        }
                    }
                }
            }
        }
        return false;
    }

    public function getXmlPath($name, $code)
    {
        $path = $this->directoryList->getPath($code) . "/" . $name;
        if ($this->fileIo->fileExists($path)) {
            return $path;
        } else {
            return false;
        }
    }

    /**
     * @param array $ids
     * @return bool
     * @throws \Exception
     */


    /**
     * @param $data
     * @param array $params
     * @return bool
     * @throws \Magento\Framework\Exception\FileSystemException
     */
    public function createFile($data, $params = [])
    {
        $type = 'json';
        $timestamp = $this->objectManager->create('\Magento\Framework\Stdlib\DateTime\DateTime');
        $name = 'exporter_' . $timestamp->gmtTimestamp();
        $path = 'exporter';
        $code = 'var';

        if (isset($params['type'])) {
            $type = $params['type'];
        }
        if (isset($params['name'])) {
            $name = $params['name'];
        }
        if (isset($params['path'])) {
            $path = $params['path'];
        }
        if (isset($params['code'])) {
            $code = $params['code'];
        }

        if ($type == 'xml') {
            $xmltoarray = $this->objectManager->create('Magento\Framework\Convert\ConvertArray');
            $data = $xmltoarray->assocToXml($data);
        } elseif ($type == 'json') {
            $data = $this->json->jsonEncode($data);
        } elseif ($type == 'string') {
            $data = ($data);
        }

        $dir = $this->createDir($path, $code);
        $filePath = $dir['path'];
        $fileName = $name . "." . $type;
        try {
            $this->fileIo->write($filePath . "/" . $fileName, $data);
        } catch (\Exception $e) {
            return false;
        }

        return true;
    }

    /**
     * @param string $name
     * @param string $code
     * @return array|bool
     * @throws \Magento\Framework\Exception\FileSystemException
     */
    public function createDir($name = self::EXPORTER_DIRECTORY, $code = 'var')
    {
        $path = $this->directoryList->getPath($code) . "/" . $name;
        if ($this->fileIo->fileExists($path)) {
            return ['status' => true, 'path' => $path, 'action' => 'dir_exists'];
        } else {
            try {
                $this->fileIo->mkdir($path, 0775, true);
                return ['status' => true, 'path' => $path, 'action' => 'dir_created'];
            } catch (\Exception $e) {
                if ($this->debugMode == true) {
                    $this->logger->error($e->getMessage(), ['path' => __METHOD__, 'trace' => $e->getTraceAsString()]);
                }
                return false;
            }
        }
    }

    /**
     * @param array $ids
     * @param null $profileId
     * @param null $otherOptions
     * @return array
     */
    public function insertProducts($ids = [], $profileId = null, $otherOptions = [])
    {
        $uploadedIds = [];
        if (isset($ids) && !empty($ids)) {
            $productData = $this->createProducts($ids, $profileId, $otherOptions);
            if (!is_array($productData)) {
                $uploadedIds[] = "Not ";
                return $uploadedIds;
            }
            foreach ($productData as $key => $result) {
                if (in_array($key, $ids)) {
                    $uploadedIds[] = $key;
                } else {
                    $uploadedIds[] = "Product Failed";
                }
            }
        }
        return $uploadedIds;
    }

    public function insertProductsInAllProfiles($ids = [], $profileIds = [], $otherOptions = [], $customerId = null)
    {
        $uploadedIds = [];
        if (isset($ids) && !empty($ids)) {
            foreach ($profileIds as $profileId) {
                $profile = $this->objectManager->create('\Ced\Exporter\Model\Profile')->load($profileId);
                $profileCode = $profile->getProfileCode();
                if ($profileCode == 'qoolo') {
                    if ($customerId) {
                        $productData = $this->createProductsInQ10($ids, $profileId, $otherOptions, $customerId);
                    } else {
                        $productData = $this->createProductsInQ10($ids, $profileId, $otherOptions);
                    }
                } else {
                    if ($customerId) {
                        $productData = $this->createProducts($ids, $profileId, $otherOptions, $customerId);
                    } else {
                        $productData = $this->createProducts($ids, $profileId, $otherOptions);
                    }
                }

                if (!is_array($productData)) {
                    $uploadedIds[] = "Not ";
                    return $uploadedIds;
                }
                foreach ($productData as $key => $result) {
                    if (in_array($key, $ids)) {
                        $uploadedIds[] = $key;
                    } else {
                        $uploadedIds[] = "Product Failed";
                    }
                }
            }
        }
        return $uploadedIds;
    }


    public function truncateProductChangeTable($customerId = 0)
    {
        try {
            $productChange = $this->changefactory->create()->getCollection()->addFieldToFilter('customer_id', ['eq' => 13]);
            if ($productChange->getData()) {
                $connection = $productChange->getConnection();
                $tableName = $productChange->getMainTable();
                $connection->truncateTable($tableName);
                return true;
            }
        } catch (\Exception $e) {
            return false;
        }

    }

    /**
     * @param array $ids
     * @return array
     * @throws \Exception
     */
    public function insertProductsToDelete($ids = [])
    {
        $uploadedIds = [];
        $deleteStatusIds = [];
        if (isset($ids) && !empty($ids)) {
            foreach ($ids as $id) {
                $productChange = $this->changefactory->create();
                $productChange->load($id, 'product_id');
                $productChange->setData('product_id', $id);
                $productChange->setData('type', \Ced\Exporter\Model\ProductChange::PRODUCT_TO_UPLOAD);
                $productChange->setData('status', \Ced\Exporter\Model\ProductChange::PRODUCT_DELETE);
                $productChange->save();
                if ($productChange->getId()) {
                    $deleteStatusIds[] = $id;
                    $uploadedIds[] = "Product With Id {$id} Queued Successfully For Delete";
                } else {
                    $uploadedIds[] = "Product With Id {$id} Failed";
                }
            }
        }
        if (isset($deleteStatusIds) && !empty($deleteStatusIds)) {
            $this->updateStatus($deleteStatusIds, \Ced\Exporter\Model\Source\Product\Status::UNPUBLISHED);
        }
        return $uploadedIds;
    }

    /**
     * @param array $ids
     * @param $profileId
     * @param $otherOptions
     * @return bool
     */
    public function createProducts($ids = [], $profileId, $otherOptions = [], $customerId = null)
    {
        $response = false;
        try {
            $timestamp = $this->dateTime->date('Y-m-d\TH:i:sP');
            $ids = $this->validateAllProducts($ids, $profileId);

            if (isset($ids['simple']) && !empty($ids['simple'])) {
                foreach ($ids['simple'] as $item) {
                    $id = $item['id'];
                    $productData = $this->prepareProductData($id, $profileId);
                    $product = $this->product->create()
                        ->load($id);

                    $qty = $product->getData('quantity_and_stock_status');
                    $stockQty = isset($qty['qty']) ? $qty['qty'] : 0;
                    // start modified
                    $date = date("Y-m-d H:i:s");
                    $productData['Posting start date'] = $date;
                    $productData['Posting end date'] = $date;
                    // end
                    //image
                    $images = [];
                    // if ($product->getMediaGalleryImages()->getSize() > 0) {
                    $images = $this->prepareAdditionalAssets($product, $otherOptions, $profileId, $customerId);
                    //   }
                    // $images[] = $product->getData('image');
                    // start for base
                    if (isset($productData['parent product stock'])) {
                        $productData['parent product stock'] = $stockQty;
                    }

                    $response[$id] = $productData;
                    if ($customerId) {
                        $this->createTestFile($id, 'w', json_encode($response[$id]), $profileId, $customerId);
                    } else {
                        $this->createTestFile($id, 'w', json_encode($response[$id]), $profileId);
                    }

                    $result = $this->productChangeFactory->create()
                        ->addFieldToFilter('profile_id', ['eq' => $profileId])
                        ->addFieldToFilter('product_id', ['eq' => $id]);
                    if ($customerId) {
                        $result = $result->addFieldToFilter('customer_id', ['eq' => $customerId]);
                    }
                    $productChange = $this->changefactory->create();
                    $tId = $result->getFirstItem()->getId();
                    if (isset($tId) && !empty($tId)) {
                        $productChange = $this->changefactory->create()->load($tId);
                    }
                    $productChange->setData('product_id', $id);
                    if ($customerId) {
                        $productChange->setData('customer_id', $customerId);
                    }
                    $productChange->setData('profile_id', $profileId);
                    $productChange->setData('product_data', json_encode($response[$id]));
                    $productChange->setData('type', \Ced\Exporter\Model\ProductChange::PRODUCT_TO_UPLOAD);
                    $productChange->setData('product_type', 'configurable');
                    $productChange->setData('status', \Ced\Exporter\Model\ProductChange::PRODUCT_CHANGE_ACTION_QUEUED);
                    if ($customerId) {
                        $productChange->setData('customer_id', $customerId);
                    }
                    $productChange->save();
                }
            }

            if (isset($ids['configurable']) && !empty($ids['configurable'])) {
                foreach ($ids['configurable'] as $key => $items) {

                    //var_dump($key);
                    $product = $this->product->create()->load($key);
                    $parentProductName = $product->getName();

                    // config attribute
                    $productType = $product->getTypeInstance();
                    $attributes = $productType->getConfigurableAttributesAsArray($product);
                    $magentoVariantAttributes = [];
                    foreach ($attributes as $attribute) {
                        $magentoVariantAttributes[] = $attribute['attribute_code'];
                    }

                    //image
                    $images = [];
                    //  if ($product->getMediaGalleryImages()->getSize() > 0) {
                    $images = $this->prepareAdditionalAssets($product, $otherOptions, $profileId, $customerId);
                    //  }

                    // $images[] = $product->getData('image');

                    // end config attribute


                    $count = 1;
                    $parentProductStock = 0;
                    foreach ($items as $item) {
                        $id = $item['id'];

                        $chiledProduct = $this->product->create()
                            ->load($id);
                        $childProductData = $this->prepareProductData($id, $profileId, $magentoVariantAttributes);
                        $qty = $chiledProduct->getData('quantity_and_stock_status');
                        $stockQty = isset($qty['qty']) ? $qty['qty'] : 0;

                        //Q10
                        if (isset($childProductData['Sell Qty'])) {
                            $childProductData['Sell Qty'] = $stockQty;
                        }
                        // start modifiyed configproduct data

                        // parent product name
                        if (isset($childProductData['Product name'])) {
                            $childProductData['Product name'] = $parentProductName;
                        }
                        // end

                        //for netsa
                        if (isset($childProductData['Product control number'])) {
                            $parentSku = $product->getSku();
                            $value = explode('-', $parentSku);
                            if (isset($value[0])) {
                                $value = strlen($value[0]) <= 20 ? $value[0] : substr($value[0], 0, 18);
                            } elseif (is_string($value) && strlen($value) > 20) {
                                $value = substr($value, 0, 18);
                            }
                            $childProductData['Product control number'] = $value;
                        }

                        if (isset($childProductData['Manufacturer part number'])) {
                            $parentSku = $product->getSku();
                            $value = explode('-', $parentSku);
                            if (isset($value[0])) {
                                $value = strlen($value[0]) <= 20 ? $value[0] : substr($value[0], 0, 18);
                            } elseif (is_string($value) && strlen($value) > 20) {
                                $value = substr($value, 0, 18);
                            }
                            $childProductData['Manufacturer part number'] = $value;
                        }
                        //end sku Modification
                        if (isset($childProductData['Order column number'])) {
                            $childProductData['Order column number'] = $count;
                            $childProductData['Product management branch number'] = $childProductData['Product management branch number'] . '-' . $count;
                            $childProductData['Number of stocks'] = $stockQty;
                            // $childProductData['Wholesale price'] = '';
                            $date = date("Y-m-d H:i:s");
                            $childProductData['Posting start date'] = $date;
                            $childProductData['Posting end date'] = $date;
                        }
                        //end Netsea


                        if (isset($childProductData['name'])) {
                            $sku = explode('-', $product->getSku());
                            if (isset($sku[0]) && strlen($sku[0]) <= 20) {
                                $sku = $sku[0];
                            } elseif (strlen($sku) > 20) {
                                $sku = substr($sku, 0, 18);
                            }
                            $childProductData['name'] = $sku . ' ' . $parentProductName;
                        }

                        // start for Base

                        if (isset($childProductData['sortint'])) {
                            $childProductData['sortint'] = $count;
                        }
                        if (isset($childProductData['child product stock'])) {
                            $childProductData['child product stock'] = $stockQty;
                            $parentProductStock += (int)$stockQty;

                        }
                        $count++;

                        //end
                        $response[$key][$id] = $childProductData;
                    }

                    if ($parentProductStock && isset($response[$key])) {
                        foreach ($response[$key] as $index => $childItem) {
                            $childItem['parent product stock'] = $parentProductStock;
                            $response[$key][$index] = $childItem;
                        }
                    }
                    $this->createTestFile($key, 'w', json_encode($response[$key]), $profileId, $customerId);

                    if (isset($response[$key])) {
                        $result = $this->productChangeFactory->create()
                            ->addFieldToFilter('profile_id', ['eq' => $profileId])
                            ->addFieldToFilter('product_id', ['eq' => $key]);
                        if ($customerId) {
                            $result = $result->addFieldToFilter('customer_id', ['eq' => $customerId]);
                        }

                        $productChange = $this->changefactory->create();
                        $tId = $result->getFirstItem()->getId();
                        if (isset($tId) && !empty($tId)) {
                            $productChange = $this->changefactory->create()->load($tId);
                        }

                        $productChange->setData('product_id', $key);
                        $productChange->setData('profile_id', $profileId);
                        $productChange->setData('product_data', json_encode($response[$key]));
                        $productChange->setData('type', \Ced\Exporter\Model\ProductChange::PRODUCT_TO_UPLOAD);
                        $productChange->setData('product_type', 'configurable');
                        $productChange->setData('status', \Ced\Exporter\Model\ProductChange::PRODUCT_CHANGE_ACTION_QUEUED);
                        if ($customerId) {
                            $productChange->setData('customer_id', $customerId);
                        }
                        $productChange->save();

                        $product->setData('exporter_product_status', \Ced\Exporter\Model\Source\Product\Status::EXPROTED);
                        $product->getResource()->saveAttribute($product, 'exporter_product_status');
                    }
                }
            }

        } catch (\Exception $exception) {
            if ($this->config->getDebugMode() == true) {
                $this->logger->error($exception->getMessage(),
                    ['path' => __METHOD__, 'trace' => $exception->getTraceAsString()]);
            }
        }

        return $response;
    }

    //Q10 Create Product--------------
    public function createProductsInQ10($ids = [], $profileId, $otherOptions = [], $customerId = null)
    {
        /*echo "<pre>";
        print_r($ids);
        die("JS");*/
        $response = false;
        try {
            $timestamp = $this->dateTime->date('Y-m-d\TH:i:sP');
            $ids = $this->validateAllProducts($ids, $profileId);
            if (isset($ids['simple']) && !empty($ids['simple'])) {
                foreach ($ids['simple'] as $item) {


                    $id = $item['id'];
                    $productData = $this->prepareProductData($id, $profileId);
                    $product = $this->product->create()
                        ->load($id);

                    $qty = $product->getData('quantity_and_stock_status');
                    $stockQty = isset($qty['qty']) ? $qty['qty'] : 0;
                    // start modified
                    $date = date("Y-m-d H:i:s");
                    $productData['Posting start date'] = $date;
                    $productData['Posting end date'] = $date;
                    // end
                    //image
                    $images = [];
                    // if ($product->getMediaGalleryImages()->getSize() > 0) {
                    $images = $this->prepareAdditionalAssets($product, $otherOptions, $profileId, $customerId);
                    //   }
                    // $images[] = $product->getData('image');
                    // start for base
                    if (isset($productData['parent product stock'])) {
                        $productData['parent product stock'] = $stockQty;
                    }
                    //for Q10
                    if (isset($productData['Sell Qty'])) {
                        $productData['Sell Qty'] = $stockQty;
                    }

                    $response[$id] = $productData;
                    $this->createTestFile($id, 'w', json_encode($response[$id]), $profileId, $customerId);

                    $result = $this->productChangeFactory->create()
                        ->addFieldToFilter('profile_id', ['eq' => $profileId])
                        ->addFieldToFilter('product_id', ['eq' => $id]);
                    if ($customerId) {
                        $result = $result->addFieldToFilter('customer_id', ['eq' => $customerId]);
                    }
                    $productChange = $this->changefactory->create();
                    $tId = $result->getFirstItem()->getId();
                    if (isset($tId) && !empty($tId)) {
                        $productChange = $this->changefactory->create()->load($tId);
                    }
                    $productChange->setData('product_id', $id);
                    $productChange->setData('profile_id', $profileId);
                    $productChange->setData('product_data', json_encode($response[$id]));
                    $productChange->setData('type', \Ced\Exporter\Model\ProductChange::PRODUCT_TO_UPLOAD);
                    $productChange->setData('product_type', 'configurable');
                    $productChange->setData('status', \Ced\Exporter\Model\ProductChange::PRODUCT_CHANGE_ACTION_QUEUED);
                    if ($customerId) {
                        $productChange->setData('customer_id', $customerId);
                    }
                    $productChange->save();

                }
            }

            if (isset($ids['configurable']) && !empty($ids['configurable'])) {
                foreach ($ids['configurable'] as $key => $items) {
                    $product = $this->product->create()->load($key);
                    $parentProductName = $product->getName();

                    // config attribute
                    $productType = $product->getTypeInstance();
                    $attributes = $productType->getConfigurableAttributesAsArray($product);
                    $magentoVariantAttributes = [];
                    foreach ($attributes as $attribute) {
                        $magentoVariantAttributes[] = $attribute['attribute_code'];
                    }

                    //image
                    $images = [];
                    //  if ($product->getMediaGalleryImages()->getSize() > 0) {
                    $images = $this->prepareAdditionalAssets($product, $otherOptions, $profileId, $customerId);
                    //  }

                    // $images[] = $product->getData('image');

                    // end config attribute


                    $count = 1;
                    $parentProductStock = 0;
                    foreach ($items as $item) {
                        $id = $item['id'];
                        $chiledProduct = $this->product->create()
                            ->load($id);
                        $childProductData = $this->prepareProductData($id, $profileId, $magentoVariantAttributes);
                        /*if (array_key_exists('Seller Code', $childProductData)
                            && isset($childProductData['Seller Code'])) {*/
                            $value = explode('-', $product->getSku());
                            if (isset($value[0])) {
                                $value = strlen($value[0]) <= 20 ? $value[0] : substr($value[0], 0, 18);
                            } elseif (is_string($value) && strlen($value) > 20) {
                                $value = substr($value, 0, 18);
                            }
                            $childProductData['Seller Code'] = $value;
                            //$childProductData['Product Model Name'] = $value;
//                        }
                        $qty = $chiledProduct->getData('quantity_and_stock_status');
                        $stockQty = isset($qty['qty']) ? $qty['qty'] : 0;

                        // start modifiyed configproduct data

                        // parent product name
                        if (isset($childProductData['Item Name'])) {
                            $childProductData['Item Name'] = $parentProductName;
                        }

                        // end
                        //for Q10
                        $childProductData['Sell Qty'] = $stockQty;
                        if (isset($childProductData['Sell Qty'])) {
                            $parentProductStock += (int)$childProductData['Sell Qty'];
                        }

                        //end Qoo10
                        //for netsa
                        if (isset($childProductData['Product control number'])) {
                            $parentSku = $product->getSku();
                            $value = explode('-', $parentSku);
                            if (isset($value[0])) {
                                $value = strlen($value[0]) <= 20 ? $value[0] : substr($value[0], 0, 18);
                            } elseif (is_string($value) && strlen($value) > 20) {
                                $value = substr($value, 0, 18);
                            }
                            $childProductData['Product control number'] = $value;
                        }

                        if (isset($childProductData['Manufacturer part number'])) {
                            $parentSku = $product->getSku();
                            $value = explode('-', $parentSku);
                            if (isset($value[0])) {
                                $value = strlen($value[0]) <= 20 ? $value[0] : substr($value[0], 0, 18);
                            } elseif (is_string($value) && strlen($value) > 20) {
                                $value = substr($value, 0, 18);
                            }
                            $childProductData['Manufacturer part number'] = $value;
                        }
                        //end sku Modification
                        if (isset($childProductData['Order column number'])) {
                            $childProductData['Order column number'] = $count;
                            $childProductData['Product management branch number'] = $childProductData['Product management branch number'] . '-' . $count;
                            $childProductData['Number of stocks'] = $stockQty;
                            // $childProductData['Wholesale price'] = '';
                            $date = date("Y-m-d H:i:s");
                            $childProductData['Posting start date'] = $date;
                            $childProductData['Posting end date'] = $date;
                        }
                        //end Netsea


                        if (isset($childProductData['name'])) {
                            $sku = explode('-', $product->getSku());
                            if (isset($sku[0]) && strlen($sku[0]) <= 20) {
                                $sku = $sku[0];
                            } elseif (strlen($sku) > 20) {
                                $sku = substr($sku, 0, 18);
                            }
                            $childProductData['name'] = $sku . ' ' . $parentProductName;
                        }

                        // start for Base

                        if (isset($childProductData['sortint'])) {
                            $childProductData['sortint'] = $count;
                        }
                        if (isset($childProductData['child product stock'])) {
                            $childProductData['child product stock'] = $stockQty;
                            $parentProductStock += (int)$stockQty;

                        }
                        $count++;

                        //end
                        $response[$key][$id] = $childProductData;
                    }

                     if($parentProductStock && isset($response[$key])) {
                         foreach ($response[$key] as $index => $childItem ) {
                             $childItem['Sell Qty'] = $parentProductStock;
                             $response[$key][$index] = $childItem;
                         }
                     }

                    //echo "<pre>";print_r($response);die();




                    $multiData = $data = [];

                    foreach ($response[$product->getId()] as $childKey => $childValue) {
                        $data = array_merge_recursive($data, $childValue);
                    }
                    foreach ($data as $keys => $values) {
                        $values = array_unique($data[$keys]);
                        if (!empty($values) || !is_null($values) || $values != '') {
                            $multiData[$product->getId()][$keys] = implode('$$', $values);
                        }
                    }
                    $response[$product->getId()] = $multiData[$product->getId()];
                    $this->createTestFile($key, 'w', json_encode($multiData), $profileId, $customerId);
                    /*echo "<pre>";print_r($response);die('pol');*/
                    if (isset($response[$key])) {
                        $result = $this->productChangeFactory->create()
                            ->addFieldToFilter('profile_id', ['eq' => $profileId])
                            ->addFieldToFilter('product_id', ['eq' => $key]);
                        if ($customerId) {
                            $result = $result->addFieldToFilter('customer_id', ['eq' => $customerId]);
                        }
                        $productChange = $this->changefactory->create();
                        $tId = $result->getFirstItem()->getId();
                        if (isset($tId) && !empty($tId)) {
                            $productChange = $this->changefactory->create()->load($tId);
                        }
                        $productChange->setData('product_id', $key);
                        $productChange->setData('profile_id', $profileId);
                        $productChange->setData('product_data', json_encode($response[$key]));
                        $productChange->setData('type', \Ced\Exporter\Model\ProductChange::PRODUCT_TO_UPLOAD);
                        $productChange->setData('product_type', 'configurable');
                        $productChange->setData('status', \Ced\Exporter\Model\ProductChange::PRODUCT_CHANGE_ACTION_QUEUED);
                        if ($customerId) {
                            $productChange->setData('customer_id', $customerId);
                        }
                        $productChange->save();

                        $product->setData('exporter_product_status', \Ced\Exporter\Model\Source\Product\Status::EXPROTED);
                        $product->getResource()->saveAttribute($product, 'exporter_product_status');
                    }
                }
            }

        } catch (\Exception $exception) {
            if ($this->config->getDebugMode() == true) {
                $this->logger->error($exception->getMessage(),
                    ['path' => __METHOD__, 'trace' => $exception->getTraceAsString()]);
            }
        }

        return $response;
    }


    public function createTestFile($id, $mode = 'w', $data, $profileId, $customerId = null)
    {

        $returnData = '';
        try {
            $fileName = 'product' . $id . '.text';
            $dir = 'ced/' . $profileId . '/exporter/back';
            if ($customerId) {
                $dir = 'ced/' . $profileId . '/' . $customerId . '/exporter/back';
            }

            $path = $this->createDir($dir, 'media');
            if (isset($path['status'], $path['path']) && $path['status']) {
                $directory = $path['path'];
                $csv_dir = $directory . '/';
            }
            if (!is_dir($csv_dir)) {
                mkdir($csv_dir, '0777', true);
            }
            $filePath = $csv_dir . $fileName;
            if ($mode == 'w') {
                if (!empty($data)) {
                    file_put_contents($filePath, $data);
                    return true;
                }

            } else {

                if ($this->fileIo->fileExists($filePath)) {
                    $returnData = file_get_contents($filePath);
                    unlink($filePath);
                    return $returnData;
                }

            }
        } catch (\Exception $e) {

        }
        return $returnData;

    }

    public function prepareAdditionalAssets($product, $otherOptions = [], $profileId, $customerId = null)
    {

        $fileName = $product->getSku();
        $dir = 'ced/' . $profileId . '/exporter/feed/_' . $fileName . '/_mediaGalleryImages/';
        if ($customerId) {
            $dir = 'ced/' . $profileId . '/' . $customerId . '/exporter/feed/_' . $fileName . '/_mediaGalleryImages/';
        }
        $path = $this->createDir($dir, 'media');
        $filePath = '';
        if (isset($path['status'], $path['path']) && $path['status']) {
            $directory = $path['path'];
            $filePath = $directory . '/';
        }
        if (!is_dir($filePath)) {
            mkdir($filePath, '0777', true);
        }

        $dirLarzImg = 'ced/' . $profileId . '/exporter/feed/_' . $fileName . '/_images_800X800'.'/_mediaGalleryImages/';
        if ($customerId) {
            $dirLarzImg = 'ced/' . $profileId . '/' . $customerId . '/exporter/feed/_' . $fileName . '/_mediaGalleryImages/_images_800X800'.'/_mediaGalleryImages/';
        }
        
        $pathlarz = $this->createDir($dirLarzImg, 'media');
        $dirLarzImg = '';
        if (isset($pathlarz['status'], $pathlarz['path']) && $pathlarz['status']) {
            $directory = $pathlarz['path'];
            $dirLarzImg = $directory . '/';
        }
        if (!is_dir($dirLarzImg)) {
            mkdir($dirLarzImg, '0777', true);
        }
                
        $lasrzImageSize = $dirLarzImg.$fileName; // for Media Images
        $filePath .= $fileName;

        $additionalAssets = [];
        try {
            if (isset($otherOptions) && !empty($otherOptions)) {
                foreach ($otherOptions as $option) {
                    if ($option == '8x8image') {
                        //Description Images-----------------------------------------------
                        $description = $product->getData('description');
                        $fileName = $product->getSku();
                        preg_match_all('/<img[^>]+>/i', $description, $imgTags);
                        if (count($imgTags) > 0) {
                            // get Discription Images
                            $descriptionImagesPath = '';
                            if ($customerId) {
                                $descriptionImagesPath =  $this->createDir('ced/' . $profileId . '/' . $customerId . '/exporter/feed/_' . $fileName . '/_images_800X800/descriptionImages/', 'media');
                            }else {
                                $descriptionImagesPath = $this->createDir('ced/' . $profileId . '/exporter/feed/_' . $fileName . '/_images_800X800/descriptionImages/', 'media');
                            }


                            if (isset($descriptionImagesPath['status'], $descriptionImagesPath['path']) && $descriptionImagesPath['status']) {
                                $descriptionImagesPath = $descriptionImagesPath['path'] . '/';
                            }
                            for ($i = 0; $i < count($imgTags[0]); $i++) {
                                // get the source string
                                preg_match('/src="([^"]+)/i', $imgTags[0][$i], $imgage);
                                $image = str_ireplace('src="', '', $imgage[0]);
                                $imgCdns[] = $image;
                            }
                            $tmpFolder = $this->createDir('catalog/product/ced_exporter/images_800X800/', 'media');
                            foreach ($imgCdns as $key => $value) {
                                $nFile = $tmpFolder['path'] . '/' . $fileName . '_desc_' . $key . '.jpg';
                                $this->download_image1($value, $nFile);
                            }
                            $tempFolderPath = $this->directoryList->getPath('media') . '/catalog/product/ced_exporter/images_800X800/';
                            $paths = glob($tempFolderPath . $fileName . '*.jpg');
                            foreach ($paths as $absPath) {
                                $t = explode("/catalog/product" , $absPath);
                                $dImages[] = $this->productImageHelper->init($product, 'small_image')
                                ->setImageFile($t[1])
                                    ->keepAspectRatio(true)
                                    ->resize(800, 800)
                                    ->getUrl();
                            }
                            if (isset($dImages) && !empty($dImages)) {
                                foreach ($dImages as $key => $u) {
                                    $newPath = $descriptionImagesPath . '_' . $fileName . '_' . $key . '.jpg';
                                    if ($this->fileIo->cp($u, $newPath)) {
                                        $additionalAssets[] = $newPath;
                                    }
                                }
                            }
                            $files = glob($tempFolderPath . '/*'); // get all file names
                            foreach($files as $file){ // iterate files
                                if(is_file($file))
                                    unlink($file); // delete file
                            }
                        }
                        //800X800 Images-------------------------
                        $fileName = $product->getSku();
                        $images_800X800 = '';
                        /*if ($customerId) {
                            $images_800X800 = $this->createDir('ced/' . $profileId .'/' . $customerId . '/exporter/feed/_' . $fileName . '/_images_800X800/', 'media');
                        }else {
                            $images_800X800 = $this->createDir('ced/' . $profileId . '/exporter/feed/_' . $fileName . '/_images_800X800/', 'media');
                        }
                        $productImages = $product->getMediaGalleryImages();
                        if ($productImages->getSize() > 0) {
                            $images = [];
                            foreach ($productImages as $image) {
                                $images[] = $this->productImageHelper->init($product, $image->getId(), $image->getData())
                                    ->setImageFile($image->getFile())
                                    ->keepAspectRatio(true)
                                    ->resize(800, 800)
                                    ->getUrl();
                            }
                            if (isset($images) && !empty($images)) {
                                foreach ($images as $key => $u) {
                                    $path = isset($images_800X800['path']) ? $images_800X800['path'] : null;
                                    $newPath = $path . '_' . $fileName . '_' . $key . '.jpg';
                                    if ($this->fileIo->cp($u, $newPath)) {
                                        $additionalAssets[] = $newPath;
                                    }
                                }
                            }
                        }*/

                        // start
                        // ColorSwatches--------------------_images_800X800----------------------
                        $colorSwatchImages = '';
                        if ($customerId) {
                            $colorSwatchImages = $this->createDir('ced/' . $profileId .'/' . $customerId . '/exporter/feed/_' . $fileName . '/_images_800X800'.'/_colorSwatches/', 'media');
                        }else {
                            $colorSwatchImages = $this->createDir('ced/' . $profileId . '/exporter/feed/_' . $fileName . '/_images_800X800'.'/_colorSwatches/', 'media');
                        }


                        if (isset($product)) {
                            $additionalAssets = [];
                            $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
                            //$swatchCollection = $objectManager->create('Magento\Swatches\Model\ResourceModel\Swatch\Collection');
                            if ($product->getTypeId() == 'configurable') {
                                $childProducts = $product->getTypeInstance()->getUsedProducts($product);
                                $configAtt = $product->getTypeInstance()->getConfigurableOptions($product);
                                $attrOptions = array();
                                foreach ($configAtt as $attr) {
                                    foreach ($attr as $p) {
                                        if(!isset($attrOptions[$p['attribute_code']]) && strpos($p['attribute_code'], 'colo') !== false){
                                            $attrOptions[$p['attribute_code']] = $p['attribute_code'];
                                        }
                                    }
                                }

                                $childIds = [];
                                $chr = [];
                                $swatchImages = [];
                                foreach ($childProducts as $child){
                                    $childIds[] = $child->getId();
                                }
                                foreach ($childIds as $childId) {
                                    // $ch = $objectManager->create('\Magento\Catalog\Api\ProductRepositoryInterface')->getById($childId);
                                    $ch =  $this->product->create()
                                        ->setStoreId($this->selectedStore)
                                        ->load($childId);

                                    $attrValue = '';
                                    foreach ($attrOptions as $attrOption ) {
                                        $attribute = $product->getResource()->getAttribute($attrOption);
                                        // $label = $attribute->getFrontend()->getLabel($ch);
                                        $attrValue = $attribute->getFrontend()->getValue($ch);
                                    }
                                    $swatchImages[$attrValue] = $this->directoryList->getPath('media') . '/catalog/product' . $ch->getData('swatch_image');
                                }
                            }

                            if (isset($swatchImages) && !empty($swatchImages)) {
                                if (count($swatchImages) > 0) {
                                    foreach ($swatchImages as $key => $url) {
                                        //if (isset($url) && !empty($url)) {
                                        $name = $product->getSku();
                                        $path = isset($colorSwatchImages['path']) ? $colorSwatchImages['path'] : null;
                                        $newPath = $path . '_' . $name . '_' . $key . '.jpg';
                                        if ($this->fileIo->cp($url, $newPath)) {
                                            $additionalAssets[] = $newPath;
                                        }
                                        //}
                                    }
                                }
                            }
                        }
                        //Media Gallery Images------  '/_images_800X800' -----------------------------------------------
                        $mediaUrl = $this->storeManagerInterface->getStore()
                            ->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);
                        $main_image = $mediaUrl . 'catalog/product' . $product->getData('image');

                        $newPath = $lasrzImageSize . '.jpg';
                        if ($this->fileIo->cp($main_image, $newPath)) {
                            $additionalAssets[] = $newPath;
                        }
                        if (isset($product)) {
                            $productImages = $product->getMediaGalleryImages();
                            if ($productImages->getSize() > 0) {
                                $mainImage = $product->getImage();
                                $count = 0;
                                foreach ($productImages as $image) {
                                    // Continuing if main image.
                                    if (isset($mainImage) && $image->getFile() == $mainImage) {
                                        continue;
                                    }
                                    $url = $image->getUrl();
                                    $newPath = $lasrzImageSize . '_' . ++$count . '.jpg';
                                    if ($this->fileIo->cp($url, $newPath)) {
                                        $additionalAssets[] = $newPath;
                                    } else {
                                        if (file_exists('/usr/share/nginx/html/pikku-up.com/pub/media/catalog/product' . $image->getFile())) {
                                            file_put_contents($newPath, file_get_contents('/usr/share/nginx/html/pikku-up.com/pub/media/catalog/product' . $image->getFile()));
                                            $additionalAssets[] = $newPath;
                                        }
                                    }
                                }
                            }
                        }

                        // end


                    }
                    if ($option == 'csv') {
                        $additionalAssets = [];
                    }
                    if ($option == 'image') {
                        // ColorSwatches------------------------------------------
                        $colorSwatchImages = '';
                        if ($customerId) {
                            $colorSwatchImages = $this->createDir('ced/' . $profileId .'/' . $customerId . '/exporter/feed/_' . $fileName . '/_colorSwatches/', 'media');
                        }else {
                            $colorSwatchImages = $this->createDir('ced/' . $profileId . '/exporter/feed/_' . $fileName . '/_colorSwatches/', 'media');
                        }


                        if (isset($product)) {
                            $additionalAssets = [];
                            $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
                            //$swatchCollection = $objectManager->create('Magento\Swatches\Model\ResourceModel\Swatch\Collection');
                            if ($product->getTypeId() == 'configurable') {
                                $childProducts = $product->getTypeInstance()->getUsedProducts($product);
                                $configAtt = $product->getTypeInstance()->getConfigurableOptions($product);
                                $attrOptions = array();
                                foreach ($configAtt as $attr) {
                                    foreach ($attr as $p) {
                                        if(!isset($attrOptions[$p['attribute_code']]) && strpos($p['attribute_code'], 'colo') !== false){
                                            $attrOptions[$p['attribute_code']] = $p['attribute_code'];
                                        }
                                    }
                                }

                                $childIds = [];
                                $chr = [];
                                $swatchImages = [];
                                foreach ($childProducts as $child){
                                    $childIds[] = $child->getId();
                                }
                                foreach ($childIds as $childId) {
                                   // $ch = $objectManager->create('\Magento\Catalog\Api\ProductRepositoryInterface')->getById($childId);
                                    $ch =  $this->product->create()
                                        ->setStoreId($this->selectedStore)
                                        ->load($childId);

                                    $attrValue = '';
                                    foreach ($attrOptions as $attrOption ) {
                                        $attribute = $product->getResource()->getAttribute($attrOption);
                                       // $label = $attribute->getFrontend()->getLabel($ch);
                                        $attrValue = $attribute->getFrontend()->getValue($ch);
                                    }
                                    $swatchImages[$attrValue] = $this->directoryList->getPath('media') . '/catalog/product' . $ch->getData('swatch_image');
                                }
                            }

                            if (isset($swatchImages) && !empty($swatchImages)) {
                                if (count($swatchImages) > 0) {
                                    foreach ($swatchImages as $key => $url) {
                                        //if (isset($url) && !empty($url)) {
                                            $name = $product->getSku();
                                            $path = isset($colorSwatchImages['path']) ? $colorSwatchImages['path'] : null;
                                            $newPath = $path . '_' . $name . '_' . $key . '.jpg';
                                            if ($this->fileIo->cp($url, $newPath)) {
                                                $additionalAssets[] = $newPath;
                                            }
                                        //}
                                    }
                                }
                            }
                        }
                        //Media Gallery Images-----------------------------------------------------
                        $mediaUrl = $this->storeManagerInterface->getStore()
                            ->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);
                        $main_image = $mediaUrl . 'catalog/product' . $product->getData('image');
                        $newPath = $filePath . '.jpg';
                        if ($this->fileIo->cp($main_image, $newPath)) {
                            $additionalAssets[] = $newPath;
                        }
                        if (isset($product)) {
                            $productImages = $product->getMediaGalleryImages();
                            if ($productImages->getSize() > 0) {
                                $mainImage = $product->getImage();
                                $count = 0;
                                foreach ($productImages as $image) {
                                    // Continuing if main image.
                                    if (isset($mainImage) && $image->getFile() == $mainImage) {
                                        continue;
                                    }
                                    $url = $image->getUrl();
                                    $newPath = $filePath . '_' . ++$count . '.jpg';
                                    if ($this->fileIo->cp($url, $newPath)) {
                                        $additionalAssets[] = $newPath;
                                    } else {
                                        if (file_exists('/usr/share/nginx/html/pikku-up.com/pub/media/catalog/product' . $image->getFile())) {
                                            file_put_contents($newPath, file_get_contents('/usr/share/nginx/html/pikku-up.com/pub/media/catalog/product' . $image->getFile()));
                                            $additionalAssets[] = $newPath;
                                        }
                                    }
                                }
                            }
                        }
                        //Description Images-----------------------------------------------
                        $description = $product->getData('description');
                        preg_match_all('/<img[^>]+>/i', $description, $imgTags);
                        if (count($imgTags) > 0) {
                            // get Discription Images
                            $descriptionImagesPath = '';
                            if ($customerId) {
                                $descriptionImagesPath = $this->createDir('ced/' . $profileId . '/' . $customerId . '/exporter/feed/_' . $fileName . '/_descriptionImages/', 'media');
                            }else {
                                $descriptionImagesPath = $this->createDir('ced/' . $profileId . '/exporter/feed/_' . $fileName . '/_descriptionImages/', 'media');
                            }

                            if (isset($descriptionImagesPath['status'], $descriptionImagesPath['path']) && $descriptionImagesPath['status']) {
                                $descriptionImagesPath = $descriptionImagesPath['path'] . '/';
                            }
                            for ($i = 0; $i < count($imgTags[0]); $i++) {
                                // get the source string
                                preg_match('/src="([^"]+)/i', $imgTags[0][$i], $imgage);
                                // remove opening 'src=' tag, can`t get the regex right
                                $image = str_ireplace('src="', '', $imgage[0]);
                                $image1 = $image;
                                if (!strstr($image, 'https')) {
                                    $image = 'https:' . $image;
                                }
                                $nfile = $descriptionImagesPath . $fileName . '_' . $i . '.jpg';
                                if ($this->fileIo->cp($image, $nfile)) {
                                    $additionalAssets[] = $nfile;
                                } else {
                                    if ($this->download_image1($image, $nfile)) {
                                        $additionalAssets[] = $nfile;
                                    }
                                }

                            }
                        }
                    }
                }
            }
        } catch (\Exception $e) {

            $this->logger->error($e->getMessage(),
                ['path' => __METHOD__, 'trace' => '']);
            // $additionalAssets = array($e->getMessage());
        }

        return $additionalAssets;
    }

    function download_image1($image_url, $image_file)
    {
        try {
            $fp = fopen($image_file, 'w+');              // open file handle

            $ch = curl_init($image_url);
            curl_setopt($ch, CURLOPT_FILE, $fp);          // output to file
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
            curl_setopt($ch, CURLOPT_TIMEOUT, 1000);      // some large value to allow curl to run for a long time
            curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0');
            curl_exec($ch);
            curl_close($ch);                              // closing curl handle
            fclose($fp);
            return true;
        } catch (\Exception $e) {
            $this->logger->error($e->getMessage(),
                ['path' => __METHOD__, 'trace' => '']);
        }
        // closing file handle
    }


    public function prepareProductData($id, $profileId, $magentoVariantAttributes = array(), $parentProductName = null)
    {
        $response = array();
        try {
            $product = $this->product->create()
                // ->setStoreId($this->selectedStore)
                ->load($id);

            if (!$profileId) {
                $profileId = $product->getData(\Ced\Exporter\Helper\Profile::ATTRIBUTE_CODE_PROFILE_ID);
                $profileId = trim($profileId);
                $profileId = explode(',', $profileId);
                if (isset($profileId[0])) {
                    $profileId = $profileId[0];
                }
            }
            $profile = $this->profileHelper->getProfile($id, $profileId);
            $profileData = $profile->getData();
            $profileRequiredAttributes = isset($profileData['profile_required_attributes']) ?
                $profileData['profile_required_attributes'] : array();
            $profileOptionalAttributes = isset($profileData['profile_optional_attributes']) ?
                $profileData['profile_optional_attributes'] : array();

            // $headerRestriction = isset($profileData['header_restriction']) ? $profileData['header_restriction'] : 0;
            if (!empty($profileRequiredAttributes)) {
                foreach ($profileRequiredAttributes as $key => $attribute) {
                    //echo "<pre>";print_r($profileRequiredAttributes);die();
                    $value = $this->getMappedAttributeValue($attribute, $product);

                    if (is_array($value)) {
                        $value = implode(',', $value);
                    }

                    // for netsea
                    if (isset($attribute['magento_attribute_code']) &&
                        $attribute['magento_attribute_code'] == 'sku') {

                        $value = explode('-', $value);
                        if (isset($value[0])) {
                            $value = strlen($value[0]) <= 20 ? $value[0] : substr($value[0], 0, 18);
                        } elseif (is_string($value) && strlen($value) > 20) {
                            $value = substr($value, 0, 18);
                        }
                    }
                    // end
                    // for base
                    if ($key == 'name') {
                        $sku = explode('-', $product->getSku());
                        if (isset($sku[0]) && strlen($sku[0]) <= 20) {
                            $sku = $sku[0];
                        } elseif (strlen($value) > 20) {
                            $sku = substr($sku, 0, 18);
                        }
                        $value = $sku . ' ' . $value;
                    }

                    if (isset($attribute['exporter_attribute_name']) &&
                        $attribute['exporter_attribute_name'] == 'Description') {
                        $tb_material = $this->getMappedAttributeValue(['magento_attribute_code' => 'tb_material'], $product);
                        $value .= $tb_material;
                        $value .= isset($attribute['default_value']) ? ' ' . $attribute['default_value'] : '';
                    }
                    // end

                    // for qoo10
                    if (isset($attribute['exporter_attribute_name']) &&
                        $attribute['exporter_attribute_name'] == 'Item Description') {
                        $tb_material = $this->getMappedAttributeValue(['magento_attribute_code' => 'tb_material'], $product);
                        $value .= $tb_material;
                        $value .= isset($attribute['default_value']) ? ' ' . $attribute['default_value'] : '';
                    }
                    /*if ($key == 'Seller Code' || $key == 'Product Model Name') {
                        $value = explode('-', $value);
                        if (isset($value[0])) {
                            $value = strlen($value[0]) <= 20 ? $value[0] : substr($value[0], 0, 18);
                        } elseif (is_string($value) && strlen($value) > 20) {
                            $value = substr($value, 0, 18);
                        }
                    }*/
                    // end
                    $response[$key] = $value;
                }
            }
            if (!empty($profileOptionalAttributes)) {
                foreach ($profileOptionalAttributes as $key => $attribute) {
                    $value = $this->getMappedAttributeValue($attribute, $product);
                    if (is_array($value)) {
                        $value = implode(',', $value);
                    }
                    $response[$key] = $value;
                }
            }


            $VariantData = [];

            if (!empty($magentoVariantAttributes)) {
                foreach ($magentoVariantAttributes as $magentoVariantAttribute) {

                    $attName = $magentoVariantAttribute;
                    if (strpos($magentoVariantAttribute, 'colo') == true) {
                        $attName = 'color';
                    } elseif (strpos($magentoVariantAttribute, 'size') == true) {
                        $attName = 'size';
                    }
                    if (isset($profileOptionalAttributes[$magentoVariantAttribute])) {
                        $value = $this->getMappedAttributeValue($profileOptionalAttributes[$magentoVariantAttribute], $product);
                        $VariantData[$attName] = $value;

                    } else {
                        $attribute = ['magento_attribute_code' => $magentoVariantAttribute];
                        $value = $this->getMappedAttributeValue($attribute, $product);
                        $VariantData[$attName] = $value;

                    }

                }
            }
            if (isset($response['Breakdown'])) {

                $breakdown = isset($VariantData['color']) ? $VariantData['color'] . ' ' : '';
                $breakdown .= isset($VariantData['size']) ? $VariantData['size'] . ' ' : '';
                $response['Breakdown'] = /*implode(' ',$VariantData)*/
                    $breakdown . $response['Breakdown'];
            }
            //for Q10---
            if (isset($response['Inventory Info'])) {

                //color =>色
//                $optionsInfo = isset($VariantData['color']) ? 'color||*' . $VariantData['color'] . '||*' : '';
                $optionsInfo = isset($VariantData['color']) ? '色||*' . $VariantData['color'] . '||*' : '';

                //size =>  サイズ
//                $optionsInfo .= isset($VariantData['size']) ? 'size||*' . $VariantData['size'] . '||*' : '';
                $optionsInfo .= isset($VariantData['size']) ? 'サイズ||*' . $VariantData['size'] . '||*' : '';
                $optionsInfo .= /*(int)$product->getPrice()*/ '0.00'. '||*'; //
                $optionsInfo .= $product->getData('quantity_and_stock_status')['qty'].'||*||*';
                $response['Inventory Info'] = /*implode(' ',$VariantData)*/
                    $optionsInfo . $response['Inventory Info'];
            }
            //end Q10---

            $product->setData('exporter_product_status', \Ced\Exporter\Model\Source\Product\Status::EXPROTED);
            $product->getResource()->saveAttribute($product, 'exporter_product_status');
        } catch (\Exception $e) {
            echo $e->getMessage();
            //die('check 1');


            if ($this->config->getDebugMode() == true) {
                $this->logger->error($e->getMessage(),
                    ['path' => __METHOD__, 'trace' => $e->getTraceAsString()]);
            }

            return false;
        }
        return $response;
    }

    /**
     * @param $data
     * @param $timestamp
     * @param $type
     * @return bool
     * @throws \DOMException
     * @throws \Magento\Framework\Exception\FileSystemException
     */
    public function createRelation($data, $timestamp, $type)
    {
        $response = false;
        if (isset($data)) {
            $path = self::EXPORTER_DIRECTORY . DS . $type . $timestamp . DS . '_rels';
            $dir = $this->createDir($path);
            $name = '.rels';
            $path = $dir['path'] . DS . $name;
            $product = $this->generator->create()->arrayToXml($data);
            $product->save($path);
            $response = true;
        }
        return $response;
    }

    /**
     * @param $data
     * @param $timestamp
     * @param $type
     * @return bool
     * @throws \DOMException
     * @throws \Magento\Framework\Exception\FileSystemException
     */
    public function createContentType($data, $timestamp, $type)
    {
        $response = false;
        if (isset($data)) {
            $path = self::EXPORTER_DIRECTORY . DS . $type . $timestamp;
            $name = '[Content_Types]' . '.xml';
            $dir = $this->createDir($path);
            $path = $dir['path'] . DS . $name;
            $product = $this->generator->create()->arrayToXml($data);
            $product->save($path);
            $response = true;
        }
        return $response;
    }

    public function xmlValidate($path, $xsdpath)
    {
        try {
            $doc = new \DOMDocument();
            $doc->load($path);
            libxml_use_internal_errors(true);
            $isValid = $doc->schemaValidate($xsdpath);
            if ($isValid) {
                return ['success' => true];
            } else {
                $errors = libxml_get_errors();
                $errm = '';
                foreach ($errors as $error) {
                    $message = 'XML error ' . $error->message . ' ' . $error->level . ' on line ' . $error->line . ' Column ' . $error->column;
                    //$this->log($message,true);
                    $errm .= $message;
                }
                libxml_clear_errors();
                return ['success' => false, 'message' => $errm];
            }
        } catch (\Exception $e) {
            $this->logger->error($e->getMessage(), ['path' => __METHOD__, 'trace' => $e->getTraceAsString()]);
        }
    }

    /**
     * @param $data
     * @return bool
     */
    public function createProductPackage($data)
    {
        try {
            $response = false;
            if (isset($data)) {
                $timestamp = $this->dateTime->gmtTimestamp();
                $path = self::EXPORTER_DIRECTORY . DS . 'Product_' . $timestamp;
                $dir = $this->createDir($path, 'media');
                $name = 'Products.xml';
                $path = $dir['path'] . DS . $name;
                $this->path = $path;
                $product = $this->generator->create()->arrayToXml($data);
                $product->save($path);
                $xmlpath = $this->createDir(self::EXPORTER_DIRECTORY, 'media');
                $xmlpath = $xmlpath['path'] . '/shopping-mall.xsd';
                $validate = $this->xmlValidate($path, $xmlpath);
                if ($validate['success'] == true) {
                    $url = $this->endpoint->getEndpoint($this->config->getmode(), 'api/importfile');
                    $headers = $this->endpoint->getHeaders($this->config->getApiKey(), 'POST');
                    $saveResponse = $this->category->sendFile($path, $url, $headers, 'POST', $name);
                    $response = true;
                    $this->saveResponse($saveResponse, 'product_creation');
                    if (isset($this->ids) && !empty($this->ids)) {
                        foreach ($this->ids as $uploadedId) {
                            $productChange = $this->changefactory->create();
                            $productChange->load($uploadedId, 'product_id');
                            if ($productChange->getId()) {
                                $productChange->setData('status', 'uploaded');
                                $productChange->save();
                            }
                        }
                    }
                } else {
                    $response = false;
                    $this->logger->error('xmlFailer', [
                        'path' => __METHOD__,
                        'trace' => $validate
                    ]);
                }
            }
            return $response;
        } catch (\Exception $e) {
            if ($this->debugMode == true) {
                $this->logger->error($e->getMessage(), ['path' => __METHOD__, 'trace' => $e->getTraceAsString()]);
            }
        }
        return $response;
    }

    /**
     * @param $data
     * @return bool
     */
    public function createOfferPackage($data)
    {
        try {
            $response = false;
            if (isset($data)) {
                $timestamp = $this->dateTime->gmtTimestamp();
                $path = self::EXPORTER_DIRECTORY . DS . 'Offer_' . $timestamp;
                $dir = $this->createDir($path, 'media');
                $name = 'Offers.xml';
                $path = $dir['path'] . DS . $name;
                $this->offerPath = $path;
                $product = $this->generator->create()->arrayToXml($data);
                $product->save($path);
                $url = $this->endpoint->getEndpoint($this->config->getmode(), 'api/importfile');
                $headers = $this->endpoint->getHeaders($this->config->getApiKey(), 'POST');
                $saveResponse = $this->category->sendFile($path, $url, $headers, 'POST', $name);
                $this->saveResponse($saveResponse, 'offer_creation');
                $response = true;
            }
        } catch (\Exception $e) {
            if ($this->debugMode == true) {
                $this->logger->error($e->getMessage(), ['path' => __METHOD__, 'trace' => $e->getTraceAsString()]);
            }
        }

        return $response;
    }

    /**
     * @param $name
     * @return bool
     */
    public function sendOfferPackage($name)
    {
        try {
            $response = true;
            $userName = $this->config->getUserName();
            $password = $this->config->getUserPassword();
            $client = $this->apiClient->create(['username' => $userName, 'password' => $password]);
            $url = $this->urlBuilder->getBaseUrl(['_type' => \Magento\Framework\UrlInterface::URL_TYPE_MEDIA]) .
                'exporter/' . $name;
            $token = $client->init();
            if (!empty($token)) {
                $offerPoint = $client->getOfferPoint();
                $submitOfferPackageResponse = $offerPoint->submitOfferPackage($url);
                if ($this->debugMode == true) {
                    $this->logger->info('Product Offer package sent.',
                        ['response' => (array)$submitOfferPackageResponse, 'method' => __METHOD__,
                            'package_name' => $name]);
                }
                $packageId = $submitOfferPackageResponse->getPackageId();
                if ($packageId) {
                    $getOfferPackageSubmissionResultResponse =
                        $offerPoint->getOfferPackageSubmissionResult((int)$packageId);
                    $this->saveResponse($getOfferPackageSubmissionResultResponse, 'OfferPackage');
                } else {
                    $response = false;
                    if ($this->debugMode == true) {
                        $this->logger->error($submitOfferPackageResponse->getErrorMessage());
                    }
                }
            }
        } catch (\Exception $e) {
            if ($this->config->getDebugMode() == true) {
                $this->config->logger->error($e->getMessage(), ['path' => __METHOD__, 'data' => $e->getTraceAsString()]);
            }
        }

        return $response;
    }

    /**
     * @param array $ids
     */
    public function syncFeeds($ids = [])
    {
        try {
            if (isset($ids) && !empty($ids)) {
                $feeds = $this->feeds->create()->getCollection()
                    ->addFieldToFilter('feed_id', ['in' => $ids]);
                if ($feeds->getSize() > 0) {
                    foreach ($feeds as $feed) {
                        if ($feed->getType() == 'product_creation') {
                            $this->path = $feed->getFeedFile();
                            $arrUrlParams = ['importFileId' => $feed->getFeedId()];
                            $urlParams = http_build_query($arrUrlParams);
                            $endpoint =
                                $this->endpoint->getEndpoint($this->config->getmode(),
                                    'api/importfilevalidation');
                            $endpoint .= "?{$urlParams}";
                            $headers =
                                $this->endpoint->getHeaders($this->config->getApiKey(),
                                    'GET', 'json');
                            $response =
                                $this->category->sendFile(false, $endpoint, $headers, 'GET');
                            $this->saveResponse($response, 'product_creation', $feed->getFeedId());
                        } elseif ($feed->getType() == 'offer_creation') {
                            $this->offerPath = $feed->getFeedFile();
                            $arrUrlParams = ['importFileId' => $feed->getFeedId()];
                            $urlParams = http_build_query($arrUrlParams);
                            $endpoint =
                                $this->endpoint->getEndpoint($this->config->getmode(),
                                    'api/importfilevalidation');
                            $endpoint .= "?{$urlParams}";
                            $headers =
                                $this->endpoint->getHeaders($this->config->getApiKey(),
                                    'GET', 'json');
                            $response =
                                $this->category->sendFile(false, $endpoint, $headers, 'GET');
                            $this->saveResponse($response, 'offer_creation', $feed->getFeedId());
                        }
                    }
                }
            }
        } catch (\Exception $exception) {
            if ($this->debugMode == true) {
                $this->logger->error($exception->getMessage(), ['path' => __METHOD__, 'feeds' => $ids]);
            }
        }
    }


    public function approveFeed($ids = [])
    {
        try {
            if (isset($ids) && !empty($ids)) {
                $message = '';
                $feeds = $this->feeds->create()->getCollection()
                    ->addFieldToFilter('feed_id', ['in' => $ids]);
                if ($feeds->getSize() > 0) {
                    foreach ($feeds as $feed) {
                        if ($feed->getType() == 'product_creation') {
                            $this->path = $feed->getFeedFile();
                            $arrUrlParams = ['importFileId' => $feed->getFeedId()];
                            $urlParams = http_build_query($arrUrlParams);
                            $endpoint =
                                $this->endpoint->getEndpoint($this->config->getmode(),
                                    'api/importfile');
                            $endpoint .= "?{$urlParams}";
                            $headers =
                                $this->endpoint->getHeaders($this->config->getApiKey(),
                                    'PUT', 'json');
                            $response =
                                $this->category->sendFile(false, $endpoint, $headers, 'PUT');
                            //print_r($response);die;
                            if (isset($response['data']) && !empty($response['data'])) {
                                $datares = json_decode($response['data'], true);
                                if (isset($datares['Message']) || isset($datares['message'])) {
                                    $message = isset($datares['Message']) ? $datares['Message'] : $datares['message'];
                                } else {
                                    $message = 'Verification Failed';
                                }
                            }

                        } elseif ($feed->getType() == 'offer_creation') {
                            $this->offerPath = $feed->getFeedFile();
                            $arrUrlParams = ['importFileId' => $feed->getFeedId()];
                            $urlParams = http_build_query($arrUrlParams);
                            $endpoint =
                                $this->endpoint->getEndpoint($this->config->getmode(),
                                    'api/importfile');
                            $endpoint .= "?{$urlParams}";
                            $headers =
                                $this->endpoint->getHeaders($this->config->getApiKey(),
                                    'PUT', 'json');
                            $response =
                                $this->category->sendFile(false, $endpoint, $headers, 'PUT');
                            if (isset($response['data']) && !empty($response['data'])) {
                                $datares = json_decode($response['data'], true);
                                if (isset($datares['Message']) || isset($datares['message'])) {
                                    $message = isset($datares['Message']) ? $datares['Message'] : $datares['message'];
                                } else {
                                    $message = 'Verification Failed';
                                }
                            }
                        }
                        $saveFeed = $this->feeds->create()->load($feed->getId());
                        $saveFeed->setData('approval_status', $message);
                        $saveFeed->save();
                    }

                }
            }
        } catch (\Exception $exception) {
            //print_r($exception->getMessage());die;
            if ($this->debugMode == true) {
                $this->logger->error($exception->getMessage(), ['path' => __METHOD__, 'feeds' => $ids]);
            }
        }
    }

    public function sendProductPackage($name)
    {
        try {
            $response = true;
            $userName = $this->config->getUserName();
            $password = $this->config->getUserPassword();
            $client = $this->apiClient->create(['username' => $userName, 'password' => $password]);
            $url = $this->urlBuilder->getBaseUrl(['_type' => \Magento\Framework\UrlInterface::URL_TYPE_MEDIA]) .
                'exporter/' . $name;
            $token = $client->init();
            if (!empty($token)) {
                $productPoint = $client->getProductPoint();
                $submitProductPackageResponse = $productPoint->submitProductPackage($url);
                if ($this->debugMode == true) {
                    $this->logger->info('Product Package', ['response' =>
                        (array)$submitProductPackageResponse, 'method' => __METHOD__, 'package_name' => $name]);
                }
                $packageId = $submitProductPackageResponse->getPackageId();
                if ($packageId) {
                    $getProductPackageSubmissionResultResponse = $productPoint
                        ->getProductPackageSubmissionResult($packageId);
                    $this->saveResponse($getProductPackageSubmissionResultResponse, 'ProductPackage');
                } else {
                    $response = false;
                    if ($this->debugMode == true) {
                        $this->logger->error($submitProductPackageResponse->getErrorMessage(), ['path' => __METHOD__]);
                    }
                }
            }
        } catch (\Exception $exception) {
            if ($this->config->getDebugMode() == true) {
                $this->config->logger->error($exception->getMessage(),
                    ['path' => __METHOD__, 'data' => $exception->getTraceAsString()]);
            }
        }
        return $response;
    }

    public function getFile($path, $name = null)
    {

        if (!file_exists($path)) {
            @mkdir($path, 0775, true);
        }

        if ($name != null) {
            $path = $path . DS . $name;

            if (!file_exists($path)) {
                @file_put_contents($path, '');
            }
        }

        return $path;
    }

    public function createZip($source, $destination)
    {
        try {
            // Initialize archive object
            $zip = new \ZipArchive();
            $zip->open($destination, \ZipArchive::CREATE | \ZipArchive::OVERWRITE);

            // Create recursive directory iterator
            /** @var \SplFileInfo[] $files */
            $files = new \RecursiveIteratorIterator(
                new \RecursiveDirectoryIterator($source),
                \RecursiveIteratorIterator::LEAVES_ONLY
            );

            foreach ($files as $name => $file) {
                // Skip directories (they would be added automatically)
                if (!$file->isDir()) {
                    // Get real and relative path for current file
                    $filePath = $file->getRealPath();
                    $relativePath = substr($filePath, strlen($source) + 1);

                    // Add current file to archive
                    if ($zip->addFile($filePath, $relativePath) === false) {

                    }
                }
            }
            // Zip archive will be created only after closing object
            $zip->close();

            return true;
        } catch (\Exception $e) {
            return false;
        }

    }

    public function deleteProducts($ids = [])
    {
        try {
            $userName = $this->config->getUserName();
            $password = $this->config->getUserPassword();
            $client = $this->apiClient->create(['username' => $userName, 'password' => $password]);
            $token = $client->init();

            if (!empty($ids)) {
                $sku = [];
                foreach ($ids as $id) {
                    $product = $this->product->create()
                        ->setStoreId($this->selectedStore)
                        ->load($id);
                    $this->ids[] = $product->getId();
                    // configurable Product
                    if ($product->getTypeId() == 'configurable' &&
                        $product->getVisibility() != 1
                    ) {
                        $configurableProduct = $product;
                        $productType = $configurableProduct->getTypeInstance();
                        $products = $productType->getUsedProducts($configurableProduct);
                        foreach ($products as $product) {
                            $sku[] = $product->getSku();
                        }
                    } elseif ($product->getTypeId() == 'simple' &&
                        $product->getVisibility() != 1
                    ) {
                        $sku[] = $product->getSku();
                    }
                    if (!empty($token)) {
                        if (isset($sku) and !empty($sku)) {
                            $offerPoint = $client->getOfferPoint();
                            $response = $submitPackage = $offerPoint->submitOfferStateAction($sku, 'Unpublish');
                        }
                    }
                }
                if (!$response->hasError()) {
                    $this->updateStatus($this->ids, \Ced\Exporter\Model\Source\Product\Status::NOT_UPLOADED);
                } elseif ($response->hasError()) {
                    return $response->getErrorMessage();
                }
                $response = true;
            }
        } catch (\Exception $e) {
            if ($this->debugMode == true) {
                $this->logger->error($e->getMessage(), ['path' => __METHOD__]);
            }
        }
        return $response;
    }

    public function publishProducts($ids = [])
    {
        try {
            $userName = $this->config->getUserName();
            $password = $this->config->getUserPassword();
            $client = $this->apiClient->create(['username' => $userName, 'password' => $password]);
            $token = $client->init();

            if (!empty($ids)) {
                $sku = [];
                foreach ($ids as $id) {
                    $product = $this->product->create()
                        ->setStoreId($this->selectedStore)
                        ->load($id);
                    $this->ids[] = $product->getId();
                    // configurable Product
                    if ($product->getTypeId() == 'configurable' &&
                        $product->getVisibility() != 1
                    ) {
                        $configurableProduct = $product;
                        $productType = $configurableProduct->getTypeInstance();
                        $products = $productType->getUsedProducts($configurableProduct);
                        foreach ($products as $product) {
                            $sku[] = $product->getSku();
                        }
                    } elseif ($product->getTypeId() == 'simple' &&
                        $product->getVisibility() != 1
                    ) {
                        $sku[] = $product->getSku();
                    }
                    if (!empty($token)) {
                        if (isset($sku) and !empty($sku)) {
                            $offerPoint = $client->getOfferPoint();
                            $response = $submitPackage = $offerPoint->submitOfferStateAction($sku, 'Publish');
                        }
                    }
                }
                if (!$response->hasError()) {
                    $this->updateStatus($this->ids, \Ced\Exporter\Model\Source\Product\Status::LIVE);
                } elseif ($response->hasError()) {
                    return $response->getErrorMessage();
                }
                $response = true;
            }
        } catch (\Exception $e) {
            if ($this->debugMode == true) {
                $this->logger->error($e->getMessage(), ['path' => __METHOD__]);
            }
        }
        return $response;
    }

    public function getCurrenncyCode($country)
    {
        $present = false;
        $codeArray = [
            'se' => 'SEK',
            'dk' => 'DKK',
            'fi' => 'EUR',
            'no' => 'NOK'
        ];

        foreach ($codeArray as $countryKey => $currencyValue) {
            if ($countryKey == $country) {
                $present = $currencyValue;
            }
        }
        return $present;
    }

    public function getLanguageCode($country)
    {
        $present = false;
        $codeArray = [
            'se' => 'sv',
            'dk' => 'da',
            'fi' => 'fi',
            'no' => 'no'
        ];

        foreach ($codeArray as $countryKey => $currencyValue) {
            if ($countryKey == $country) {
                $present = $currencyValue;
            }
        }
        return $present;
    }

    /**
     * @param array $ids
     * @return array
     * @throws \Exception
     */
    public function validateAllProducts($ids = [], $profileId = null)
    {

        $validatedProducts = [
            'simple' => [],
            'configurable' => [],
        ];
        $this->ids = [];
        foreach ($ids as $id) {

            $allPresentCurrencies = $this->currencyModel->getConfigAllowCurrencies();
            $product = $this->product->create()
                ->setStoreId($this->selectedStore)
                ->load($id);


            // Getting product profile

            // 1.1: Getting Parents and loading parent profile and sending product as child.
            $productParents = $this->objectManager
                ->create('Magento\ConfigurableProduct\Model\Product\Type\Configurable')
                ->getParentIdsByChild($product->getId());
            if (!empty($productParents)) {
                /** @var \Ced\Exporter\Helper\Profile $profile */
                $profile = $this->profileHelper->getProfile($productParents[0]);
                if (!empty($profile->getId())) {
                    $product = $this->product->create()
                        ->setStoreId($this->selectedStore)
                        ->load($productParents[0]);
                } else {
                    // 1.1.2: Getting product profile id and sending as simple product.
                    /** @var \Ced\Exporter\Helper\Profile $profile */

                    if (!$profileId) {
                        $profileId = $product->getData(\Ced\Exporter\Helper\Profile::ATTRIBUTE_CODE_PROFILE_ID);
                        $profileId = trim($profileId);
                        $profileId = explode(',', $profileId);
                        if (isset($profileId[0])) {
                            $profileId = $profileId[0];
                        }
                    }
                    $profile = $this->profileHelper->getProfile(
                        $id,
                        $profileId
                    );
                    if (empty($profile->getId())) {
                        $e = [];
                        $e[$product->getSku()] = [
                            'sku' => $product->getSku(),
                            'id' => $product->getId(),
                            'url' => $this->urlBuilder
                                ->getUrl('catalog/product/edit', ['id' => $product->getId()]),
                            'errors' => [['profile_missing' => 'Please assign product to a profile and try again.']]
                        ];
                        $product->setData(\Ced\Exporter\Helper\Profile::ATTRIBUTE_CODE_VALIDATION_ERRORS, $this->json->jsonEncode($e));
                        $product->getResource()
                            ->saveAttribute($product, \Ced\Exporter\Helper\Profile::ATTRIBUTE_CODE_VALIDATION_ERRORS);
                        continue;
                    }
                }
            } else {
                // 1.2: Getting product profile id and sending as simple product.
                /** @var \Ced\Exporter\Helper\Profile $profile */

                if (!$profileId) {
                    $profileId = $product->getData(\Ced\Exporter\Helper\Profile::ATTRIBUTE_CODE_PROFILE_ID);
                    $profileId = trim($profileId);
                    $profileId = explode(',', $profileId);
                    if (isset($profileId[0])) {
                        $profileId = $profileId[0];
                    }
                }
                $profile = $this->profileHelper->getProfile(
                    $id,
                    $profileId
                );
                if (empty($profile->getId())) {
                    $e = [];
                    $e[$product->getSku()] = [
                        'sku' => $product->getSku(),
                        'id' => $product->getId(),
                        'url' => $this->urlBuilder
                            ->getUrl('catalog/product/edit', ['id' => $product->getId()]),
                        'errors' => ['profile_missing' => 'Please assign product to a profile and try again.']
                    ];
                    $product->setData(\Ced\Exporter\Helper\Profile::ATTRIBUTE_CODE_VALIDATION_ERRORS,
                        $this->json->jsonEncode($e));
                    $product->getResource()
                        ->saveAttribute($product,
                            \Ced\Exporter\Helper\Profile::ATTRIBUTE_CODE_VALIDATION_ERRORS);
                    continue;
                }
            }
            // case 1 : for config products
            if ($product->getTypeId() == 'configurable' &&
                $product->getVisibility() != 1
            ) {
                $configurableProduct = $product;
                $sku = $configurableProduct->getSku();

                $parentId = $configurableProduct->getId();
                $productType = $configurableProduct->getTypeInstance();
                $products = $productType->getUsedProducts($configurableProduct);
                $attributes = $productType->getConfigurableAttributesAsArray($configurableProduct);

                $magentoVariantAttributes = [];
                foreach ($attributes as $attribute) {
                    $magentoVariantAttributes[] = $attribute['attribute_code'];
                }
                $exporterVariantAttributes = $profile->getAttributes();
                $errors = [
                    $sku => [
                        'sku' => $sku,
                        'id' => $configurableProduct->getId(),
                        'url' => $this->urlBuilder
                            ->getUrl('catalog/product/edit', ['id' => $configurableProduct->getId()]),
                        'errors' => []
                    ]
                ];
                //common attributes check start
                $commonErrors = [];
                // Taking The Attributes From Configuration Which Are To Be Send From Configurable Products
                /* $requiredAttribute = $this->config->getConfAttrValues();
                 foreach ($profile->getRequiredAttributes() as $attributeId => $validationAttribute) {
                     if (in_array($attributeId, $requiredAttribute)) {
                         $value = $configurableProduct->getData($validationAttribute[self::MAGENTO_ATTRIBUTE_CODE]);
                         if (!isset($value) || empty($value)) {
                             $commonErrors[$attributeId] = 'Common required attribute empty.';
                         }
                     }
                 }*/

                if (!empty($commonErrors)) {
                    $errors[$sku]['errors'][] = $commonErrors;
                }

                //common attributes check end.

                // variant attribute mapping check start.
                $unmappedVariantAttribute = [];
                $mappedVariantAttributes = [];

                foreach ($magentoVariantAttributes as $code) {
                    foreach ($exporterVariantAttributes as $exporterVariantAttribute) {
                        if (isset($exporterVariantAttribute[self::MAGENTO_ATTRIBUTE_CODE]) and
                            $exporterVariantAttribute[self::MAGENTO_ATTRIBUTE_CODE] == $code
                        ) {
                            $mappedVariantAttributes[] = $code;
                            break;
                        }
                    }
                }


                $headerRestriction = $profile->getHeaderRestriction();
                if ($headerRestriction) {
                    foreach ($magentoVariantAttributes as $code) {
                        if (!in_array($code, $mappedVariantAttributes)) {
                            $unmappedVariantAttribute[] = $code;
                        }
                    }
                }


                $exporterVariantAttributesValues = [];
                foreach ($exporterVariantAttributes as $attributeId => $variantAttribute) {
                    if (isset($variantAttribute[self::MAGENTO_ATTRIBUTE_CODE]) and
                        in_array($variantAttribute[self::MAGENTO_ATTRIBUTE_CODE], $mappedVariantAttributes)) {
                        $exporterVariantAttributesValues[$variantAttribute[self::MAGENTO_ATTRIBUTE_CODE]] =
                            $variantAttribute;
                    }
                }
                // variant attribute mapping check end.

                $key = 0;
                foreach ($products as $product) {
                    $errors[$product->getSku()] = [
                        'sku' => $product->getSku(),
                        'id' => $product->getId(),
                        'url' => $this->urlBuilder
                            ->getUrl('catalog/product/edit', ['id' => $product->getId()]),
                        'errors' => []
                    ];
                    $product = $this->product->create()
                        ->setStoreId($this->selectedStore)
                        ->load($product->getId());

                    $productId = $this->validateProduct($product->getId(), $product, $profile, $parentId);

                    // variant attribute option value check start.
                    foreach ($mappedVariantAttributes as $mappedVariantAttribute) {
                        if (isset($exporterVariantAttributesValues[$mappedVariantAttribute]['options'])
                            && !empty($exporterVariantAttributesValues[$mappedVariantAttribute]['options'])) {
                            $valueId = $product->getData($mappedVariantAttribute);
                            $value = $valueId;
                            $defaultValue = "";

                            if (isset($exporterVariantAttributesValues[$mappedVariantAttribute]['default_value']) and
                                !empty($exporterVariantAttributesValues[$mappedVariantAttribute]['default_value'])
                            ) {
                                $defaultValue =
                                    $exporterVariantAttributesValues[$mappedVariantAttribute]['default_value'];
                            }

                            //case 3: magento attribute option value
                            $attr = $product->getResource()->getAttribute($mappedVariantAttribute)
                                ->setStoreId($this->selectedStore);
                            if ($attr && ($attr->usesSource() || $attr->getData('frontend_input') == 'select')) {
                                $value = $attr->getSource()->getOptionText($valueId);
                                if (is_object($value)) {
                                    $value = $value->getText();
                                }
                            }
                            // order of check: default value > option mapping > default magento option value
                            if (!isset($exporterVariantAttributesValues[$mappedVariantAttribute]
                                    ['options'][$defaultValue]) and
                                !isset($exporterVariantAttributesValues[$mappedVariantAttribute]
                                    ['option_mapping'][$valueId]) and
                                !isset($exporterVariantAttributesValues[$mappedVariantAttribute]
                                    ['options'][str_replace("'", "&#39;", $value)])
                            ) {
//                                if (isset($value) && !empty($value)) {
                                //if (!in_array($value, $exporterVariantAttributesValues[$mappedVariantAttribute]['options'])) {
                                $errors[$product->getSku()]['errors'][][$mappedVariantAttribute] =
                                    "attribute has invalid option value: <b> " .
                                    $value . " [" . json_encode($valueId) . "]";
                                //}
//
//                                }
                            }
                        }
                    }
                    // variant attribute option value check end.
                    if (isset($productId['id']) and
                        empty($errors[$sku]['errors']) and
                        empty($errors[$product->getSku()]['errors'])
                    ) {
                        //Check if all mappedAttributes are mapped
                        if (empty($unmappedVariantAttribute)) {
                            $validatedProducts['configurable'][$parentId][$product->getId()]['id'] = $productId['id'];
                            $validatedProducts['configurable'][$parentId][$product->getId()]['type'] = 'configurable';
                            $validatedProducts['configurable'][$parentId][$product->getId()]['variantid'] = $sku;
                            $validatedProducts['configurable'][$parentId][$product->getId()]['parentid'] = $parentId;
                            $validatedProducts['configurable'][$parentId][$product->getId()]['variantattr'] =
                                $mappedVariantAttributes;
                            $validatedProducts['configurable'][$parentId][$product->getId()]['variantattrmapped'] =
                                $exporterVariantAttributesValues;
                            $validatedProducts['configurable'][$parentId][$product->getId()]['isprimary'] = 'false';
                            $validatedProducts['configurable'][$parentId][$product->getId()]['isprimary'] = 'false';
                            $validatedProducts['configurable'][$parentId][$product->getId()]['category'] =
                                $profile->getProfileCategory();
                            $validatedProducts['configurable'][$parentId][$product->getId()]['profile_id'] =
                                $profile->getId();
                            if ($key == 0) {
                                $validatedProducts['configurable'][$parentId][$product->getId()]['isprimary'] = 'true';
                                $key = 1;
                            }
                            $product->setData('exporter_validation_errors',
                                $this->json->jsonEncode('valid'));
                            $product->getResource()
                                ->saveAttribute($product, 'exporter_validation_errors');
                            continue;
                        } else {
                            $errorIndex = implode(", ", $unmappedVariantAttribute);
                            $errors[$product->getSku()]['errors'][][$errorIndex] = [
                                'Configurable attributes not mapped.'];
                        }
                    } elseif (isset($productId['errors'])) {
                        $errors[$product->getSku()]['errors'][] = $productId['errors'];
                        if (!empty($unmappedVariantAttribute)) {
                            $errorIndex = implode(", ", $unmappedVariantAttribute);
                            $errors[$product->getSku()]['errors'][][$errorIndex] = [
                                'Configurable attributes not mapped.'];
                        }
                    }
                }
                if (!empty($errors)) {
                    if (!empty($unmappedVariantAttribute)) {
                        $errorIndex = implode(", ", $unmappedVariantAttribute);
                        $errors[$configurableProduct->getSku()]['errors'][][$errorIndex] = [
                            'Configurable attributes not mapped.'];
                    }
                    $errorsInRegistry = $this->registry->registry('exporter_product_validaton_errors');
                    $this->registry->unregister('exporter_product_validaton_errors');
                    $this->registry->register(
                        'exporter_product_validaton_errors',
                        is_array($errorsInRegistry) ? array_merge($errorsInRegistry, $errors) : $errors
                    );
                    $configurableProduct->setExporterValidationErrors($this->json->jsonEncode($errors));
                    $configurableProduct->getResource()
                        ->saveAttribute($configurableProduct, 'exporter_validation_errors');
                } else {
                    $configurableProduct->setExporterValidationErrors('["valid"]');
                    $configurableProduct->getResource()
                        ->saveAttribute($configurableProduct, 'exporter_validation_errors');
                }
            } elseif ($product->getTypeId() == 'simple' && $product->getVisibility() != 1) {
                // case 2 : for simple products
                $productId = $this->validateProduct($product->getId(), $product, $profile);
                if (isset($productId['id'])) {
                    $validatedProducts['simple'][$product->getId()] = [
                        'id' => $productId['id'],
                        'type' => 'simple',
                        'variantid' => null,
                        'variantattr' => null,
                        'category' => $profile->getProfileCategory(),
                        'profile_id' => $profile->getId()
                    ];
                } elseif (isset($productId['errors']) and is_array($productId['errors'])) {
                    $errors[$product->getSku()] = [
                        'sku' => $product->getSku(),
                        'id' => $product->getId(),
                        'url' => $this->urlBuilder
                            ->getUrl('catalog/product/edit', ['id' => $product->getId()]),
                        'errors' => $productId['errors']
                    ];
                    $errorsInRegistry = $this->registry->registry('exporter_product_validaton_errors');
                    $this->registry->unregister('exporter_product_validaton_errors');
                    $this->registry->register(
                        'exporter_product_validaton_errors',
                        is_array($errorsInRegistry) ? array_merge($errorsInRegistry, $errors) :
                            $errors
                    );
                }
            }
        }
        return $validatedProducts;
    }

    /**
     * @param $id
     * @param null $product
     * @param null $profile
     * @param null $parentId
     * @return bool
     * @throws \Exception
     */
    public function validateProduct($id, $product = null, $profile = null, $parentId = null)
    {
        $validatedProduct = false;

        //if product object is not passed, then load in case of Simple product
        if ($product == null) {
            $product = $this->product->create()
                ->setStoreId($this->selectedStore)
                ->load($id);
        }

        //if profile is not passed, get profile
        if ($profile == null) {
            $profileAtt = \Ced\Exporter\Model\Profile::ATTRIBUTE_CODE_PROFILE_ID;//.'_'.$profileId;
            $profile = $this->profileHelper->getProfile($product->getId(), $product->getData($profileAtt));
        }
        $profileId = $profile->getId();
        $sku = $product->getSku();
        $productArray = $product->toArray();
        $errors = [];


        $allPresentCurrencies = $this->currencyModel->getConfigAllowCurrencies();
        //Case 1: Profile is Available
        if (isset($profileId) && $profileId != false) {
            $category = $profile->getProfileCategory();
            $requiredAttributes = $profile->getRequiredAttributes();
            $headerRestriction = $profile->getHeaderRestriction();


            foreach ($requiredAttributes as $exporterAttributeId => $exporterAttribute) {
                if (!isset($productArray[$exporterAttribute[self::MAGENTO_ATTRIBUTE_CODE]])
                    || empty($productArray[$exporterAttribute[self::MAGENTO_ATTRIBUTE_CODE]]) and
                    empty($exporterAttribute['default_value'])
                ) {
                    // Validation case 2 Empty or blank value check
                    $errors["$exporterAttributeId"] = "Required attribute empty or not mapped. 
                    [{$exporterAttribute[self::MAGENTO_ATTRIBUTE_CODE]}]";
                } elseif (isset($exporterAttribute['options']) &&
                    !empty($exporterAttribute['options'])
                ) {
                    $valueId = $product->getData($exporterAttribute[self::MAGENTO_ATTRIBUTE_CODE]);
                    $value = $valueId;
                    $defaultValue = "";
                    // Case 2: default value from profile
                    if (isset($exporterAttribute['default_value']) &&
                        !empty($exporterAttribute['default_value'])
                    ) {
                        $defaultValue = $exporterAttribute['default_value'];
                    }
                    // Case 3: magento attribute option value
                    $attr = $product->getResource()->getAttribute($exporterAttribute[self::MAGENTO_ATTRIBUTE_CODE])
                        ->setStoreId($this->selectedStore);
                    if ($attr && ($attr->usesSource() || $attr->getData('frontend_input') == 'select')) {
                        $value = $attr->getSource()->getOptionText($valueId);
                        if (is_object($value)) {
                            $value = $value->getText();
                        }
                    }
                    // order of check: default value > option mapping > default magento option value
                    if (!isset($exporterAttribute['options'][$defaultValue]) &&
                        !isset($exporterAttribute['option_mapping'][$valueId]) &&
                        !isset($exporterAttribute['options'][$value])
                    ) {
                        $errors["$exporterAttributeId"] = "Exporter attribute: 
                                [" . $exporterAttribute['name'] .
                            "] mapped with [" . $exporterAttribute[self::MAGENTO_ATTRIBUTE_CODE] .
                            "] has invalid option value: <b> " .
                            json_encode($value) . "/" . json_encode($valueId) .
                            "</b> ";
                    }
                }
            }
            $img = $this->prepareImages($product);
            if (empty($img) and !empty($parentId)) {
                $parentImages = $this->product->create()->load($parentId)->getMediaGalleryImages();
                if ($parentImages->getSize() > 0) {
                    foreach ($parentImages as $parentImage) {
                        $img[] = $parentImage->getUrl();

                    }
                }
            }
            if (empty($img)) {
                $errors["ProductImage"] = "ProductImage Not Available";
            }

            //Setting Errors in product validation attribute

            if (!empty($errors) && $headerRestriction == 1) {
                $validatedProduct['errors'] = $errors;
                $e = [];
                $e[$product->getSku()] = [
                    'sku' => $product->getSku(),
                    'id' => $product->getId(),
                    'url' => $this->urlBuilder
                        ->getUrl('catalog/product/edit', ['id' => $product->getId()]),
                    'errors' => [$errors]
                ];
                $product->setExporterValidationErrors($this->json->jsonEncode($e));
                $product->getResource()
                    ->saveAttribute($product, 'exporter_validation_errors');
            } else {
                // insert product id for status update.
                $this->ids[] = $product->getId();

                $product->setData('exporter_validation_errors', '["valid"]');
                $product->getResource()
                    ->saveAttribute($product, 'exporter_validation_errors');
                $validatedProduct['id'] = $id;
                $validatedProduct['category'] = $category;
            }
        } else {
            //Case 2: Profile is not available, not needed case
            $errors = [
                "sku" => "$sku",
                "id" => "$id",
                "url" => $this->urlBuilder
                    ->getUrl('catalog/product/edit', ['id' => $product->getId()]),
                "errors" =>
                    [
                        "Profile not found" => "Product is not mapped in any exporter profile"
                    ]
            ];
            $validatedProduct['errors'] = $errors;
            $errors = $this->json->jsonEncode([$errors]);
            $product->setData('exporter_validation_errors', $errors);
            $product->getResource()
                ->saveAttribute($product, 'exporter_validation_errors');
        }

        return $validatedProduct;
    }

    public function getposition($code, $rev = false)
    {
        foreach (self::POSITIONS_ARRAY as $key => $value) {
            if (!$rev) {
                if ($key === $code) {
                    return $value;
                }
            } elseif ($rev) {
                if ($code === $value) {
                    return $key;
                }
            }
        }
    }


    public function getMappedAttributeValue($magentoAttribute, $product)
    {
        $attribute = isset($magentoAttribute['magento_attribute_code']) ? $magentoAttribute['magento_attribute_code'] : '';
        $value = '';
        if ($attribute != 'default') {
            $value = $product->getData($attribute);
            $mappedOptions = isset($magentoAttribute['option_mapping']) ? $magentoAttribute['option_mapping'] : array();
            if ($mappedOptions !== '{}' && !empty($mappedOptions)) {
                $mappedOptions = json_decode($mappedOptions, true);
            }
            $attr = $product->getResource()->getAttribute($attribute);
            if ($attr && ($attr->usesSource() && $attr->getData('frontend_input') == 'select')) {
                $value = $attr->getSource()->getOptionText($product->getData($attribute));
                if (is_object($value)) {
                    $value = $value->getText();
                }
            }

        } elseif (isset($magentoAttribute['default_value']) && $magentoAttribute['default_value'] != ' ') {
            $value = $magentoAttribute['default_value'];
        }
        if (empty($value) && isset($magentoAttribute['default_value'])) {
            $value = $magentoAttribute['default_value'];
        }

        if ($attribute == 'Breakdown' && isset($magentoAttribute['default_value'])) {
            $value .= $magentoAttribute['default_value'];
        }

        try {
            // Q10 price
            if ($magentoAttribute['exporter_attribute_name'] == 'Sell Price' && isset($magentoAttribute['default_value'])) {
                $value = $product->getSpecialPrice();
                if (!$value) {
                    $value = $product->getPrice();
                }
                if (!$value) {
                    $value = 0;
                } else {
                    $price = str_replace('price', $value, $magentoAttribute['default_value']);
                    eval('$value = (' . $price . ');');
                    $value = round($value);
                }
            }
            if ($magentoAttribute['exporter_attribute_name'] == 'Retail Price' && isset($magentoAttribute['default_value'])) {
                $value = $product->getSpecialPrice();
                if (!$value) {
                    $value = $product->getPrice();
                }
                if (!$value) {
                    $value = 0;
                } else {
                    $price = str_replace('price', $value, $magentoAttribute['default_value']);
                    eval('$value = (' . $price . ');');
                    $value = round($value);
                }
            }
            // base price
            if ($attribute == 'price' && isset($magentoAttribute['exporter_attribute_name'])
                && $magentoAttribute['exporter_attribute_name'] == 'price') {
                $value = $product->getSpecialPrice();
                if (!$value) {
                    $value = $product->getPrice();
                }
                if (!$value) {
                    $value = 0;
                } else {
                    $price = str_replace('price', $value, $magentoAttribute['default_value']);
                    eval('$value = (' . $price . ');');
                    $value = round($value);
                }
            }
            // Netsea price
            if ($attribute == 'price' && isset($magentoAttribute['exporter_attribute_name'])
                && $magentoAttribute['exporter_attribute_name'] == 'Wholesale price') {
                $value = $product->getSpecialPrice();
                if (!$value) {
                    $value = $product->getPrice();
                }

                if (!$value) {
                    $value = 0;
                } elseif (isset($magentoAttribute['default_value'])) {
                    $price = str_replace('price', $value, $magentoAttribute['default_value']);
                    eval('$value = (' . $price . ');');
                    $value = round($value);
                }

            }
        } catch (\Exception $e) {

            if ($this->config->getDebugMode() == true) {
                $this->logger->error($e->getMessage(),
                    ['path' => __METHOD__, 'trace' => $e->getTraceAsString()]);
            }
        }


        return $value;
    }


    public function convertCurrencyTo($amount, $currentSymbol)
    {
        $amount = str_replace(',', '', $amount);
        $price = $this->priceCurrency->convert($amount, $this->selectedStore, $currentSymbol);
        return $price;
    }

    /**
     * @param $amount
     * @return float
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function convertCurrencyFrom($amount)
    {
        $currentCurrency = $this->storeManagerInterface->getStore()->getCurrentCurrencyCode();
        if ($currentCurrency == 'USD') {
            return $amount;
        }

        $price = $this->directoryHelper->currencyConvert($amount, 'USD', $currentCurrency);
        return (float)$price;
    }


    public function prepareSalesChannelsOffer($product)
    {
        $salesChannel = [];
        $allCurrencies = $this->currencyModel->getConfigAllowCurrencies();
        $price = $this->getPrice($product);
        return $salesChannel;
    }

    public function prepareSalesChannels($product)
    {
        $salesChannel = [];
        $allCurrencies = $this->currencyModel->getConfigAllowCurrencies();

        $price = $this->getPrice($product);

//        $this->logger->error('salesChannel',
//            ['path' => __METHOD__, 'trace' =>
//                ['sales' => $salesChannel, 'selected' => $selectedCountries, 'getCU' => $getCurrency, 'all' => $allCurrencies]]);
        return $salesChannel;
    }

    /**
     * @param $productObject
     * @return array
     */
    public function getPrice($productObject)
    {
        $splprice =
            round((float)$productObject->setStoreId($this->selectedStore)->getFinalPrice(), 2);

        $price =
            round((float)$productObject->setStoreId($this->selectedStore)->getData('price'), 2);

        $splprice = number_format($splprice, 2);
        $price = number_format($price, 2);

        $configPrice = $this->config->getPriceType();

        switch ($configPrice) {
            case 'plus_fixed':
                $fixedPrice = $this->config->getFixedPrice();
                $price = $this->forFixPrice($price, $fixedPrice, 'plus_fixed');
                $splprice = $this->forFixPrice($splprice, $fixedPrice, 'plus_fixed');
                break;

            case 'min_fixed':
                $fixedPrice = $this->config->getFixedPrice();
                $price = $this->forFixPrice($price, $fixedPrice, 'min_fixed');
                $splprice = $this->forFixPrice($splprice, $fixedPrice, 'min_fixed');
                break;

            case 'plus_per':
                $percentPrice = $this->config->getPercentPrice();
                $price = $this->forPerPrice($price, $percentPrice, 'plus_per');
                $splprice = $this->forPerPrice($splprice, $percentPrice, 'plus_per');
                break;

            case 'min_per':
                $percentPrice = $this->config->getPercentPrice();
                $price = $this->forPerPrice($price, $percentPrice, 'min_per');
                $splprice = $this->forPerPrice($splprice, $percentPrice, 'min_per');
                break;

            case 'differ':
                $customPriceAttr = $this->config->getDifferPrice();
                try {
                    $cprice = (float)$productObject->getData($customPriceAttr);
                } catch (\Exception $e) {
                    $this->logger->debug(" Exporter: Product Helper: getExporterPrice() : " .
                        $e->getMessage());
                }
                $price = (isset($cprice) && $cprice != 0) ? $cprice : $price;
                $splprice = $price;
                break;

            default:
                return [
                    'price' => (string)$price,
                    'special_price' => (string)$splprice,
                ];
        }
        return [
            'price' => (string)$price,
            'special_price' => (string)$splprice,
        ];
    }

    /**
     * ForFixPrice
     * @param null $price
     * @param null $fixedPrice
     * @param string $configPrice
     * @return float|null
     */
    public function forFixPrice($price = null, $fixedPrice = null, $configPrice)
    {
        if (is_numeric($fixedPrice) && ($fixedPrice != '')) {
            $fixedPrice = (float)$fixedPrice;
            if ($fixedPrice > 0) {
                $price = $configPrice == 'plus_fixed' ? (float)($price + $fixedPrice)
                    : (float)($price - $fixedPrice);
            }
        }
        return $price;
    }

    /**
     * ForPerPrice
     * @param null $price
     * @param null $percentPrice
     * @param string $configPrice
     * @return float|null
     */
    public function forPerPrice($price = null, $percentPrice = null, $configPrice)
    {
        if (is_numeric($percentPrice)) {
            $percentPrice = (float)$percentPrice;
            if ($percentPrice > 0) {
                $price = $configPrice == 'plus_per' ?
                    (float)($price + (($price / 100) * $percentPrice))
                    : (float)($price - (($price / 100) * $percentPrice));
            }
        }
        return $price;
    }

    /**
     * @param $product
     * @return array
     */
    private function prepareImages($product)
    {
        $productImages = $product->getMediaGalleryImages();
        $mainImage = $product->getData('image');
        $images = [];
        if ($productImages->getSize() > 0) {
            foreach ($productImages as $key => $image) {
                $key = 'Image ' . $key;
                $images[$key] = $image->getUrl();
            }
        }
        return $images;
    }


    /**
     * @param $response
     * @return bool
     */
    public function saveResponse($response, $type, $feedId = 'not_found')
    {
        try {
            $errors = '{}';
            $path = $this->offerPath;
            if ($type == 'product_creation') {
                $path = $this->path;
            }
            $logMessage = json_encode($response, JSON_PRETTY_PRINT);
            $status = \Ced\Exporter\Model\Source\Feed\Status::INTEGRATION_PENDING;
            $data = json_decode($response['data'], true);

            if (isset($data['Message']) && $data['Message'] == 'Maximum request limit for import controller reached') {
                $status = \Ced\Exporter\Model\Source\Feed\Status::QUOTA_EXPIRED;
            }

            if (isset($data['importStatus']) && $data['importStatus'] == 'Waiting for approval') {
                $status = \Ced\Exporter\Model\Source\Feed\Status::INTEGRATION_PENDING;
            }
            if (isset($data['importStatus']) && $data['importStatus'] == 'Imported') {
                $status = \Ced\Exporter\Model\Source\Feed\Status::IMPORTED;
            }
            if (isset($data['importStatus']) && $data['importStatus'] == 'Rejected') {
                $status = \Ced\Exporter\Model\Source\Feed\Status::FAILURE;
                $errors = isset($data['validationResult']) ? json_encode($data['validationResult']) : '{}';
            }
            $packageId = isset($data['ImportId']) ? $data['ImportId'] : $feedId;
            $this->registry->register('exporter_product_errors', $packageId);
            $feedModel = $this->feeds->create()->load($packageId, 'feed_id');
            $feedModel->addData([
                'feed_id' => $packageId,
                'type' => $type,
                'approval_status' => self::APPROVAL_STATUS,
                'feed_response' => $this->json->jsonEncode(
                    ['Body' => $logMessage,
                        'Errors' => $errors]
                ),
                'status' => $status,
                'feed_file' => $path,
                'response_file' => '',
                'feed_created_date' => $this->dateTime->date("Y-m-d"),
                'feed_executed_date' => $this->dateTime->date("Y-m-d"),
                'product_ids' => $this->json->jsonEncode($this->ids)
            ]);
            $feedModel->save();
            if (is_array($this->ids) and !empty($this->ids)) {
                foreach ($this->ids as $id) {
                    $product = $this->product->create()->load($id);
                    if (isset($product)) {
                        $product->setExporterFeedErrors($this->json->jsonEncode($response));
                        $product->getResource()
                            ->saveAttribute($product, 'exporter_feed_errors');
                    }
                }
            }
            return true;
        } catch (\Exception $e) {
            if ($this->debugMode) {
                $this->logger->debug($e->getMessage(), ['path' => __METHOD__]);
            }
        }

        return false;
    }

    /**
     * @param array $ids
     * @return bool
     * @throws \Exception
     */
    public function updatePriceInventory($ids = [])
    {
        $response = false;
        try {
            $timestamp = $this->dateTime->gmtTimestamp();
            $capacity = 0;
            $this->offer = [
                'OfferPackage' => [
                    '_attribute' => [
                        'Name' => "Offer Package " . $timestamp,
                        'PurgeAndReplace' => 'false',
                        'PackageType' => 'StockAndPrice',
                        'xmlns' => 'clr-namespace:Exporter.Service.OfferIntegration.Pivot;assembly=Exporter.Service.OfferIntegration',
                        'xmlns:x' => 'http://schemas.microsoft.com/winfx/2006/xaml'
                    ],
                    '_value' => [
                        'OfferPackage.Offers' => [
                            '_attribute' => [],
                            '_value' => [
                                'OfferCollection' => [
                                    '_attribute' => [
                                        'Capacity' => $capacity
                                    ],
                                    '_value' => []
                                ]
                            ]
                        ]
                    ]
                ]
            ];

            if (!empty($ids)) {
                $this->ids = [];
                foreach ($ids as $id) {
                    $product = $this->product->create()
                        ->setStoreId($this->selectedStore)
                        ->load($id);

                    // Getting product profile

                    // 1.1: Getting Parents and loading parent profile and sending product as child.
                    $productParents = $this->objectManager
                        ->create('Magento\ConfigurableProduct\Model\Product\Type\Configurable')
                        ->getParentIdsByChild($product->getId());
                    if (!empty($productParents)) {
                        /** @var \Ced\Exporter\Helper\Profile $profile */
                        $profile = $this->profileHelper->getProfile($productParents[0]);
                        if (!empty($profile->getId())) {
                            $product = $this->product->create()
                                ->setStoreId($this->selectedStore)
                                ->load($productParents[0]);
                        } else {
                            // 1.1.2: Getting product profile id and sending as simple product.
                            /** @var \Ced\Exporter\Helper\Profile $profile */
                            $profile = $this->profileHelper->getProfile(
                                $id,
                                $product->getData(\Ced\Exporter\Helper\Profile::ATTRIBUTE_CODE_PROFILE_ID)
                            );
                            if (empty($profile->getId())) {
                                continue;
                            }
                        }
                    } else {
                        // 1.2: Getting product profile id and sending as simple product.
                        /** @var \Ced\Exporter\Helper\Profile $profile */
                        $profile = $this->profileHelper->getProfile(
                            $id,
                            $product->getData(\Ced\Exporter\Helper\Profile::ATTRIBUTE_CODE_PROFILE_ID)
                        );
                        if (empty($profile->getId())) {
                            continue;
                        }
                    }

                    $requiredAttributes = $profile->getRequiredAttributes();
                    // configurable Product
                    if ($product->getTypeId() == 'configurable' &&
                        $product->getVisibility() != 1 &&
                        !in_array($product->getId(), $this->ids)
                    ) {
                        $configurableProduct = $product;
                        $childIds = $configurableProduct->getTypeInstance()->getChildrenIds($product->getId());
                        // getting child products
                        $products = $this->collectionFactory->create()->addAttributeToSelect('*')
                            ->addAttributeToFilter('entity_id', ['in' => $childIds]);
                        //preparing data for child products
                        foreach ($products as $product) {
                            $stock = $this->stockState->getStockQty($product->getId(),
                                $product->getStore()->getWebsiteId());
                            $price = $this->getPrice($product);
                            /*$confTypeProdAttr = $this->config->getConfAttrValues();
                            if (in_array('Price', $confTypeProdAttr)) {
                                $price = $this->getPrice($configurableProduct);
                            }*/

                            ++$capacity;
                            $this->offer['OfferPackage']['_value']
                            ['OfferPackage.Offers']['_value']['OfferCollection']['_value'][$this->key] =
                                [
                                    'Offer' => [
                                        '_attribute' => [
                                            'SellerProductId' => $product
                                                ->getData($requiredAttributes
                                                [\Ced\Exporter\Helper\Category::ATTRIBUTE_SELLER_PRODUCT_ID]
                                                [self::MAGENTO_ATTRIBUTE_CODE]),
                                            'ProductEan' => $product
                                                ->getData($requiredAttributes
                                                [\Ced\Exporter\Helper\Category::ATTRIBUTE_EAN]
                                                [self::MAGENTO_ATTRIBUTE_CODE]),
                                            'Stock' => $stock,
                                        ],
                                        '_value' => []
                                    ],
                                ];
                            if ($price['special_price'] == 0) {
                                $this->offer['OfferPackage']['_value']
                                ['OfferPackage.Offers']['_value']
                                ['OfferCollection']['_value'][$this->key]
                                ['Offer']['_attribute']['Price'] = $price['price'];
                            } else {
                                $this->offer['OfferPackage']['_value']
                                ['OfferPackage.Offers']['_value']
                                ['OfferCollection']['_value'][$this->key]
                                ['Offer']['_attribute']['Price'] = $price['special_price'];
                            }
                            $this->ids[$product->getId()] = $product->getId();
                            $this->key++;
                        }
                        $this->ids[$configurableProduct->getId()] = $configurableProduct->getId();
                    } elseif ($product->getTypeId() == 'simple' &&
                        $product->getVisibility() != 1 &&
                        !in_array($product->getId(), $this->ids)
                    ) {
                        $stock = $this->stockState->getStockQty($product->getId(),
                            $product->getStore()->getWebsiteId());
                        $price = $this->getPrice($product);
                        ++$capacity;
                        $this->offer['OfferPackage']['_value']['OfferPackage.Offers']
                        ['_value']['OfferCollection']['_value'][$this->key] =
                            [
                                'Offer' => [
                                    '_attribute' => [
                                        'SellerProductId' => $product
                                            ->getData($requiredAttributes
                                            [\Ced\Exporter\Helper\Category::ATTRIBUTE_SELLER_PRODUCT_ID]
                                            [self::MAGENTO_ATTRIBUTE_CODE]),
                                        'ProductEan' => $product
                                            ->getData($requiredAttributes[\Ced\Exporter\Helper\Category::ATTRIBUTE_EAN]
                                            [self::MAGENTO_ATTRIBUTE_CODE]),
                                        'Stock' => $stock,
                                    ],
                                    '_value' => []
                                ],
                            ];
                        if ($price['special_price'] == 0) {
                            $this->offer['OfferPackage']['_value']
                            ['OfferPackage.Offers']['_value']
                            ['OfferCollection']['_value'][$this->key]
                            ['Offer']['_attribute']['Price'] = $price['price'];
                        } else {
                            $this->offer['OfferPackage']['_value']
                            ['OfferPackage.Offers']['_value']
                            ['OfferCollection']['_value'][$this->key]
                            ['Offer']['_attribute']['Price'] = $price['special_price'];
                        }
                        $this->ids[$product->getId()] = $product->getId();
                        $this->key++;
                    }
                }
                $this->offer['OfferPackage']['_value']
                ['OfferPackage.Offers']['_value']
                ['OfferCollection']['_attribute']['Capacity'] = $capacity;
                $this->createOfferPackage($this->offer);
                $response = true;
            }
        } catch (\Exception $exception) {
            if ($this->config->getDebugMode() == true) {
                $this->logger->error($exception->getMessage(), ['path' => __METHOD__, 'ids' => $ids,
                    'offer' => $this->offer]);
            }
        }
        return $response;
    }

    /**
     * @param array $ids
     * @return bool
     * @throws \DOMException
     * @throws \Exception
     * @throws \Magento\Framework\Exception\FileSystemException
     */
    public function updateOffers($ids = [])
    {
        $this->offer = [
            'request' => [
                '_attribute' => [
                    'xmlns:shoppingmall' => 'http://schemas.exporter.com/product/2.0/shopping-mall.xsd',
                    'xmlnx' => 'http://schemas.exporter.com/integration/0.1/merchant/sku-status/'
                ],
                '_value' => [
                    'skus' => [
                        '_attribute' => [],
                        '_value' => []
                    ]
                ]
            ]
        ];

        $response = false;
        if (!empty($ids)) {
            $this->ids = [];
            foreach ($ids as $id) {
                $product = $this->product->create()
                    ->setStoreId($this->selectedStore)
                    ->load($id);
                $this->ids = $product->getId();

                // configurable Product
                if ($product->getTypeId() == 'configurable' &&
                    $product->getVisibility() != 1) {
                    $profile = $this->profileHelper->getProfile($product->getId(), $product->getExporterProfileId());
                    $basicMappings = $profile->getBasicmappingInfo();

                    $productStatus = $basicMappings['status_product'];
                    $exposeStatus = $basicMappings['product_expose_status'];
                    $configurableProduct = $product;
                    $childIds = $configurableProduct->getTypeInstance()->getChildrenIds($product->getId());
                    // getting child products
                    $products = $this->collectionFactory->create()->addAttributeToSelect('*')
                        ->addAttributeToFilter('entity_id', ['in' => $childIds]);
                    //preparing data for child products
                    foreach ($products as $product) {
                        $channels = $this->prepareSalesChannelsOffer($product);
                        $sku = $product->getSku();
                        $stock = $this->stockState->getStockQty($product->getId(), $product->getStore()->getWebsiteId());
                        $this->offer['request']['_value']['skus']['_value'][$this->key]
                        ['sku_status'] = [
                            '_attribute' => [
                                'sku' => $sku,
                                'status' => $productStatus,
                                'exposure' => $exposeStatus,
                                'inStock' => $stock
                            ],
                            '_value' => [
                                'channels' => [
                                    '_attribute' => [],
                                    '_value' => $channels
                                ]
                            ]
                        ];
                        $this->key++;
                    }
                } elseif ($product->getTypeId() == 'simple' &&
                    $product->getVisibility() != 1) {
                    $profile = $this->profileHelper->getProfile($product->getId(), $product->getExporterProfileId());
                    $basicMappings = $profile->getBasicmappingInfo();
                    $productStatus = $basicMappings['status_product'];
                    $exposeStatus = $basicMappings['product_expose_status'];
                    $channels = $this->prepareSalesChannelsOffer($product);
                    $sku = $product->getSku();
                    $stock = $this->stockState->getStockQty($product->getId(), $product->getStore()->getWebsiteId());
                    $this->offer['request']['_value']['skus']['_value'][$this->key]
                    ['sku_status'] = [
                        '_attribute' => [
                            'sku' => $sku,
                            'status' => $productStatus,
                            'exposure' => $exposeStatus,
                            'inStock' => $stock
                        ],
                        '_value' => [
                            'channels' => [
                                '_attribute' => [],
                                '_value' => $channels
                            ]
                        ]
                    ];

                    $this->key++;
                }
            }
            $this->createOfferPackage($this->offer);
            $response = true;
        }
        return $response;
    }

    /**
     * Update Product Status
     * @param string $status
     * @return bool
     */
    public function updateStatus($ids = [], $status = \Ced\Exporter\Model\Source\Product\Status::UPLOADED)
    {
        if (!empty($ids) and is_array($ids) and
            in_array($status, \Ced\Exporter\Model\Source\Product\Status::STATUS)
        ) {
            $products = $this->product->create()->getCollection()
                ->addAttributeToSelect(['exporter_product_status'])
                ->addAttributeToFilter('entity_id', ['in' => $ids]);
            foreach ($products as $product) {
                $product->setData('exporter_product_status', $status);
                $product->getResource()->saveAttribute($product, 'exporter_product_status');
            }
            return true;
        }
        return false;
    }

    public function generateFeeds($profileIds, $customerId = null)
    {
        foreach ($profileIds as $profileId) {
            $this->generateFeed($profileId, $customerId);
        }
    }

    public function generateFeed($profileId, $customerId = null)
    {

        $feedData = [];
        $productIds = [];
        $header = [];

        try {
            $timeStamp = $this->dateTime->gmtTimestamp();
            $profile = $this->objectManager->create('\Ced\Exporter\Model\Profile')->load($profileId);
            $profileCode = 'No ';
            if ($profile) {
                $profileCode = $profile->getProfileCode();
                $pId = $profile->getId();
            }
            $dir = 'ced/' . $profileId . '/exporter/feed/';
            if ($customerId) {
                $dir = 'ced/' . $profileId . '/' . $customerId . '/exporter/feed/';
            }
            $path = $this->createDir($dir, 'media');
            if (isset($path['status'], $path['path']) && $path['status']) {
                $directory = $path['path'];
                $csv_dir = $directory . '/';
            }
            if (!is_dir($csv_dir)) {
                mkdir($csv_dir, '0777', true);
            }

            $fileName = $profileCode . '_' . $pId . '_' . $timeStamp . '_product.csv';
            $csvFileDir = 'ced/' . $profileId . '/exporter';
            if ($customerId) {
                $csvFileDir = 'ced/' . $profileId . '/' . $customerId . '/exporter';
            }
            $path = $this->createDir($csvFileDir, 'media');
            if (isset($path['status'], $path['path']) && $path['status']) {
                $csvFileDirectory = $path['path'];
                $csv_filedir = $csvFileDirectory . '/';
            }
            if (!is_dir($csv_filedir)) {
                mkdir($csv_filedir, '0777', true);
            }

            $filePath = $csv_filedir . $fileName;
            $file = fopen($filePath, 'w');
            if ($file) {
                $result = $this->productChangeFactory->create()
                    ->addFieldToFilter('profile_id', ['eq' => $profileId]);
                if ($customerId) {
                    $result = $result->addFieldToFilter('customer_id', ['eq' => $customerId]);
                }

                foreach ($result as $row_data) {
                    $productIds[] = $row_data->getProductId();
                    $productType = $row_data->getProductType();
                    if ($productType == 'simple') {
                        $productData = $this->createTestFile($row_data->getProductId(), 'r', null, $profileId, $customerId);
                        $productData = json_decode($productData, true);
                        if (!empty($productData)) {
                            if (count($header) == 0) {
                                $header = array_keys($productData);
                                fputcsv($file, $header);
                            }
                            if (!empty($productData)) {
                                fputcsv($file, $productData);
                            }
                        }
                    } elseif ($productType == 'configurable') {
                        $configurableProductData = $this->createTestFile($row_data->getProductId(), 'r', null, $profileId, $customerId);
                        $configurableProductData = json_decode($configurableProductData, true);
                        if (is_array($configurableProductData)) {
                            foreach ($configurableProductData as $productData) {

                                if (!empty($productData) && is_array($productData)) {
                                    if (count($header) == 0) {
                                        $header = array_keys($productData);
                                        fputcsv($file, $header);
                                    }
                                    fputcsv($file, $productData);
                                } else {
                                    if (count($header) == 0) {
                                        $header = array_keys($productData);
                                        fputcsv($file, $header);
                                    }
                                    fputcsv($file, $configurableProductData);
                                }
                            }
                        }

                    }
                }
                $msg['success'] = "Product Uploaded Successfully ";
                fclose($file);

                $profile = $this->objectManager->create('\Ced\Exporter\Model\Profile')->load($profileId);
                $profileCode = 'No ';
                if ($profile) {
                    $profileCode = $profile->getProfileCode();
                }


                $destination = 'ced/' . $profileId . '/exporter';
                if ($customerId) {
                    $destination = 'ced/' . $profileId . '/' . $customerId . '/exporter';
                }
                $destinationPath = $this->createDir($destination, 'media');
                if (isset($destinationPath['status'], $destinationPath['path']) && $destinationPath['status']) {
                    $destination = $destinationPath['path'];
                }
                if (!is_dir($destination)) {
                    mkdir($destination, '0777', true);
                }

                $zipPath = $this->getFile($destination, $profileCode . '_' . $timeStamp . ".zip");

                if ($this->createZip($directory, $zipPath)) {
                    $this->deleteDir($directory);
                }
                if ($productIds) {
                    $feedData = [
                        'feed_id' => $profileCode,
                        'feed_file' => $zipPath,
                        'response_file' => $filePath,
                        'type' => 'export',
                        'feed_created_date' => $this->dateTime->date('Y-m-d H:i:s'),
                        'product_ids' => implode(',', $productIds),
                    ];
                    if ($customerId) {
                        $feedData['customer_id'] = $customerId;
                    }
                } else {
                    $msg['error'] = "Product not uploaded ";
                }
                try {
                    $this->feeds->create()->addData($feedData)->save();
                } catch (\Exception $e) {
                    $msg['error'] = $e->getMessage();
                }
            } else {
                $msg['error'] = "Product not uploaded ";
            }
        } catch (Exception $e) {
            $msg['error'] = $e->getMessage();
            return $msg;
        }
        return $msg;
    }

    public function deleteDir($dirPath)
    {
        if (!is_dir($dirPath)) {
            throw new InvalidArgumentException("$dirPath must be a directory");
        }
        if (substr($dirPath, strlen($dirPath) - 1, 1) != '/') {
            $dirPath .= '/';
        }
        $files = glob($dirPath . '*', GLOB_MARK);
        foreach ($files as $file) {
            if (is_dir($file)) {
                self::deleteDir($file);
            } else {
                unlink($file);
            }
        }
        rmdir($dirPath);
    }


    public function margeFeeds($allFeedFiles, $profileId)
    {

        $feedData = [];
        $productIds = [];
        $header = false;
        try {
            $date = date("Y-m-d H:i:s");
            $fileName = 'product' . $date . '.csv';
            $dir = 'ced/' . $profileId . '/exporter/' . date("Y-m-d");
            $path = $this->createDir($dir, 'media');
            if (isset($path['status'], $path['path']) && $path['status']) {
                $directory = $path['path'];
                $csv_dir = $directory . '/';
            }
            if (!is_dir($csv_dir)) {
                mkdir($csv_dir, '0777', true);
            }
            $filePath = $csv_dir . $fileName;
            $file = fopen($filePath, 'w');
            if ($file) {
                foreach ($allFeedFiles as $feedFile) {
                    $csvData = $this->csv->getData($feedFile);
                    if (!$header) {
                        $header = true;
                        foreach ($csvData as $productData) {
                            fputcsv($file, $productData);
                        }

                    } else {
                        unset($csvData[0]);
                        foreach ($csvData as $productData) {
                            fputcsv($file, $productData);
                        }
                    }

                }
                $msg['success'] = "Feed Marged Successfully. ";
                fclose($file);

                $feedData = [
                    'feed_file' => $filePath,
                    'type' => 'export',
                    'feed_created_date' => $date,
                    'product_ids' => !empty($productIds) ? implode(',', $productIds) : 'This is marged feed file.',
                ];
                try {
                    $this->feeds->create()->addData($feedData)->save();
                } catch (\Exception $e) {

                }
            } else {
                $msg['error'] = "Feed Not Marged.";
            }
        } catch (Exception $e) {
            $msg['error'] = $e->getMessage();
            return $msg;
        }
        return $msg;
    }

    /**
     * Check if configurations are valid
     * @return boolean
     */
    public function checkForConfiguration()
    {
        return $this->config->isValid();
    }
}
