<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement(EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @category  Ced
 * @package   Ced_Exporter
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 */

namespace Ced\Exporter\Helper;

use Magento\Quote\Model\Quote;

/**
 * Class Order
 *
 * @package Ced\Exporter\Helper
 */
class Order extends \Magento\Framework\App\Helper\AbstractHelper
{

    const SHIPMENT_PROVIDERS = [
        'UPS',
        'USPS',
        'FedEx',
        'Airborne',
        'OnTrac',
        'Other'
    ];

    const DEFAULT_EMAIL = 'customer@exporter.com';

    /**
     * @var \Magento\Framework\objectManagerInterface
     */
    public $objectManager;

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    public $storeManager;
    /**
     * @var \Magento\Customer\Model\CustomerFactory
     */
    public $customerFactory;

    /**
     * @var \Magento\Customer\Api\CustomerRepositoryInterface
     */
    public $customerRepository;

    /**
     * @var \Magento\Catalog\Model\ProductRepository
     */
    public $productRepository;

    /**
     * @var \Magento\Catalog\Model\ProductFactory
     */
    public $product;

    /**
     * @var \Magento\Framework\Json\Helper\Data
     */
    public $json;

    /**
     * @var \Magento\Sales\Model\Service\OrderService
     */
    public $orderService;

    /**
     * @var \Magento\Sales\Controller\Adminhtml\Order\CreditmemoLoaderFactory
     */
    public $creditmemoLoaderFactory;

    /**
     * @var \Magento\Quote\Api\CartManagementInterface
     */
    public $cartManagementInterface;

    /**
     * @var \Magento\Quote\Api\CartRepositoryInterface
     */
    public $cartRepositoryInterface;

    /**
     * @var \Magento\Framework\App\Cache\TypeListInterface
     */
    public $cache;

    /**
     * @var \Magento\CatalogInventory\Api\StockRegistryInterface
     */
    public $stockRegistry;

    /**
     * @var \Ced\Exporter\Model\Orders
     */
    public $orders;

    /**
     * @var \Magento\AdminNotification\Model\Inbox
     */
    public $inbox;

    /**
     * @var
     */
    public $messageManager;

    /**
     * @var \Ced\Exporter\Model\OrderFailed
     */
    public $orderFailed;

    public $orderValidationFactory;

    public $exporter;

    public $orderList;
    public $orderLineList;
    public $validateOrderLineFactory;

    /**
     * @var $config
     */
    public $config;

    /**
     * @var Logger
     */
    public $logger;

    /**
     * \
     *
     * @var \Magento\Framework\Registry
     */
    public $registry;

    public $curl;

    /**
     * Ids of Products
     *
     * @var array $ids
     */
    public $ids = [];

    /**
     * @var \Ced\Exporter\Model\FeedsFactory
     */
    public $feeds;

    /**
     * @var \Magento\Framework\Stdlib\DateTime\DateTime
     */
    public $dateTime;

    public $orderFilter;

    public $endpoint;

    /**
     * Order constructor.
     *
     * @param \Magento\Framework\App\Helper\Context $context
     * @param \Magento\Framework\objectManagerInterface $objectManager
     * @param \Magento\Framework\Stdlib\DateTime\DateTime $dateTime
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Magento\Customer\Model\CustomerFactory $customerFactory
     * @param \Magento\Customer\Api\CustomerRepositoryInterface $customerRepository
     * @param \Magento\Catalog\Model\ProductRepository $productRepository
     * @param \Magento\Catalog\Model\ProductFactory $product
     * @param \Magento\Framework\Json\Helper\Data $json
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Sales\Model\Service\OrderService $orderService
     * @param \Magento\Sales\Controller\Adminhtml\Order\CreditmemoLoaderFactory $creditmemoLoaderFactory
     * @param \Magento\Quote\Api\CartRepositoryInterface $cartRepositoryInterface
     * @param \Magento\Quote\Api\CartManagementInterface $cartManagementInterface
     * @param \Magento\Framework\App\Cache\TypeListInterface $cache
     * @param \Magento\AdminNotification\Model\Inbox $inbox
     * @param \Magento\Framework\Message\ManagerInterface $manager
     * @param \Magento\CatalogInventory\Api\StockRegistryInterface $stockRegistry
     * @param \Ced\Exporter\Model\OrdersFactory $orders
     * @param \Ced\Exporter\Model\FeedsFactory $feedsFactory
     * @param \Ced\Exporter\Model\OrderFailedFactory $orderFailed
     * @param Config $config
     * @param Logger $logger
     */
    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        \Magento\Framework\objectManagerInterface $objectManager,
        \Magento\Framework\Stdlib\DateTime\DateTime $dateTime,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Customer\Model\CustomerFactory $customerFactory,
        \Magento\Customer\Api\CustomerRepositoryInterface $customerRepository,
        \Magento\Catalog\Model\ProductRepository $productRepository,
        \Magento\Catalog\Model\ProductFactory $product,
        \Magento\Framework\Json\Helper\Data $json,
        \Magento\Framework\Registry $registry,
        \Magento\Sales\Model\Service\OrderService $orderService,
        \Magento\Sales\Controller\Adminhtml\Order\CreditmemoLoaderFactory $creditmemoLoaderFactory,
        \Magento\Quote\Api\CartRepositoryInterface $cartRepositoryInterface,
        \Magento\Quote\Api\CartManagementInterface $cartManagementInterface,
        \Magento\Framework\App\Cache\TypeListInterface $cache,
        \Magento\AdminNotification\Model\Inbox $inbox,
        \Magento\Framework\Message\ManagerInterface $manager,
        \Magento\CatalogInventory\Api\StockRegistryInterface $stockRegistry,
        \Ced\Exporter\Model\OrdersFactory $orders,
        \Ced\Exporter\Model\FeedsFactory $feedsFactory,
        \Ced\Exporter\Model\OrderFailedFactory $orderFailed,
        \Ced\Exporter\Helper\Config $config,
        \Ced\Exporter\Helper\Logger $logger,
        \Ced\Exporter\Helper\Endpoint $endpoint,
        \Magento\Framework\HTTP\Client\Curl $curl
    ) {
        parent::__construct($context);
        $this->objectManager = $objectManager;
        $this->storeManager = $storeManager;
        $this->customerFactory = $customerFactory;
        $this->customerRepository = $customerRepository;
        $this->productRepository = $productRepository;
        $this->product = $product;
        $this->endpoint = $endpoint;
        $this->json = $json;
        $this->orderService = $orderService;
        $this->creditmemoLoaderFactory = $creditmemoLoaderFactory;
        $this->cartRepositoryInterface = $cartRepositoryInterface;
        $this->cartManagementInterface = $cartManagementInterface;
        $this->cache = $cache;
        $this->inbox = $inbox;
        $this->messageManager = $manager;
        $this->stockRegistry = $stockRegistry;
        $this->orders = $orders;
        $this->registry = $registry;
        $this->dateTime = $dateTime;
        $this->orderFailed = $orderFailed;
        $this->feeds = $feedsFactory;
        $this->logger = $logger;
        $this->config = $config;
        $this->curl = $curl;
    }



    public function getPackageCarriers()
    {
        return
            [
                [
                    "Id" => 18,
                    "Name" => "BIBAB"
                ],
                [
                    "Id" => 20,
                    "Name" => "Bring CityMail"
                ],
                [
                    "Id" => 19,
                    "Name" => "Bring Express"
                ],
                [
                    "Id" => 2,
                    "Name" => "Bring Parcel"
                ],
                [
                    "Id" => 10,
                    "Name" => "Bussgods"
                ],
                [
                    "Id" => 21,
                    "Name" => "DB Schenker Logistics"
                ],
                [
                    "Id" => 22,
                    "Name" => "DB Schenker PrivPak"
                ],
                [
                    "Id" => 23,
                    "Name" => "DHL Express"
                ],
                [
                    "Id" => 3,
                    "Name" => "DHL Freight"
                ],
                [
                    "Id" => 24,
                    "Name" => "DHL Parcel"
                ],
                [
                    "Id" => 13,
                    "Name" => "DPD"
                ],
                [
                    "Id" => 9,
                    "Name" => "DSV"
                ],
                [
                    "Id" => 11,
                    "Name" => "FedEx"
                ],
                [
                    "Id" => 12,
                    "Name" => "GLS"
                ],
                [
                    "Id" => 26,
                    "Name" => "Helthjem"
                ],
                [
                    "Id" => 8,
                    "Name" => "Itella"
                ],
                [
                    "Id" => 1,
                    "Name" => "Posten"
                ],
                [
                    "Id" => 15,
                    "Name" => "PostenAland"
                ],
                [
                    "Id" => 14,
                    "Name" => "Posti"
                ],
                [
                    "Id" => 6,
                    "Name" => "PostNord"
                ],
                [
                    "Id" => 25,
                    "Name" => "PostNord Logistics"
                ],
                [
                    "Id" => 5,
                    "Name" => "Schenker Privpak"
                ],
                [
                    "Id" => 17,
                    "Name" => "Skanlog"
                ],
                [
                    "Id" => 16,
                    "Name" => "SkyNet Express"
                ],
                [
                    "Id" => 7,
                    "Name" => "TNT"
                ],
                [
                    "Id" => 4,
                    "Name" => "UPS"
                ]
            ];
    }

    /**
     * @return bool
     * @throws \Exception
     * @throws \Magento\Framework\Exception\AlreadyExistsException
     */
    public function importOrders()
    {
        try {
            $endpoint = $this->endpoint->getEndpoint($this->config->getmode(),'api/order/');
            $filters = [
                'DateTimeRangeMin' => $this->dateTime->date('Y-m-d', $this->config->getfetchdate()),
                'DateTimeRangeMax' => $this->dateTime->date('Y-m-d')
            ];
            $filters = http_build_query($filters);
            $endpoint = "{$endpoint}?{$filters}";
            $this->endpoint->setOrderType(true);
            $storeId = $this->config->getStore();
            $store = $this->storeManager->getStore($storeId);
            $websiteId = $this->storeManager->getStore()->getWebsiteId();
            $this->curl->setHeaders([
                'Authorization' => 'api '.$this->config->getApiKey(),
                'Accept' => 'application/json'
            ]);
            $this->curl->get($endpoint);
            $orders = json_decode($this->curl->getBody(), true);
//            print_r(json_decode($this->curl->getBody(), true));die;
            /*$orders = '{
  "OrderDetails": {
    "OrderKey": "19a244b6-97dc-4edf-b7de-760c46257809-64224080",
    "OrderId": 64224080,
    "State": "Invoiced",
    "PaymentStatus": "AwaitingPayment",
    "CreatedDateUtc": "2018-11-11T21:02:58.73",
    "LastModifiedDateUtc": "2018-11-12T08:04:51.133",
    "MerchantId": "19a244b6-97dc-4edf-b7de-760c46257809",
    "CountryCode": "Sweden",
    "CurrencyCode": "SEK",
    "TotalAmount": 561.0,
    "TotalAmountExcludingVat": 448.8,
    "TotalSalesAmount": 619.0,
    "HoursPastDeliverySla": 0,
    "CustomerInfo": {
      "CustomerId": 0,
      "EmailAddress": "",
      "ShippingAddress": {
        "Name": "Eve-Marie Boner",
        "StreetAddress": "Veckovägen 36 Lgh 1201",
        "CoAddress": "",
        "ZipCode": "17762",
        "City": "Järfälla",
        "Country": "SE"
      },
      "BillingAddress": {
        "Name": "Eve-Marie Boner",
        "StreetAddress": "Veckovägen 36 Lgh 1201",
        "CoAddress": "",
        "ZipCode": "17762",
        "City": "Järfälla",
        "Country": "SE"
      },
      "Phones": {
        "PhoneMobile": "+46707493611",
        "PhoneWork": null,
        "PhoneHome": null
      },
      "SocialSecurityNumber": ""
    },
    "OrderRows": [
      {
        "OrderRowId": 1,
        "FulfillmentStatus": "Invoiced",
        "PaymentStatus": "AwaitingPayment",
        "ProductId": "GS144",
        "ProductName": "Swatch Originals INTENSE BLUE GS144",
        "ProductType": "Article",
        "Quantity": 1,
        "DeliveredQuantity": 1,
        "InvoicedQuantity": 1,
        "CancelledQuantity": 0,
        "ReturnedQuantity": 0,
        "PickedQuantity": null,
        "PricePerUnit": 462.0,
        "OrdinaryPricePerUnit": 520.0,
        "VatPerUnit": 92.4,
        "VatPercentage": 25.0000,
        "PackageId": "6309421615",
        "PackageCarrierId": 3,
        "AddonToProductId": null,
        "DebitedAmount": 462.0,
        "CreditedAmount": 0.0,
        "PaidAmount": 0.0,
        "RefundedAmount": 0.0,
        "MerchantCampaignDiscount": []
      },
      {
        "OrderRowId": 2,
        "FulfillmentStatus": "Invoiced",
        "PaymentStatus": "AwaitingPayment",
        "ProductId": "Postage",
        "ProductName": "Postage",
        "ProductType": "Postage",
        "Quantity": 1,
        "DeliveredQuantity": 1,
        "InvoicedQuantity": 1,
        "CancelledQuantity": 0,
        "ReturnedQuantity": 0,
        "PickedQuantity": null,
        "PricePerUnit": 99.0,
        "OrdinaryPricePerUnit": 99.0,
        "VatPerUnit": 19.8,
        "VatPercentage": 25.0000,
        "PackageId": "6309421615",
        "PackageCarrierId": 3,
        "AddonToProductId": null,
        "DebitedAmount": 99.0,
        "CreditedAmount": 0.0,
        "PaidAmount": 0.0,
        "RefundedAmount": 0.0,
        "MerchantCampaignDiscount": []
      }
    ],
    "OrderNotices": [],
    "InvoiceNumbers": [
      "4883331"
    ],
    "TotalVat": 112.2,
    "IsSplitOrder": false
  },
  "Invoices": [
    {
      "Rows": [
        {
          "TotalPaymentAmount": 0.0,
          "TotalCreditNoteAmount": 0.0,
          "Status": "AwaitingPayment",
          "InvoiceRowNumber": 1,
          "OrderRowId": 1,
          "ProductId": "GS144",
          "ProductName": "Swatch Originals INTENSE BLUE GS144",
          "ProductType": "Article",
          "Quantity": 1,
          "PricePerUnit": 462.0,
          "VatPerUnit": 92.4,
          "VatPercentage": 25.0000,
          "TotalAmount": 462.0,
          "TotalVat": 92.4
        },
        {
          "TotalPaymentAmount": 0.0,
          "TotalCreditNoteAmount": 0.0,
          "Status": "AwaitingPayment",
          "InvoiceRowNumber": 2,
          "OrderRowId": 2,
          "ProductId": "Postage",
          "ProductName": "Postage",
          "ProductType": "Postage",
          "Quantity": 1,
          "PricePerUnit": 99.0,
          "VatPerUnit": 19.8,
          "VatPercentage": 25.0000,
          "TotalAmount": 99.0,
          "TotalVat": 19.8
        }
      ],
      "Status": "AwaitingPayment",
      "Payments": null,
      "InvoiceNumber": "4883331",
      "MerchantId": "19a244b6-97dc-4edf-b7de-760c46257809",
      "OrderId": 64224080,
      "CustomerId": 10876117,
      "CreatedDateUtc": "2018-11-12T08:04:51.0733995Z",
      "BookingDateUtc": "2018-11-12T08:04:51.0733995Z",
      "TotalAmount": 561.0,
      "TotalVat": 112.2,
      "CurrencyCode": "SEK"
    }
  ]
}';*/

            if (!isset($orders[0])) {
                $orders = [$orders];
            }

            $count = 0;
            if (isset($orders)) {
                foreach ($orders as $order) {
                    $exporterOrderId = $order['OrderDetails']['OrderId'];
                    $exporterOrder = $this->orders->create()
                        ->getCollection()
                        ->addFieldToFilter('exporter_order_id', $exporterOrderId);
                    if (!$this->validateString($exporterOrder->getData())) {
                        $customer = $this->getCustomer($order['OrderDetails']['CustomerInfo'], $websiteId);
                        if ($customer) {
                            $count = $this->generateQuote($store, $customer, $order['OrderDetails'], $count);
                        } else {
                            continue;
                        }
                    }
                }
            }
            if ($count > 0) {
                $this->notificationSuccess($count);
                return true;
            }
        } catch (\Exception $exception) {
            print_r($exception->getMessage());
            die;
            if ($this->config->getDebugMode() == true) {
                $this->logger->error($exception->getMessage(), ['path' => __METHOD__,
                    'trace' => $exception->getTraceAsString()]);
            }
        }

        return false;
    }

    /**
     * @param $string
     * @return bool
     */
    public function validateString($string)
    {
        $stringValidation = (isset($string) && !empty($string)) ? true : false;
        return $stringValidation;
    }

    public function getEmail($order)
    {
        (isset($order['EmailAddress']) && !empty($order['EmailAddress']))
            ? $email = $order['EmailAddress'] :  $email = self::DEFAULT_EMAIL;
        return $email;
    }

    /**
     * @param $order
     * @param $websiteId
     * @return bool|\Magento\Customer\Model\Customer
     */
    public function getCustomer($customreInfo, $websiteId)
    {
        $customerId = $this->config->getDefaultCustomer();
        $billing = $customreInfo['BillingAddress'];

        if ($customerId !== false) {
            // Case 1: Use default customer.
            $customer = $this->customerFactory->create()
                ->setWebsiteId($websiteId)
                ->load($customerId);
            if (!isset($customer) or empty($customer)) {
                $this->logger->log(
                    'ERROR',
                    "Default Customer does not exists. Customer Id: #{$customerId}."
                );
                return false;
            }
        } else {
            // Case 2: Use Customer from Order.
            $email = $this->getEmail($customreInfo);
            // Case 2.1 Get Customer if already exists.
            $customer = $this->customerFactory->create()
                ->setWebsiteId($websiteId)
                ->loadByEmail($email);

            if (!$customer->getData()) {
                // Case 2.1 : Create customer if does not exists.
                try {
                    $customer = $this->customerFactory->create();
                    $customer->setWebsiteId($websiteId);
                    $fullName = isset($billing['Name']) ? $billing['Name'] : '';
                    $customer->setEmail($this->getEmail($customreInfo));
                    $customer->setFirstname($fullName);
                    $customer->setLastname('...');
                    $customer->setPassword("exporterpassword");
                    $customer->save();
                } catch (\Exception $e) {
                    print_r($e->getMessage());die;
                    $this->logger->log(
                        'ERROR',
                        'Customer create failed. Order Id: # Message:' . $e->getMessage()
                    );
                    return false;
                }
            }
        }

        return $customer;
    }

    /**
     * @param $store
     * @param $customer
     * @param int $count
     * @return int
     * @throws \Exception
     * @throws \Magento\Framework\Exception\CouldNotSaveException
     * @throws \Magento\Framework\Exception\LocalizedException
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function generateQuote(
        $store,
        $customer,
        $order = null,
        $count = 0
    ) {
        $cart_id = $this->cartManagementInterface->createEmptyCart();
        $shippingcost = 0;
        /** @var Quote $quote */
        $quote = $this->cartRepositoryInterface->get($cart_id);
        $quote->setStore($store);
        $quote->setCurrency();
        $customer = $this->customerRepository->getById($customer->getId());
        $quote->assignCustomer($customer);
        $itemAccepted = 0;

        $phoneNumber = 123456;
        $exporterCustomer = isset($order['CustomerInfo']) ? $order['CustomerInfo'] : false;
        if (isset($exporterCustomer['Phones']['PhoneMobile']) && !empty($exporterCustomer['Phones']['PhoneMobile'])) {
            $phoneNumber = $exporterCustomer['Phones']['PhoneMobile'];
        } elseif (isset($exporterCustomer['Phones']['PhoneWork']) && !empty($exporterCustomer['Phones']['PhoneWork'])) {
            $phoneNumber = $exporterCustomer['Phones']['PhoneWork'];
        } elseif (isset($exporterCustomer['Phones']['PhoneHome']) && !empty($exporterCustomer['Phones']['PhoneHome'])) {
            $phoneNumber = $exporterCustomer['Phones']['PhoneHome'];
        }

        $shipping = isset($order['CustomerInfo']['ShippingAddress']) ? $order['CustomerInfo']['ShippingAddress'] : false;
        $billing = isset($order['CustomerInfo']['BillingAddress']) ? $order['CustomerInfo']['BillingAddress'] : false;

        $items = isset($order['OrderRows']) ? $order['OrderRows'] : [];
        $reason = [];
        if (isset($items) && !empty($items)) {
            foreach ($items as $item) {
                $sku = isset($item['ProductId']) ? $item['ProductId'] : false;
                if ($sku) {
                    $qty = isset($item['Quantity']) ? $item['Quantity'] : 1;
                    $product = $this->product->create()->loadByAttribute('sku', $sku);
                    if (isset($product) and !empty($product)) {
                        $product = $this->product->create()->load($product->getEntityId());
                        if ($product->getStatus() == '1') {
                            /* Get stock item */
                            $stock = $this->stockRegistry
                                ->getStockItem($product->getId(), $product->getStore()->getWebsiteId());
                            $stockStatus = ($stock->getQty() > 0) ? ($stock->getIsInStock() == '1' ?
                                ($stock->getQty() >= $qty ? true : false)
                                : false) : false;
                            if ($stockStatus) {
                                if (isset($item['FulfillmentStatus']) && $item['FulfillmentStatus'] == 'Pending') {
                                    $itemAccepted++;
                                    $baseprice = $item['PricePerUnit'];

                                    $product->setPrice($baseprice)
                                        ->setBasePrice($baseprice)
                                        ->setOriginalCustomPrice($baseprice)
                                        ->setRowTotal($baseprice)
                                        ->setBaseRowTotal($baseprice);
                                    $product->setData("salable", true);
                                    $quote->addProduct($product, (int)$qty);
                                } else {
                                    $reason[] = "Imvalid Order State {$item['FulfillmentStatus']}";
                                }
                            } else {
                                $reason[] = $sku . "SKU out of stock";
                            }
                        } else {
                            $reason[] = $sku . " SKU not enabled on store";
                        }
                    } else {
                        $reason[] = $sku . "  SKU not exist on store";
                    }
                } else {
                    $reason[] = "SKU not exist in order item";
                }
            }
            if ($itemAccepted == 0) {
                $this->rejectOrder($order, $items, $reason);
            }

            if ($itemAccepted > 0) {
                try {
                    $shipAddress = [
                        'firstname' => $shipping['Name'],
                        'lastname' => '----',
                        'street' => $shipping['StreetAddress'],
                        'city' => $shipping['City'],
                        'country' => $this->getCountryName($shipping['Country']),
                        'country_id' => $shipping['Country'],
                        'postcode' => $shipping['ZipCode'],
                        'telephone' => $phoneNumber,
                        'fax' => '',
                        'save_in_address_book' => 1
                    ];

                    $billAddress = [
                        'firstname' => $billing['Name'],
                        'lastname' => '----',
                        'street' => $billing['StreetAddress'],
                        'city' => $billing['City'],
                        'country' => $this->getCountryName($billing['Country']),
                        'country_id' => $billing['Country'],
                        'postcode' => $billing['ZipCode'],
                        'telephone' => $phoneNumber,
                        'fax' => '',
                        'save_in_address_book' => 1
                    ];
                    $quote->getBillingAddress()->addData($billAddress);
                    $shippingAddress = $quote->getShippingAddress()->addData($shipAddress);
                    $shippingAddress->setCollectShippingRates(true)->collectShippingRates()
                        ->setShippingMethod('shipbyexporter_shipbyexporter');
                    $quote->setPaymentMethod('paybyexporter');
                    $quote->setInventoryProcessed(false);
                    $quote->save();
                    $quote->getPayment()->importData(
                        [
                            'method' => 'paybyexporter'
                        ]
                    );
                    $quote->collectTotals()->save();
                    foreach ($quote->getAllItems() as $item) {
                        $item->setDiscountAmount(0);
                        $item->setBaseDiscountAmount(0);
                        $item->setOriginalCustomPrice($item->getPrice())
                            ->setOriginalPrice($item->getPrice())->save();
                    }
                    $magentoOrder = $this->cartManagementInterface->submit($quote);
                    $magentoOrder->setShippingAmount($shippingcost)
                        ->setBaseShippingAmount($shippingcost)
                        ->setIncrementId($this->config->getOrderIdPrefix() . $magentoOrder->getIncrementId())
                        ->save();
                    $count = isset($magentoOrder) ? $count + 1 : $count;
                    foreach ($magentoOrder->getAllItems() as $item) {
                        $item->setOriginalPrice($item->getPrice())
                            ->setBaseOriginalPrice($item->getPrice())
                            ->save();
                    }


                    // after save order
                    $orderPlace = substr($order['CreatedDateUtc'], 0, 10);
                    /*$itemArray = [];
                    foreach ($items as $item) {
                        $itemArray = json_encode((array)$item);
                    }*/
                    $orderData = [
                        'exporter_order_id' => $order['OrderId'],
                        'order_place_date' => $orderPlace,
                        'magento_order_id' => $magentoOrder->getId(),
                        'increment_id' => $magentoOrder->getIncrementId(),
                        'status' => \Ced\Exporter\Model\Source\Order\Status::IMPORTED,
                        'order_data' => json_encode($order),
                        'order_items' => json_encode($items)
                    ];
                    $this->orders->create()->addData($orderData)->save($this->orders);
                    $this->sendMail($order['OrderId'], $magentoOrder->getIncrementId(), $orderPlace);
                    $this->generateInvoice($magentoOrder);
                } catch (\Exception $exception) {
                    $this->logger->log('ERROR', $exception->getMessage());
                }
            }
        }

        return $count;
    }


    public function getCountryName($code) {
        $countryName = 'United States';
        $countryArray = [
            'SE' => 'Sweden',
            'DK' => 'Den Mark',
            'FI' => 'Finland',
            'NO' => 'Norway'
        ];
        foreach ($countryArray as $countryCode => $countryValue) {
            if ($countryCode == $code) {
                $countryName = $countryValue;
            }
        }
        return $countryName;
    }

    public function acknowledgeOrders($order)
    {
        die('ACK');
        $response = false;
        $purchaseId = $order->getorderNumber();
        $ordersData = $this->orders->create()->getCollection()
            ->addFieldToFilter('exporter_order_id', $purchaseId)
            ->getData();
        if (isset($ordersData) and !empty($ordersData)) {
            $orderItems = (unserialize($ordersData[0]['order_items']));
            $username = $this->config->getUserName();
            $password = $this->config->getUserPassword();
            $apiClient = $this->exporter->create(
                [
                    'username' => $username,
                    'password' => $password
                ]
            );
            $token = $apiClient->init();
            if (empty($token)) {
                return false;
            }
            $ordersPoint = $apiClient->getOrderPoint();
            $validate = $this->orderValidationFactory->create(
                [
                    'orderNumber' => $purchaseId
                ]
            );
            $validate->setOrderState(\Sdk\Order\OrderStateEnum::AcceptedBySeller);
            $orderLineList = $this->orderLineList;
            foreach ($orderItems as $orderItem) {
                $validateOrderLine = $this->validateOrderLineFactory->create(
                    [
                        'sellerProductId' => $orderItem->getSellerProductId(),
                        'acceptationState' => \Sdk\Order\OrderStateEnum::AcceptedBySeller,
                        'productCondition' => \Sdk\Order\ProductConditionEnum::NewS
                    ]
                );
                $orderLineList->addOrderLine($validateOrderLine);
                $validate->setOrderLineList($orderLineList);
            }
            $orderList = $this->orderList;
            $orderList->addOrder($validate);
            $validateOrderListResponse = $ordersPoint->validateOrderList($orderList);
            if (!$validateOrderListResponse->hasError()) {
                $response = true;
            } else {
                $response = true;
            }
            return $response;
        }
        return true;
    }

    /**
     * @param $order
     * @param array $items
     * @param array $reason
     * @return bool
     * @throws \Exception
     */
    public function rejectOrder($order, $items = [], $reason = [])
    {

        $orderFailed = $this->orderFailed->create()->load($order['OrderId'], 'exporter_order_id');
        $addData = [
            'exporter_order_id' => $order['OrderId'],
            'status' => \Ced\Exporter\Model\Source\Order\Status::CANCELLED,
            'reason' => $this->json->jsonEncode($reason),
            'order_date' => substr($order['CreatedDateUtc'], 0, 10),
            'order_data' => json_encode($order),
            'order_items' => json_encode($items)
        ];
        $orderFailed->addData($addData)->save($this->orderFailed);
        $this->logger->log(
            'ERROR',
            'Order failed request sends to Exporter. Order Id: #' . $order['OrderId']
        );
        return true;
    }

    public function getShipmentProviders()
    {
        $providers = [];
        foreach (self::SHIPMENT_PROVIDERS as $SHIPMENT_PROVIDER) {
            $providers[] = $SHIPMENT_PROVIDER;
        }
        return $providers;
    }

    public function getCancelReasons($type = 'canceled')
    {
        $reasons = [];
        /*$exporterOrder = $this->objectManager->create(
            '\Exporter\Sdk\Order',
            ['config' => $this->config->getApiConfig()]
        );
        $exporterReasons = $exporterOrder->getCancelReasons();
        if (isset($exporterReasons['Reasons'])) {
            foreach ($exporterReasons['Reasons'] as $exporterReason) {
                if (isset($exporterReason['Type']) and $exporterReason['Type'] == $type) {
                    $reasons[] = $exporterReason;
                }
            }
        }*/
        return $reasons;
    }

    /**
     * @param $exporterOrderId
     * @param $mageOrderId
     * @param $placeDate
     * @return bool
     */
    public function sendMail($exporterOrderId, $mageOrderId, $placeDate)
    {
        $body = '<table cellpadding="0" cellspacing="0" border="0">
            <tr> <td> <table cellpadding="0" cellspacing="0" border="0">
                <tr> <td class="email-heading">
                    <h1>You have a new order from Exporter.</h1>
                    <p> Please review your admin panel."</p>
                </td> </tr>
            </table> </td> </tr>
            <tr> 
                <td>
                    <h4>Merchant Order Id' . $exporterOrderId . '</h4>
                </td>
                <td>
                    <h4>Magneto Order Id' . $mageOrderId . '</h4>
                </td>
                <td>
                    <h4>Order Place Date' . $placeDate . '</h4>
                </td>
            </tr>  
        </table>';
        $to_email = $this->scopeConfig->getValue('exporter_config/exporter_order/order_notify_email');
        $subject = 'Imp: New Exporter Order Imported';
        $senderEmail = 'exporteradmin@cedcommerce.com';
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $headers .= 'From: ' . $senderEmail . '' . "\r\n";
        //mail($to_email, $subject, $body, $headers);
        return true;
    }

    /**
     * @param $order
     */
    public function generateInvoice($order)
    {
        $invoice = $this->objectManager->create('Magento\Sales\Model\Service\InvoiceService')
            ->prepareInvoice($order);
        $invoice->register();
        $invoice->save();
        $transactionSave = $this->objectManager->create('Magento\Framework\DB\Transaction')
            ->addObject($invoice)->addObject($invoice->getOrder());
        $transactionSave->save();
        $order->addStatusHistoryComment(__('Notified customer about invoice #%1.', $invoice->getId()))
            ->setIsCustomerNotified(true)->save();
        $order->setStatus('processing')->save();
    }

    /**
     * Ship Exporter Order
     *
     * @param  array $data
     * @return array
     */
    public function shipOrder(array $data = [])
    {
        $response = [
            'success' => false,
            'message' => []
        ];
        $response['message']['Type'] = 'order_shipment';
        $status = '';

        try {
            $username = $this->config->getUserName();
            $password = $this->config->getUserPassword();
            $apiClient = $this->exporter->create(
                [
                    'username' => $username,
                    'password' => $password
                ]
            );
            $token = $apiClient->init();
            if (empty($token)) {
                throw new \Exception('Token Invalid or not found');
            }
            $this->ids = $data['ExporterOrderID'];
            $orderPoint = $apiClient->getOrderPoint();
            $orders = $this->orderValidationFactory->create(
                [
                    'orderNumber' => $data['ExporterOrderID']
                ]
            );

            if (isset($data['ShippingProvider']) and empty($data['ShippingProvider'])) {
                throw new \Exception('ShippingProvider are missing.');
            }


            if (isset($data['TrackingNumber']) and empty($data['TrackingNumber'])) {
                throw new \Exception('TrackingNumber are missing.');
            }

            if (isset($data['TrackingUrl']) and empty($data['TrackingUrl'])) {
                throw new \Exception('TrackingUrl Is Missing');
            }

            $trackingUrl = "<![CDATA[{$data['TrackingUrl']}]]>";
            $orders->setOrderState(\Sdk\Order\OrderStateEnum::Shipped);
            $orders->setCarrierName($data['ShippingProvider']);
            $orders->setTrackingNumber($data['TrackingNumber']);
            $orders->setTrackingUrl($trackingUrl);
            $orderList = $this->orderList;
            $orderLineList = $this->orderLineList;
            $magentoOrder = $this->objectManager
                ->create('\Magento\Sales\Model\Order')->load($data['OrderId']);
            $shipQty = [];
            if (isset($data['OrderItemIds']) and !empty($data['OrderItemIds'])) {
                foreach ($magentoOrder->getAllItems() as $orderItem) {
                    foreach ($data['OrderItemIds'] as $val) {

                        $validateOrderLineList = $this->validateOrderLineFactory->create(
                            [
                                'sellerProductId' => $val['SKU'],
                                'acceptationState' => \Sdk\Order\OrderStateEnum::ShippedBySeller,
                                'productCondition' => \Sdk\Order\ProductConditionEnum::NewS
                            ]
                        );
                        $orderLineList->addOrderLine($validateOrderLineList);
                        $orders->setOrderLineList($orderLineList);
                        if ($orderItem->getSku() == $val['SKU']) {
                            $shipQty[$orderItem->getId()] = $val['Quantity'];
                        }
                    }
                    $orderList->addOrder($orders);
                    $validateOrderListResponse = $orderPoint->validateOrderList($orderList);
                    $status = $validateOrderListResponse;
                }
            } else {
                throw new \Exception('OrderItemIds are missing.');
            }

            //$this->saveResponse($status);
            if ($status->hasError()) {
                $response['message']['Status'] = \Ced\Exporter\Model\Source\Feed\Status::FAILURE;
                $response['message']['Error'] = $status->getErrorMessage();
                $validateOrderResult = $status->getValidateOrderResults();
                if (isset($validateOrderResult)) {
                    foreach ($validateOrderResult->getValidateOrderResultList() as $validateOrder) {
                        $response['message']['OrderNumber'] = $validateOrder->getOrderNumber();
                        if (isset($validateOrder)) {
                            foreach ($validateOrder->getValidateOrderLineResults()->getValidateOrderLineResultList() as $validateOrderLineResult) {
                                $response['message']['SellerProductID'] = $validateOrderLineResult->getSellerProductId();
                                $response['message']['ProductUpdated'] = $validateOrderLineResult->isUpdated();
                            }
                        }
                    }
                }
                $this->saveResponse($response);
            } elseif (!$status->hasError()) {
                //$this->generateShipment($magentoOrder, $shipQty);
                $response['message']['Status'] = \Ced\Exporter\Model\Source\Feed\Status::SUCCESS;
                $response['message']['Error'] = '{}';
                $validateOrderResult = $status->getValidateOrderResults();
                if (isset($validateOrderResult)) {
                    foreach ($validateOrderResult->getValidateOrderResultList() as $validateOrder) {
                        $response['message']['OrderNumber'] = $validateOrder->getOrderNumber();
                        if (isset($validateOrder)) {
                            foreach ($validateOrder->getValidateOrderLineResults()->getValidateOrderLineResultList() as $validateOrderLineResult) {
                                $response['message']['SellerProductID'] = $validateOrderLineResult->getSellerProductId();
                                $response['message']['ProductUpdated'] = $validateOrderLineResult->isUpdated();
                            }
                        }
                    }
                }
                $this->saveResponse($response);
                // Saving fulfillment data.
                $exporterOrder = $this->orders->create()->load($data['OrderId'], 'magento_order_id');

                $data['Response'] = $response['message'];

                $shipments = [];
                if (!empty($exporterOrder->getData('shipments'))) {
                    $shipments = $this->json->jsonDecode($exporterOrder->getData('shipments'));
                }
                $shipments[] = $data;

                $exporterOrder->setData('shipments', $this->json->jsonEncode($shipments));
                $exporterOrder->setData('status', \Ced\Exporter\Model\Source\Order\Status::SHIPPED);
                $exporterOrder->save();
            }
        } catch (\Exception $exception) {
            $response['message'] = $exception->getMessage();
        }

        return $response;
    }

    /**
     * Cancel Exporter Order
     *
     * @param  array $data
     * @return array
     */
    public function cancelOrder(array $data = [])
    {
        $response = [
            'success' => false,
            'message' => []
        ];
        $response['message']['Type'] = 'order_cancellation';

        try {
            $magentoOrder = $this->objectManager
                ->create('\Magento\Sales\Model\Order')->load($data['OrderId']);
            $cancel = [];

            if (isset($data['ExporterOrderId']) and !empty($data['ExporterOrderId'])) {
                $username = $this->config->getUserName();
                $password = $this->config->getUserPassword();
                $apiClient = $this->exporter->create(
                    [
                        'username' => $username,
                        'password' => $password
                    ]
                );
                $token = $apiClient->init();
                if (empty($token)) {
                    throw new \Exception('Token Invalid or not found');
                }
                $this->ids = $data['ExporterOrderId'];
                $orderPoint = $apiClient->getOrderPoint();
                $orders = $this->orderValidationFactory->create(
                    [
                        'orderNumber' => $data['ExporterOrderId']
                    ]
                );
                $orders->setOrderState(\Sdk\Order\OrderStateEnum::ShipmentRefusedBySeller);
                $orderList = $this->orderList;
                $orderLineList = $this->orderLineList;

                $validateOrderLineList = $this->validateOrderLineFactory->create(
                    [
                        'sellerProductId' => $data['SKU'],
                        'acceptationState' => \Sdk\Order\OrderStateEnum::ShipmentRefusedBySeller,
                        'productCondition' => \Sdk\Order\ProductConditionEnum::VeryGoodState
                    ]
                );
                $orderLineList->addOrderLine($validateOrderLineList);
                $orders->setOrderLineList($orderLineList);

                $orderList->addOrder($orders);
                $validateOrderListResponse = $orderPoint->validateOrderList($orderList);
                $status = $validateOrderListResponse;

                //foreach ($data['ExporterOrderId'] as $orderItemId) {
                $orderItemId = $data['ExporterOrderId'];
                // Preparing cancel qty for magento credit memo
                $cancelQty = $data['Quantity'];

                if ($status->hasError()) {
                    $response['message']['Status'] = \Ced\Exporter\Model\Source\Feed\Status::FAILURE;
                    $response['message']['Error'] = $status->getErrorMessage();
                    $validateOrderResult = $status->getValidateOrderResults();
                    if (isset($validateOrderResult)) {
                        foreach ($validateOrderResult->getValidateOrderResultList() as $validateOrder) {
                            $response['message']['OrderNumber'] = $validateOrder->getOrderNumber();
                            if (isset($validateOrder)) {
                                foreach ($validateOrder->getValidateOrderLineResults()->getValidateOrderLineResultList() as $validateOrderLineResult) {
                                    $response['message']['SellerProductID'] = $validateOrderLineResult->getSellerProductId();
                                    $response['message']['ProductUpdated'] = $validateOrderLineResult->isUpdated();
                                }
                            }
                        }
                    }
                    $this->saveResponse($response);
                } elseif (!$status->hasError()) {
                    $this->generateCreditMemo($magentoOrder, $cancelQty);
                    $response['message'][] = $orderItemId . ' Cancelled successfully. ';
                    $response['success'] = true;
                    // Saving fulfillment data.
                    $exporterOrder = $this->orders->create()->load($data['OrderId'], 'magento_order_id');

                    $data['Status'] = \Ced\Exporter\Model\Source\Feed\Status::SUCCESS;
                    $data['Response'] = $response['message'];

                    $cancellations = [];
                    if (!empty($exporterOrder->getData('cancellations'))) {
                        $cancellations = $this->json->jsonDecode($exporterOrder->getData('cancellations'));
                    }
                    $cancellations[] = $data;

                    $exporterOrder->setData('cancellations', $this->json->jsonEncode($cancellations));
                    $exporterOrder->setData('status', \Ced\Exporter\Model\Source\Order\Status::SHIPPED);
                    $exporterOrder->save();
                } else {
                    $response['message'][] = $orderItemId . " " . $status['Error'];
                }
                //}
            } else {
                throw new \Exception('OrderItemIds are missing.');
            }
        } catch (\Exception $exception) {
            $response['message'] = $exception->getMessage();
        }
        return $response;
    }

    /**
     * @param $count
     * @throws \Exception
     * @throws \Magento\Framework\Exception\AlreadyExistsException
     */
    public function notificationSuccess($count)
    {
        $model = $this->inbox;
        $date = date("Y-m-d H:i:s");
        $model->setData('severity', 4);
        $model->setData('date_added', $date);
        $model->setData('title', "New Exporter Orders");
        $model->setData('description', "Congratulation! You have received " . $count . " new orders form Exporter");
        $model->setData('url', "#");
        $model->setData('is_read', 0);
        $model->setData('is_remove', 0);
        $model->getResource()->save($model);
    }

    /**
     * @param $order
     * @param $cancelleditems
     */
    public function generateShipment($order, $cancelleditems)
    {
        $shipment = $this->prepareShipment($order, $cancelleditems);
        if ($shipment) {
            $shipment->register();
            $shipment->getOrder()->setIsInProcess(true);
            try {
                $transactionSave = $this->objectManager->create('Magento\Framework\DB\Transaction')
                    ->addObject($shipment)->addObject($shipment->getOrder());
                $transactionSave->save();
                $order->setStatus('complete')->save();
            } catch (\Exception $e) {
                $this->messageManager->addErrorMessage('Error in saving shipping:' . $e->getMessage());
            }
        }
    }

    /**
     * @param $order
     * @param $cancelleditems
     * @return bool
     */
    public function prepareShipment($order, $cancelleditems)
    {
        $shipment = $this->objectManager->get('Magento\Sales\Model\Order\ShipmentFactory')
            ->create($order, isset($cancelleditems) ? $cancelleditems : [], []);
        if (!$shipment->getTotalQty()) {
            return false;
        }
        return $shipment;
    }

    /**
     * @param $order
     * @param $cancelleditems
     */

    public function generateCreditMemo($order, $cancelleditems)
    {
        foreach ($order->getAllItems() as $orderItems) {
            $items_id = $orderItems->getId();
            $order_id = $orderItems->getOrderId();
        }
        $creditmemoLoader = $this->creditmemoLoaderFactory->create();
        $creditmemoLoader->setOrderId($order_id);
        foreach ($cancelleditems as $item_id => $cancelQty) {
            $creditmemo[$item_id] = ['qty' => $cancelQty];
        }
        $items = [
            'items' => $creditmemo,
            'do_offline' => '1',
            'comment_text' => 'Exporter Cancelled Orders',
            'adjustment_positive' => '0',
            'adjustment_negative' => '0'
        ];
        $creditmemoLoader->setCreditmemo($items);
        $creditmemo = $creditmemoLoader->load();
        $creditmemoManagement = $this->objectManager
            ->create('Magento\Sales\Api\CreditmemoManagementInterface');
        if ($creditmemo) {
            $creditmemo->setOfflineRequested(true);
            $creditmemoManagement->refund($creditmemo, true);
        }
    }

    /**
     * @param $message
     * @throws \Exception
     * @throws \Magento\Framework\Exception\AlreadyExistsException
     */
    public function notificationFailed($message)
    {
        $date = date("Y-m-d H:i:s");
        $model = $this->inbox;
        $model->setData('severity', 1);
        $model->setData('date_added', $date);
        $model->setData('title', "Failed Exporter Order");
        $model->setData('description', "You have one pending order." . $message);
        $model->setData('url', "#");
        $model->setData('is_read', 0);
        $model->setData('is_remove', 0);
        $model->getResource()->save($model);
    }

    public function processOrderItems($order)
    {
        $cancelledIds = [];
        $shippedIds = [];
        $items = [];
        $shipments = [];

        if ($order->getShipments() && is_string($order->getShipments())) {
            $shipments = json_decode($order->getShipments(), true);
        }

        //@todo shipment
        if (isset($shipments) && !empty($shipments)) {
            foreach ($shipments as $shipment) {
                foreach ($shipment['OrderItemIds'] as $ids) {
                    $shippedIds[] = $ids['ProductId'];
                }
            }
        }

        $cancellations = [];
        if ($order->getCancellations() && is_string($order->getCancellations())) {
            $cancellations = json_decode($order->getCancellations(), true);
        }

        if (isset($cancellations) && !empty($cancellations)) {
            foreach ($cancellations as $cancellation) {
                foreach ($cancellation['OrderItemIds'] as $ids) {
                    $cancelledIds[] = $ids['ProductId'];
                }
            }
        }
        $exporterOrderItemsData = json_decode($order->getOrderItems(), true);
        foreach ($exporterOrderItemsData as $orderItem) {
            if (!in_array($orderItem['ProductId'], $shippedIds) and !in_array($orderItem['ProductId'], $cancelledIds)) {
                $items[] = $orderItem;
            }
        }
        return $items;
    }

    /**
     * Save Response to db
     *
     * @param  array $response
     * @return boolean
     */
    public function saveResponse($response = [])
    {
        //remove index if already set.
        $this->registry->unregister('exporter_product_errors');
        if (is_array($response)) {
            try {
                $this->registry->register(
                    'exporter_product_errors',
                    $response['message']
                );
                $feedModel = $this->feeds->create();
                $feedModel->addData(
                    [
                        'feed_id' => $this->dateTime->gmtTimestamp(),
                        'type' => $response['message']['Type'],
                        'feed_response' => $this->json->jsonEncode(
                            ['Body' => json_encode($response), 'Errors' => $response['message']['Error']]
                        ),
                        'status' => $response['message']['Status'],
                        'feed_file' => json_encode($response),
                        'response_file' => json_encode($response),
                        'feed_created_date' => $this->dateTime->date("Y-m-d"),
                        'feed_executed_date' => $this->dateTime->date("Y-m-d"),
                        'product_ids' => $this->json->jsonEncode($this->ids)
                    ]
                );
                $feedModel->save();
                return true;
            } catch (\Exception $e) {
                if ($this->config->debugMode) {
                    $this->logger->debug($e->getMessage());
                }
            }
        }
        return false;
    }
}
