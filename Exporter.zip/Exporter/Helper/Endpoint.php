<?php


/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement (EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @category    Ced
 * @package     Ced_enterprise
 * @author      CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright   Copyright © 2018 CedCommerce. All rights reserved.
 * @license     EULA http://cedcommerce.com/license-agreement.txt
 */

namespace Ced\Exporter\Helper;


class Endpoint
{
    private $orderType = false;
    const SANDBOX_URL = 'https://integration-admin.marketplace.exporter.com/';
    const LIVE_URL = 'https://admin.marketplace.exporter.com/';

    public function getEndpoint($mode, $endpointname)
    {
        if ($mode == 'sandbox') {
            return self::SANDBOX_URL.$endpointname;
        } else {
            return self::LIVE_URL.$endpointname;
        }
    }

    /**
     * @param bool $type
     */
    public function setOrderType($type)
    {
        $this->orderType = $type;
    }

    public function getHeaders($apiKey, $requestType, $contentType = null)
    {
        $apiKey = trim($apiKey);
        $headers = [];
        $headers[] = "Authorization: api {$apiKey}";
        $headers[] = "Accept: application/json";

        if ($requestType == 'PUT') {
            $headers[] = 'Content-Length: 0';
        }

        if ($this->orderType == false) {
            if ($contentType == 'json') {
                $headers[] = 'Content-type: application/json';
            } else {
                $headers[] = 'Content-type: multipart/form-data';
            }
        }
        return $headers;
    }
}