<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement (EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @category    Ced
 * @package     Ced_Exporter
 * @author 		CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright   Copyright CedCommerce (http://cedcommerce.com/)
 * @license      http://cedcommerce.com/license-agreement.txt
 */

namespace Ced\Exporter\Block\Adminhtml\AttributeMappingTemplate\Edit\Tab;

/**
 * Rolesedit Tab Display Block.
 *
 * @SuppressWarnings(PHPMD.LongVariable)
 */
class Categorymapping extends \Magento\Backend\Block\Template
{
    /**
     * @var string
     */
    //protected $_template = 'Ced_Exporter::profile/categorymapping.phtml';


    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Framework\Acl\RootResource $rootResource
     * @param \Magento\Authorization\Model\ResourceModel\Rules\CollectionFactory $rulesCollectionFactory
     * @param \Magento\Authorization\Model\Acl\AclRetriever $aclRetriever
     * @param \Magento\Framework\Acl\AclResource\ProviderInterface $aclResourceProvider
     * @param \Magento\Integration\Helper\Data $integrationData
     * @param array $data
     */


    public function getExporterCategoryId($field='parent_cat_id'){
        $category_id = ''; //Mage::app()->getRequest()->getParam('id');

        $value = $this->_objectManager->create('Ced\Exporter\Model\Categories')->getCollection()->addFieldToFilter('magento_cat_id',$category_id)->getFirstItem();
        $exporter_mapped_id=$value->getData($field);
        $exporter_mapped_id=($exporter_mapped_id === 0?'':$exporter_mapped_id);

        return $exporter_mapped_id;
    }

    public function getFilteredExporterCollection($level){
        return $this->_objectManager->create('Ced\Exporter\Model\Categories')->getCollection()->addFieldToFilter('level' , $level);
    }
}
