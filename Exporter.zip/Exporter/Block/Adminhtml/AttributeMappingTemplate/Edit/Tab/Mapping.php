<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement (EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @category    Ced
 * @package     Ced_Exporter
 * @author 		CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright   Copyright CedCommerce (http://cedcommerce.com/)
 * @license      http://cedcommerce.com/license-agreement.txt
 */
namespace Ced\Exporter\Block\Adminhtml\AttributeMappingTemplate\Edit\Tab;

use Magento\Framework\Data\Form as DataForm;

class Mapping extends \Magento\Backend\Block\Widget\Form\Generic
{
    protected $_formFactory;

    public $_objectManager;

    public $formKey;

    public $template;

    public function __construct(
        \Magento\Backend\Block\Widget\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Data\FormFactory $formFactory,
        \Magento\Framework\ObjectManagerInterface $objectInterface,
        \Magento\Framework\Data\Form\FormKey $formKey,
        \Ced\Exporter\Model\AttributeMappingTemplate $template,
        array $data = []
    ) {
        $this->_coreRegistry = $registry;
        $this->_objectManager = $objectInterface;
        $this->formKey = $formKey;
        $this->template = $template;
        parent::__construct($context,$registry, $formFactory);
    }
    protected function _prepareForm(){

        $form = $this->_formFactory->create();
        $fieldset = $form->addFieldset('category', array('legend'=>__('Attribute Mapping File')));

        $template = $this->_coreRegistry->registry('current_template');
        if(!$template) {
            $data = $this->getRequest()->getParams();
            $template =  $this->template;
            if(isset($data['id'])) {
                $template =   $this->template->load($data['id']);
                $this->_coreRegistry->register('current_template', $template);
            }
        }
        $fieldset->addField('template_file', 'file',
            array(
                'name'      => "template_file",
                'label'     => __('Template File'),
               // 'value'     => $template->getData('template_file'),
                'note' => $template->getData('template_file')
            )
        );

       $fieldset->addField('category_js', 'text', [
                'label'     => __('Category JS Mapping'),
                'class'     => 'action',
                'name'      => 'category_js_mapping'
            ]
        );

        $locations = $form->getElement('category_js');
        $locations->setRenderer(
            $this->getLayout()->createBlock('Ced\Exporter\Block\Adminhtml\AttributeMappingTemplate\Edit\Tab\Attribute\CategoryJs')
        );

        $fieldset = $form->addFieldset('required_attributes', array('legend'=>__('Exporter / Magento Attribute Mapping (Required/Optional mapping)')));

        $fieldset->addField('required_attribute', 'text', [
                'label'     => __('Required Attribute Mapping'),
                'class'     => 'action',
                'name'      => 'required_attribute'
            ]
        );

        $locations = $form->getElement('required_attribute');
        $locations->setRenderer(
            $this->getLayout()->createBlock('Ced\Exporter\Block\Adminhtml\AttributeMappingTemplate\Edit\Tab\Attribute\RequiredattributeBack')
        );


        //$fieldset = $form->addFieldset('config_attributes', array('legend'=>__('Exporter / Magento Attribute Mapping (Variant Attribute Mapping)')));

        /*$fieldset->addField('config_attribute', 'text', [
                'label'     => __('Config Attribute Mapping'),
                'class'     => 'action',
                'name'      => 'required_attribute'
            ]
        );

        $locations = $form->getElement('config_attribute');
        $locations->setRenderer(
            $this->getLayout()->createBlock('Ced\Exporter\Block\Adminhtml\AttributeMappingTemplate\Edit\Tab\Attribute\Configattribute')
        );*/



        //print_r($data->getData('in_group_vendor_old'));die;
        //$form->setValues($data->getData());
        $this->setForm($form);

        return parent::_prepareForm();
    }

    public function getFormKey()
    {
        return $this->formKey->getFormKey();
    }

}