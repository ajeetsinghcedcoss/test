<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement (EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @category    Ced
 * @package     Ced_Exporter
 * @author 		CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright   Copyright CedCommerce (http://cedcommerce.com/)
 * @license      http://cedcommerce.com/license-agreement.txt
 */
namespace Ced\Exporter\Block\Adminhtml\AttributeMappingTemplate\Edit\Tab;

class Info extends \Magento\Backend\Block\Widget\Form\Generic
{
	//protected $_formFactory;
    protected  $_store;
	
    public function __construct(
    		\Magento\Backend\Block\Widget\Context $context,
    		\Magento\Framework\Registry $registry,
    		\Magento\Framework\Data\FormFactory $formFactory,
            \Magento\Store\Model\System\Store $store,
            \Magento\Framework\ObjectManagerInterface $objectInterface,
    		array $data = []
    ) {

    	$this->_coreRegistry = $registry;
    	$this->_objectManager = $objectInterface;
    	$this->_store = $store;
    	parent::__construct($context,$registry, $formFactory);
    }
	protected function _prepareForm(){
		
		$form=$this->_formFactory->create();
		//$form = $this->getForm();

        $template = $this->_coreRegistry->registry('current_template');
        if(!$template) {
            $data = $this->getRequest()->getParams();
            if(isset($data['id'])) {
                $template =  $this->_objectManager->get('Ced\Exporter\Model\AttributeMappingTemplate')->load($data['id']);
                $this->_coreRegistry->register('current_template', $template);
            } else {
                $template =  $this->_objectManager->get('Ced\Exporter\Model\AttributeMappingTemplate');
            }
        }

		$fieldset = $form->addFieldset('template_info', array('legend'=>__('Template Information')));
        $fieldset->addField('template_code', 'text',
            array(
                'name'      => "template_code",
                'label'     => __('Code'),
                'note'  	=> __('For internal use. Must be unique with no spaces'),
                //'class' 	=> 'validate-code',
                'required'  => true,
                'value'     => $template->getData('template_code'),
            )
        );

        $fieldset->addField('template_name', 'text',
            array(
                'name'      => "template_name",
                'label'     => __('Name'),
                'class'     => '',
                'required'  => true,
                'value'    => $template->getData('template_name'),
            )
        );

		$this->setForm($form);
	
		return parent::_prepareForm();
	}
	
}