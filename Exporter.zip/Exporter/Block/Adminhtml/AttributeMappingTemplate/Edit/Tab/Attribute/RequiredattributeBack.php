<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement (EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @category    Ced
 * @package     Ced_Exporter
 * @author 		CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright   Copyright CedCommerce (http://cedcommerce.com/)
 * @license      http://cedcommerce.com/license-agreement.txt
 */

namespace Ced\Exporter\Block\Adminhtml\AttributeMappingTemplate\Edit\Tab\Attribute;

/**
 * Rolesedit Tab Display Block.
 *
 * @SuppressWarnings(PHPMD.LongVariable)
 */
//class Requiredattribute extends \Magento\Backend\Block\Template

class RequiredattributeBack extends \Magento\Backend\Block\Widget implements \Magento\Framework\Data\Form\Element\Renderer\RendererInterface
{

    /**
     * @var string
     */
    protected $_template = 'Ced_Exporter::attributemappingtemplate/attribute/required_attribute.phtml';


    protected  $_objectManager;

    protected  $_coreRegistry;

    protected  $_mappingTemplate;

    protected  $_exporterAttribute;

    public  $json;

    public  $configHelper;

    public  $categoryHelper;


    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\ObjectManagerInterface $objectManager,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Json\Helper\Data $json,
        \Ced\Exporter\Helper\Config $configHelper,
        \Ced\Exporter\Helper\Category $categoryHelper,
        array $data = []

    )
    {
        $this->_objectManager = $objectManager;
        $this->_coreRegistry = $registry;
        $this->json = $json;
        $this->configHelper = $configHelper;
        $this->categoryHelper = $categoryHelper;
        $this->_mappingTemplate = $this->_coreRegistry->registry('current_tepmlate');

        parent::__construct($context, $data);
    }



    /**
     * Prepare global layout
     * Add "Add tier" button to layout
     *
     * @return $this
     */
    protected function _prepareLayout()
    {
        $button = $this->getLayout()->createBlock(
            'Magento\Backend\Block\Widget\Button'
        )->setData(
            [
                'label' => __('Add Attribute'),
                'onclick' => 'return requiredAttributeControl.addItem()',
                'class' => 'add'
            ]
        );
        $button->setName('add_required_item_button');

        $this->setChild('add_button', $button);
        return parent::_prepareLayout();
    }

    /**
     * Retrieve 'add group price item' button HTML
     *
     * @return string
     */
    public function getAddButtonHtml()
    {
        return $this->getChildHtml('add_button');
    }



    /**
     * Retrieve exporter attributes
     *
     * @param int|null $groupId  return name by customer group id
     * @return array|string
     */
    public function getExporterAttributes()
    {
        $attributes = [];
        $requiredAttribute = [];
        $optionalAttribues = [];

        $configAttributeMappingFile = $this->configHelper->getAttributeMappingFile();
        if($this->_mappingTemplate && $this->_mappingTemplate->getId()>0){
            $template_file = $this->_mappingTemplate->getData('template_file');
            $allAttributes = json_decode($this->_mappingTemplate->getData('required_attributes'), true);

            if(isset($allAttributes['required_attributes'])) {
                $attributes[] = [
                    'label' => 'Required Attributes',
                    'value' => $allAttributes['required_attributes']
                    ];
            }

            if(isset($allAttributes['optional_attributes'])) {
                $attributes[] = [
                    'label' => 'Optional Attributes',
                    'value' => $allAttributes['optional_attributes']
                    ];
            }
        }else{
            $template_file = $this->getTemplateFile();
            $attributes = json_decode($this->getAttributes(), true);
        }
        if($configAttributeMappingFile && empty($attributes)){
            $attributes = $this->categoryHelper->getAllAttribute($configAttributeMappingFile);
        }
        if(is_array($attributes)) {
            foreach ($attributes as $attribute) {
                // Required Attributes
                if($attribute && isset($attribute['label']) && $attribute['label'] == 'Required Attributes') {
                    $exporterRequiredAttributes = $attribute['value'];
                    foreach ($exporterRequiredAttributes as $item) {
                        $temp = array();
                        $temp['exporter_attribute_name'] = isset($item['exporter_attribute_name'])? $item['exporter_attribute_name']:'';
                        $temp['magento_attribute_code'] = isset($item['magento_attribute_code'])? $item['magento_attribute_code']:'';
                        $temp['exporter_attribute_type'] = '';
                        $temp['exporter_attribute_enum'] = '';
                        $temp['exporter_attribute_level'] = '';
                        $temp['depends_attribute'] =  '';
                        $temp['default_value'] =  isset($item['default_value'])? $item['default_value']:'';
                        $temp['required'] = true;
                        $requiredAttribute[$temp['exporter_attribute_name']] = $temp;
                    }
                }

                // Optional Attributes
                if($attribute && isset($attribute['label']) && $attribute['label'] == 'Optional Attributes') {
                    $exporterRequiredAttributes = $attribute['value'];
                    foreach ($exporterRequiredAttributes as $item) {
                        $temp = array();
                        $temp['exporter_attribute_name'] = isset($item['exporter_attribute_name'])? $item['exporter_attribute_name']:'';
                        $temp['magento_attribute_code'] = isset($item['magento_attribute_code'])? $item['magento_attribute_code']:'';
                        $temp['exporter_attribute_type'] = '';
                        $temp['exporter_attribute_enum'] = '';
                        $temp['exporter_attribute_level'] = '';
                        $temp['depends_attribute'] =  '';
                        $temp['default_value'] =  isset($item['default_value'])? $item['default_value']:'';
                        $temp['required'] = false;
                        $optionalAttribues[$temp['exporter_attribute_name']] = $temp;
                    }
                }

            }
        }

        if(!isset($this->_exporterAttribute[0]['label'])) {
            $this->_exporterAttribute[] = array(
                'label' => __('Required Attributes'),
                'value' => $requiredAttribute
            );
        }

        if(!isset($this->_exporterAttribute[1]['label'])) {
            $this->_exporterAttribute[] = array(
                'label' => __('Optional Attributes'),
                'value' => $optionalAttribues
            );
        }


        return $this->_exporterAttribute;
    }



    /**
     * Retrieve magento attributes
     *
     * @param int|null $groupId  return name by customer group id
     * @return array|string
     */
    public function getMagentoAttributes()
    {


        $attributes = $this->_objectManager->create('Magento\Catalog\Model\ResourceModel\Product\Attribute\Collection')
            ->getItems();
        $mattributecode = '--please select--';

        $magentoattributeCodeArray[''] =
            [
                'attribute_code' => $mattributecode,
                'attribute_type' => '',
                'input_type' => '',
                'option_values' => ''
            ];
        $magentoattributeCodeArray['default'] =
            [
                'attribute_code' =>"-- Set Default Value --",
                'attribute_type' => '',
                'input_type' => 'input_type',
                'option_values' => ''
            ];

        foreach ($attributes as $attribute){

            $type = "";
            $optionValues = "";
            $attributeOptions = $attribute->getSource()->getAllOptions(false);
            if (!empty($attributeOptions) and is_array($attributeOptions)) {
                $type = " [ select ]";
                foreach ($attributeOptions as &$option) {
                    if (isset($option['label']) and is_object($option['label'])) {
                        $option['label'] = $option['label']->getText();
                    }
                }
                $attributeOptions = str_replace('\'', '&#39;', $this->json->jsonEncode($attributeOptions));
                $optionValues = addslashes($attributeOptions);
            }

            if($attribute->getFrontendInput() =='select' && $optionValues){
                $magentoattributeCodeArray[$attribute->getAttributecode()] =
                    [
                        'attribute_code' => $attribute->getAttributecode(),
                        'attribute_type' => $attribute->getFrontendInput(),
                        'input_type' => 'select',
                        'option_values' => $optionValues,
                    ];
            }
            else{
                $magentoattributeCodeArray[$attribute->getAttributecode()] =
                    [
                        'attribute_code' => $attribute->getAttributecode(),
                        'attribute_type' => $attribute->getFrontendInput(),
                        'input_type' => '',
                        'option_values' => $optionValues,
                    ];
            }
        }
        return $magentoattributeCodeArray;
    }


    public function getExporterAttributeValuesMapping() {

        $data = array();

        if($this->_mappingTemplate && $this->_mappingTemplate->getId()>0) {
            $data = json_decode($this->_mappingTemplate->getRequiredAttributes(), true);
            if(isset($data['required_attributes']) && isset($data['optional_attributes'])) {
                $data = array_merge($data['required_attributes'], $data['optional_attributes']);
            }
            // if mapping is not fund from profile then show requred attribute
            if(empty($data)) {
                $this->_exporterAttribute = $this->getExporterAttributes();
                if(count($this->_exporterAttribute[0]['value'])>0){
                    $data = $this->_exporterAttribute[0]['value'];
                }
            }
        } else {
           /* if(!$this->_exporterAttribute)
                $this->_exporterAttribute = $this->getExporterAttributes();*/
            //  $model = $this->_objectManager->create('Ced\Exporter\Model\Attributes');
            if(count($this->_exporterAttribute[0]['value'])>0){
                $data = $this->_exporterAttribute[0]['value'];
            }
        }
        return $data;

    }


    /**
     * Render form element as HTML
     *
     * @param \Magento\Framework\Data\Form\Element\AbstractElement $element
     * @return string
     */
    public function render(\Magento\Framework\Data\Form\Element\AbstractElement $element)
    {
        $this->setElement($element);
        return $this->toHtml();
    }
}
