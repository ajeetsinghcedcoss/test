<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement (EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @category    Ced
 * @package     Ced_Exporter
 * @author 		CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright   Copyright CedCommerce (http://cedcommerce.com/)
 * @license      http://cedcommerce.com/license-agreement.txt
 */

namespace Ced\Exporter\Block\Adminhtml\AttributeMappingTemplate\Edit\Tab\Attribute;

/**
 * Rolesedit Tab Display Block.
 *
 * @SuppressWarnings(PHPMD.LongVariable)
 */
//class Configattribute extends \Magento\Backend\Block\Template
class Configattribute extends \Magento\Backend\Block\Widget implements \Magento\Framework\Data\Form\Element\Renderer\RendererInterface

{
    /**
     * @var string
     */
    protected $_template = 'Ced_Exporter::attributemappingtemplate/attribute/config_attribute.phtml';


    protected  $_objectManager;

    protected  $_coreRegistry;

    protected  $_mappingTemplate;

    protected  $_exporterAttribute;

    public  $json;


    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\ObjectManagerInterface $objectManager,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Json\Helper\Data $json,
        array $data = []

    )
    {
        $this->_objectManager = $objectManager;
        $this->_coreRegistry = $registry;
        $this->json = $json;

              $this->_mappingTemplate = $this->_coreRegistry->registry('current_template');

        parent::__construct($context, $data);
    }

    /**
     * Prepare global layout
     * Add "Add tier" button to layout
     *
     * @return $this
     */
    protected function _prepareLayout()
    {
        $button = $this->getLayout()->createBlock(
            'Magento\Backend\Block\Widget\Button'
        )->setData(
            ['label' => __('Add Attribute'), 'onclick' => 'return configAttributeControl.addItem()', 'class' => 'add']
        );
        $button->setName('add_required_item_button');

        $this->setChild('add_button', $button);
        return parent::_prepareLayout();
    }

    /**
     * Retrieve 'add group price item' button HTML
     *
     * @return string
     */
    public function getAddButtonHtml()
    {
        return $this->getChildHtml('add_button');
    }



    /**
     * Retrieve exporter attributes
     *
     * @param int|null $groupId  return name by customer group id
     * @return array|string
     */
    public function getExporterConfigAttributes()
    {
        $attributeCollections = $this->_objectManager->create('Ced\Exporter\Model\Confattributes')->getCollection();
        $configAttribute = [];

        foreach ($attributeCollections as $item) {
            $this->_exporterAttribute[$item->getExporterAttributeName()] = $item->getExporterAttributeName();
            $temp = array();
            $temp['exporter_attribute_name'] = $item->getExporterAttributeName();
            $temp['magento_attribute_code'] = $item->getMagentoAttributeCode();
            $temp['exporter_attribute_type'] = $item->getExporterAttributeType();
            $configAttribute[$item->getExporterAttributeName()] = $temp;
        }
        $temp = array();
        $temp['exporter_attribute_name'] = 'numberOfPieces';
        $temp['magento_attribute_code'] = '';
        $temp['exporter_attribute_type'] = '';
        $configAttribute['numberOfPieces'] = $temp;
        $this->_exporterAttribute = $configAttribute;

        return $this->_exporterAttribute;
    }


    /**
     * Retrieve magento attributes
     *
     * @param int|null $groupId  return name by customer group id
     * @return array|string
     */
    public function getMagentoAttributes()
    {
        $attributes = $this->_objectManager->create('Magento\Catalog\Model\ResourceModel\Product\Attribute\Collection')
            ->addFieldToFilter('frontend_input', ['in' => ['select', 'multiselect']])
            /*->getItems()*/;

        $magentoattributeCodeArray = array();
       /* foreach ($attributes as $attribute) {
            $magentoattributeCodeArray[$attribute->getAttributecode()] = $attribute->getAttributecode();
        }*/

        foreach ($attributes as $attribute){

            $type = "";
            $optionValues = "";
            $attributeOptions = $attribute->getSource()->getAllOptions(false);
            if (!empty($attributeOptions) and is_array($attributeOptions)) {
                $type = " [ select ]";
                foreach ($attributeOptions as &$option) {
                    if (isset($option['label']) and is_object($option['label'])) {
                        $option['label'] = $option['label']->getText();
                    }
                }
                $attributeOptions = str_replace('\'', '&#39;', $this->json->jsonEncode($attributeOptions));
                $optionValues = addslashes($attributeOptions);
            }

            if($attribute->getFrontendInput() =='select' && $optionValues){
                $magentoattributeCodeArray[$attribute->getAttributecode()] =
                    [
                        'attribute_code' => $attribute->getAttributecode(),
                        'attribute_type' => $attribute->getFrontendInput(),
                        'input_type' => 'select',
                        'option_values' => $optionValues,
                    ];
            }
            else{
                $magentoattributeCodeArray[$attribute->getAttributecode()] =
                    [
                        'attribute_code' => $attribute->getAttributecode(),
                        'attribute_type' => $attribute->getFrontendInput(),
                        'input_type' => '',
                        'option_values' => $optionValues,
                    ];
            }
        }


        /*$attributes = Mage::getResourceModel('catalog/product_attribute_collection')
            ->addFieldToFilter('frontend_input', ['in' => ['select', 'multiselect']])
            ->getItems();
        $mattributecode =
            $model->getMagentoAttributeCode()!=' ' ? $model->getMagentoAttributeCode() : '--please select--';
        if ($mattributecode == '--please select--') {
            $magentoattributeCodeArray[''] = $mattributecode;
        } else {
            $magentoattributeCodeArray[$mattributecode] = $mattributecode;
        }*/

        /*foreach ($attributes as $attribute) {
            $magentoattributeCodeArray[$attribute->getAttributecode()] = $attribute->getAttributecode();
        }*/

        return $magentoattributeCodeArray;
    }


    public function getExporterAttributeValuesMapping(){

        $data = array();
        if($this->_mappingTemplate && $this->_mappingTemplate->getId()>0){
            $configdata = json_decode($this->_mappingTemplate->getProfileAttributeMapping(), true);
            if(isset($configdata['variant_attributes']))
                $data = $configdata['variant_attributes'];
        }else{
            if(!$this->_exporterAttribute)
                $this->_exporterAttribute = $this->getExporterConfigAttributes();

            //$collection = $this->_objectManager->create('Ced\Exporter\Model\Confattributes')->getCollection()->addFieldToFilter('magento_attribute_code', array('neq' => 'NULL' ));
            foreach($this->_exporterAttribute as $key => $value){
                if(isset($value['magento_attribute_code']) && $value['magento_attribute_code']!=""){
                    $data[] = $value;

                }
            }
        }

        return $data;
    }


    /**
     * Render form element as HTML
     *
     * @param \Magento\Framework\Data\Form\Element\AbstractElement $element
     * @return string
     */
    public function render(\Magento\Framework\Data\Form\Element\AbstractElement $element)
    {
        $this->setElement($element);
        return $this->toHtml();
    }

}
