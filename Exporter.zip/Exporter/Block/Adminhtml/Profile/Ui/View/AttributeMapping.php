<?php

namespace Ced\Exporter\Block\Adminhtml\Profile\Ui\View;

use Ced\Exporter\Helper\Config;
use Magento\Store\Model\StoreManagerInterface;

class AttributeMapping extends \Magento\Backend\Block\Template
{
     /**
     * @var string
     */
    public $_template = 'Ced_Exporter::profile/attribute/attributes.phtml';

    public $_objectManager;

    public $_coreRegistry;

    public $profile;

    public $category;

    public $_exporterAttribute;

    public $request;

    public $json;

    public $magentoAttributes;

    public $storeId;

    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\ObjectManagerInterface $objectManager,
        \Magento\Catalog\Model\ResourceModel\Product\Attribute\CollectionFactory $attributeCollection,
        \Magento\Framework\App\Request\Http $request,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Json\Helper\Data $json,
        \Ced\Exporter\Helper\Config $config,
        \Ced\Exporter\Helper\Profile $profile,
        \Ced\Exporter\Helper\Category $category,
        array $data = []
    ) {
        $this->_objectManager = $objectManager;
        $this->_coreRegistry = $registry;
        $this->category = $category;
        $this->request = $request;
        $this->magentoAttributes = $attributeCollection;
        $id = $this->request->getParam('id');
        $this->profile = $profile->getProfile(null, $id);
        $this->json = $json;
        $this->storeId = $config->getStore();
        parent::__construct($context, $data);
    }

    /**
     * @return mixed
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getAddButtonHtml()
    {
        $button = $this->getLayout()->createBlock(
            'Magento\Backend\Block\Widget\Button'
        )->setData(
            [
                'label' => __('Add Attribute'),
                'onclick' => 'return exporterAttributeControl.addItem()',
                'class' => 'add'
            ]
        );

        $button->setName('exporter_add_attribute_mapping_button');
        return $button->toHtml();
    }

    public function getExporterAttributes()
    {
        // For AJAX
        $this->_exporterAttribute = $this->getAttributes();

        if (isset($this->_exporterAttribute) and !empty($this->_exporterAttribute)) {
            return $this->_exporterAttribute;
        }

        if($this->profile && $this->profile->getId()>0){
            $profileData = $this->profile->getData();
            $profile_required_attributes = isset($profileData['profile_required_attributes']) ?
                $profileData['profile_required_attributes'] : array();
            $profile_optional_attributes = isset($profileData['profile_optional_attributes']) ?
                $profileData['profile_optional_attributes'] : array();

            if(isset($profile_required_attributes)) {
                $this->_exporterAttribute[] = [
                    'label' => 'Required Attributes',
                    'value' => $profile_required_attributes
                ];
            }

            if(isset($profile_optional_attributes)) {
                $this->_exporterAttribute[] = [
                    'label' => 'Optional Attributes',
                    'value' => $profile_optional_attributes
                ];
            }
            return $this->_exporterAttribute;
        }
        $optionalAttributes = $this->category->getAttributes('optional');
        $requiredAttributes = $this->category->getAttributes('required');
        $variantAttributes = $this->category->getAttributes('variant');

        $this->_exporterAttribute[] = [
            'label' => __('Required Attributes'),
            'value' => $requiredAttributes
        ];

        $this->_exporterAttribute[] = [
            'label' => __('Optional Attributes'),
            'value' => $optionalAttributes
        ];
        $this->_exporterAttribute[] = [
            'label' => __('Variant Attributes'),
            'value' => $variantAttributes
        ];
        return $this->_exporterAttribute;
    }

    public function getMagentoAttributes()
    {
        $store = $this->_storeManager->getStore($this->storeId);

        $attributes = $this->magentoAttributes
            ->create()
            ->getItems();
        $magentoAttributes[''] = [
            'name' => "--please select--",
            'code' => "",
            'option_values' => '{}'
        ];
        $magentoAttributes['default'] = [
            'name' => "Set Default Value",
            'code' => "",
            'option_values' => '{}'
        ];
        foreach ($attributes as $attribute) {
            $type = "";
            $optionValues = "{}";
            $attributeOptions = $attribute->setStoreId($store->getId())->getSource()->getAllOptions(false);
            if (!empty($attributeOptions) and is_array($attributeOptions)) {
                $type = " [ select ]";
                foreach ($attributeOptions as &$option) {
                    if (isset($option['label']) and is_object($option['label'])) {
                        $option['label'] = $option['label']->getText();
                    }
                }

                $attributeOptions = str_replace('\'', '&#39;', $this->json->jsonEncode($attributeOptions));
                $optionValues = addslashes($attributeOptions);
            }
            $magentoAttributes[$attribute->getAttributecode()]['code'] = $attribute->getAttributecode();
            $magentoAttributes[$attribute->getAttributecode()]['name'] = is_object($attribute->getStoreLabel($store)) ?
                addslashes($attribute->getStoreLabel($store)->getText() . $type):
                addslashes($attribute->getStoreLabel($store) . $type);
            $magentoAttributes[$attribute->getAttributecode()]['option_values'] = $optionValues;
        }
        return $magentoAttributes;
    }

    public function getMappedAttribute()
    {

        $data = $this->_exporterAttribute[0]['value'];
        if ($this->profile && $this->profile->getId() > 0) {
            $profileData = $this->profile->getData();
            $requiredAttributes = isset($profileData['profile_required_attributes'])?
                $profileData['profile_required_attributes'] :array();
            $optionalAttributes = isset($profileData['profile_optional_attributes'])?
                $profileData['profile_optional_attributes'] :array();
            if (isset($requiredAttributes) and !empty($requiredAttributes)) {
                $data = array_merge($requiredAttributes, $optionalAttributes);
            }
        }
        return $data;
    }

    public function getAjaxUrl()
    {
        return $this->_urlBuilder->getUrl('exporter/profile/options');
    }

    public function getProfileId()
    {
        $pid = $this->profile->getId();
        return $pid;
    }
    /**
     * Render form element as HTML
     *
     * @param \Magento\Framework\Data\Form\Element\AbstractElement $element
     * @return string
     */
    public function render (
        \Magento\Framework\Data\Form\Element\AbstractElement $element
    ) {
        $this->setElement($element);
        return $this->toHtml();
    }
}
