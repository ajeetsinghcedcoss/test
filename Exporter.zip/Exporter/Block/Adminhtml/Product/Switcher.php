<?php

/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement (EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @category  Ced
 * @package   Ced_Exporter
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE (http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 */

namespace Ced\Exporter\Block\Adminhtml\Product;

class Switcher extends \Magento\Backend\Block\Template
{

    /**
     * Block template filename
     *
     * @var string
     */
    protected $_template = 'Ced_Exporter::product/switcher.phtml';


    /**
     * Get active or first link for default display.
     *
     * @return \Magento\Framework\Phrase
     */
    public function getCurrentGridTitle()
    {
       $profileId = $this->getRequest()->getParam('profile_id');

       if($profileId) {
           $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
           $profile = $objectManager->create('\Ced\Exporter\Model\Profile')->load($profileId);
           return __($profile->getProfileName());
       }
         /*  $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
           $profiles = $objectManager->create('\Ced\Exporter\Model\ResourceModel\Profile\Collection')
           ->getFirstItem();
           if($profiles) {
               $profileId = $profiles->getId();
               $profile = $objectManager->create('\Ced\Exporter\Model\Profile')->load($profileId);
               return __($profile->getProfileName());
           }*/

        return  __('Please Select Profile');
    }


    public function getProfiles() {

        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $profiles = $objectManager->create('\Ced\Exporter\Model\ResourceModel\Profile\Collection');
        /*$data['Please Select Profile'] = [
            'title' => 'Please Select Profile',
            'url' => $this->_urlBuilder->getUrl('exporter/product/index', []),
        ];*/
        foreach ($profiles as $profile) {
            $data[$profile->getProfileCode()] = [
                'title' => $profile->getProfileName(),
                'id' => $profile->getId(),
                'url' => $this->_urlBuilder->getUrl('exporter/product/index', ['profile_id' => $profile->getId()]),
                ];
        }
        return $data;
    }
}