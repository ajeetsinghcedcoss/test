<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Ced\Expoter\Block\Adminhtml\Product\Button;

/**
 * Class Back
 */
class Back extends \Magento\Catalog\Block\Adminhtml\Product\Edit\Button\Generic
{

 protected  $_request;


    public function __construct(
        \Magento\Framework\View\Element\UiComponent\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\App\Request\Http $request
    ) {
        $this->context = $context;
        $this->registry = $registry;
        $this->_request = $request;
    }

    /**
     * @return array
     */
    public function getButtonData()
    {
        $id = $this->_request->getParam('profile_id');

        if($id){
            return [
                'label' => __('Back To Profile'),
                'on_click' => sprintf("location.href = '%s';", $this->getUrl('walmart/profile/edit', ['id' => $id])),
                'class' => 'secondry',
                'sort_order' => 10
            ];
        }
        else{
            return [
                'label' => __('Back To Profile'),
                'on_click' => sprintf("location.href = '%s';", $this->getUrl('walmart/profile/index')),
                'class' => 'secondry',
                'sort_order' => 10
            ];
        }
    }
}
