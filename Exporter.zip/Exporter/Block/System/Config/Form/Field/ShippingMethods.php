<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement(EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @category  Ced
 * @package   Ced_Exporter
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 */

namespace Ced\Exporter\Block\System\Config\Form\Field;

class ShippingMethods extends \Magento\Config\Block\System\Config\Form\Field\FieldArray\AbstractFieldArray
{

    /**
     * @var
     */
    protected $_shippingRegion;

    /**
     * @var
     */
    protected $_shippingMethod;

    protected $_magentoAttr;

    protected  $_enabledRenderer;

    protected $_enableStoreRenderer;

    /**
     * @return \Magento\Framework\View\Element\BlockInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    protected function _getEnabledRenderer()
    {
        if (!$this->_enabledRenderer) {
            $this->_enabledRenderer = $this->getLayout()->createBlock(
                'Ced\Exporter\Block\System\Config\Form\Field\ShippingMethodList',
                '',
                ['data' => ['is_render_to_js_template' => true]]
            );
            $this->_enabledRenderer->setClass('shipping_region_select');
            $this->_enabledRenderer->setId('<%- _id %>');
        }
        return $this->_enabledRenderer;
    }

    protected function _getEnabledRendererforStore()
    {
        if (!$this->_enableStoreRenderer) {
            $this->_enableStoreRenderer = $this->getLayout()->createBlock(
                'Ced\Exporter\Block\System\Config\Form\Field\Stores',
                '',
                ['data' => ['is_render_to_js_template' => true]]
            );
            $this->_enableStoreRenderer->setClass('store_region_select');
            $this->_enableStoreRenderer->setId('<%- _id %>');
        }
        return $this->_enableStoreRenderer;
    }

    /**
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    protected function _prepareToRender()
    {

        $this->addColumn(
            'country',
            [
                'label' => __('Countries'),
                'renderer' => $this->_getEnabledRenderer()
            ]
        );
        $this->addColumn('store', ['label' => __('Store'), 'renderer' => $this->_getEnabledRendererforStore()]);
        $this->addColumn('delivery_time_min', ['label' => __('Delivery Time Min')]);
        $this->addColumn('delivery_time_max', ['label' => __('Delivery Time Max')]);
        $this->_addAfter = false;
        $this->_addButtonLabel = __('Add Countries');
    }

    /**
     * @param \Magento\Framework\DataObject $row
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    protected function _prepareArrayRow(\Magento\Framework\DataObject $row)
    {
        $optionExtraAttr = [];

        $optionExtraAttr['option_' . $this->_getEnabledRenderer()->calcOptionHash($row->getData('country'))] =
            'selected="selected"';
        $optionExtraAttr['option_' . $this->_getEnabledRendererforStore()->calcOptionHash($row->getData('store'))] =
            'selected="selected"';
        //print_r($optionExtraAttr);die;
        $row->setData(
            'option_extra_attrs',
            $optionExtraAttr
        );
    }
}
