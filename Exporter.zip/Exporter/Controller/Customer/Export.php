<?php

namespace Ced\Exporter\Controller\Customer;

class Export extends \Magento\Framework\App\Action\Action
{
    const CHUNK_SIZE = 50;

    public $filter;
    public $catalogCollection;
    public $session;
    public $customerSession;
    public $productHelper;
    public $redirectFactory;
    public $resultJsonFactory;
    public $resultPageFactory;
    public $config;
    public $registry;

    /**
     * Export constructor.
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Customer\Model\Session $customerSession
     * @param \Ced\Exporter\Helper\Product $product
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Customer\Model\SessionFactory $customerSession,
        \Magento\Framework\Controller\Result\RedirectFactory $redirectFactory,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Ced\Exporter\Helper\Product $product,
        \Ced\Exporter\Helper\Config $config,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory
    )
    {
        parent::__construct($context);
        $this->session = $context->getSession();
        $this->customerSession = $customerSession->create();
        $this->filter = $this->_objectManager->create(\Magento\Ui\Component\MassAction\Filter::class);
        $this->catalogCollection = $this->_objectManager->create(\Magento\Catalog\Model\Product::class);
        $this->productHelper = $product;
        $this->redirectFactory = $redirectFactory;
        $this->resultJsonFactory = $resultJsonFactory;
        $this->resultPageFactory = $resultPageFactory;
        $this->config = $config;
        $this->registry = $registry;
    }

    public function execute()
    {
        $redirect = $this->redirectFactory->create();
        $chunkSize = !empty($this->config->getChunkSize()) ? $this->config->getChunkSize() : self::CHUNK_SIZE;
        $batchId = $this->getRequest()->getParam('batchid');

        if (isset($batchId)) {
            $resultJson = $this->resultJsonFactory->create();
            $productIds = $this->session->getExporterProducts();
            $profileIds = $this->session->getProfileIds();
            $otherOptions = $this->session->getOtherOptions();
            if (isset($productIds[$batchId])) {
                $customerId = $this->customerSession->getCustomerId();
                $response = $this->productHelper->insertProductsInAllProfiles($productIds[$batchId], $profileIds, $otherOptions, $customerId);
                if (count($productIds) <= $batchId + 1) {
                    $this->productHelper->generateFeeds($profileIds, $customerId);
                }
                if (isset($productIds[$batchId]) && isset($response) && !empty($response)) {
                    return $resultJson->setData(
                        [
                            'success' => 'Product Ids ' . implode(', ', $response) . 'Exported Successfully',
                            'messages' => $response
                        ]
                    );
                }
            }
            return $resultJson->setData(
                [
                    'error' => count($productIds[$batchId]) . " Product(s) Export Failed",
                    'messages' => $this->registry->registry('exporter_product_errors'),
                ]
            );
        }
        $profileIds = [];
        $otherOptions = [];
        $collection = $this->filter->getCollection($this->catalogCollection->getCollection())->getAllIds();
        $array = json_decode($this->session->getArrayPIds(), true);
        $this->session->unsArrayPIds();
        if (isset($array['profileIds'])) {
            $profileIds = $array['profileIds'];
        }
        if (isset($array['others'])) {
            $otherOptions = $array['others'];
        }


//        $profileIds = json_decode($this->session->getArrayPIds(), true);
        $customerId = $this->customerSession->getCustomer()->getId();

        if (isset($profileIds) && empty($profileIds)) {
            $this->messageManager->addErrorMessage('Please select a profile');
            return $redirect->setPath('exporter/customer/product');
        }
        if (count($collection) == 0) {
            $this->messageManager->addErrorMessage('No Product selected to upload.');
            return $redirect->setPath('exporter/customer/product');
        }
        $this->productHelper->truncateProductChangeTable($customerId);
        if (count($collection) <= $chunkSize) {
            $response = $this->productHelper->insertProductsInAllProfiles($collection, $profileIds, $otherOptions, $customerId);
            $this->productHelper->generateFeeds($profileIds, $customerId);
            if (isset($response) && !empty($response)) {
                $this->messageManager->addSuccessMessage('Product Ids ' . implode(', ', $response) . 'Exported Successfully');
            } else {
                $message = 'Product(s) Export Failed.';
                $errors = $this->registry->registry('exporter_product_errors');
                if (isset($errors)) {
                    $message = "Product(s) Upload Failed. \nErrors: " . (string)json_encode($errors);
                }
                $this->messageManager->addError($message);
            }
            return $redirect->setPath('exporter/customer/product');
        }

        $collection = array_chunk($collection, $chunkSize);
        $this->registry->register('productids', count($collection));
        $this->registry->register('profile_ids', $profileIds);
        $this->session->setExporterProducts($collection);
        $this->session->setProfileIds($profileIds);
        $this->session->setOtherOptions($otherOptions);
        $resultPage = $this->resultPageFactory->create();
        $resultPage->getConfig()->getTitle()->prepend(__('Export Products'));
        return $resultPage;
    }
}