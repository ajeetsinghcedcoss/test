<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement (EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @category    Ced
 * @package     Ced_Exporter
 * @author 		CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright   Copyright CedCommerce (http://cedcommerce.com/)
 * @license      http://cedcommerce.com/license-agreement.txt
 */
namespace Ced\Exporter\Controller\Adminhtml\AttributeMappingTemplate;
use Magento\Framework\View\Result\PageFactory;

class UpdateCategoryAttributes extends \Magento\Backend\App\Action
{
    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    protected $resultPageFactory;

    protected $_coreRegistry;

    public $jsonFactory;

    public $uploaderFactory;

    public $fileSystem;

    protected $allowedExtensions = ['csv']; // to allow file upload types

    protected $fileId = 'file'; // name of the input file box

    /**
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Catalog\Controller\Adminhtml\Product\Builder $productBuilder
     * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        PageFactory $resultPageFactory,
        \Magento\Framework\Controller\Result\JsonFactory $jsonFactory,
        \Magento\Framework\Registry $coreRegistry,
        \Magento\MediaStorage\Model\File\UploaderFactory $uploaderFactory,
        \Magento\Framework\Filesystem $fileSystem
    ) {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
        $this->_coreRegistry = $coreRegistry;
        $this->jsonFactory = $jsonFactory;
        $this->uploaderFactory = $uploaderFactory;
        $this->fileSystem = $fileSystem;
    }

    /**
     * Vendor grid for AJAX request
     *
     * @return \Magento\Backend\Model\View\Result\Page
     */
    public function execute()
    {
        $fileChek = false;
        $path = '';
        try{
            $file = $this->getRequest()->getFiles();
            if (isset($file['file']['tmp_name'])) {
                if(isset($file['file']['type']) && $file['file']['type'] == 'text/csv') {
                    $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
                    $fileSystem = $objectManager->create('\Magento\Framework\Filesystem');
                    $media = $fileSystem->getDirectoryRead(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA)->getAbsolutePath('attributemapping');
                    $file_name = $file['file']['name'];
                    $file_tmp = $file['file']['tmp_name'];
                    $path = $media . $file_name;
                    if (move_uploaded_file($file_tmp, $media . $file_name)) {
                        $fileChek = true;
                    }
                }
            }
            $halperCategory = $this->_objectManager->create('\Ced\Exporter\Helper\Category');
            if($path && $fileChek) {
                $requiredAttributes = $halperCategory->getAllAttribute($path);
                if($requiredAttributes) {
                    $result = $this->resultPageFactory->create(true)->getLayout()->createBlock('Ced\Exporter\Block\Adminhtml\AttributeMappingTemplate\Edit\Tab\Attribute\RequiredattributeBack')->setTemplateFile($path)->setAttributes(json_encode($requiredAttributes))->toHtml();
                    $this->getResponse()->setBody($result);
                }else {
                    return $this->jsonFactory->create()
                        ->setData(['Invalid file Formate .']);
                }

            } else {
                return $this->jsonFactory->create()
                    ->setData(['Invalid file Formate .']);
            }

        }catch (\Exception $e) {
            echo $e->getMessage();
            die;
        }
    }



}
