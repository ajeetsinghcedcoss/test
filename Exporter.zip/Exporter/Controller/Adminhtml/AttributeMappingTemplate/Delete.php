<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement (EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @category    Ced
 * @package     Ced_Exporter
 * @author 		CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright   Copyright CedCommerce (http://cedcommerce.com/)
 * @license      http://cedcommerce.com/license-agreement.txt
 */
namespace Ced\Exporter\Controller\Adminhtml\AttributeMappingTemplate;
 
use Magento\Customer\Api\Data\GroupInterfaceFactory;
use Magento\Customer\Api\GroupRepositoryInterface;

class Delete extends \Magento\Customer\Controller\Adminhtml\Group
{
	protected $_objectManager;
	
	protected $_session;

    public $filter;

    public $templateModel;

    public $templateCollectionFactory;

    public function __construct(
	    \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\Registry $coreRegistry,
        GroupRepositoryInterface $groupRepository,
        GroupInterfaceFactory $groupDataFactory,
        \Magento\Backend\Model\View\Result\ForwardFactory $resultForwardFactory,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Magento\Ui\Component\MassAction\Filter $filter,
        \Ced\Exporter\Model\ResourceModel\AttributeMappingTemplate\CollectionFactory $templateCollectionFactory,
        \Ced\Exporter\Model\AttributeMappingTemplate $templateModel
    )
    {
        $this->filter = $filter;
        $this->templateModel = $templateModel;
        $this->templateCollectionFactory = $templateCollectionFactory;
        parent::__construct($context, $coreRegistry, $groupRepository, $groupDataFactory, $resultForwardFactory, $resultPageFactory);
    }

    /**
	 * Delete the Attribute
	 */
	public function execute()
    {

        $templateModelIds = array();
        // delete
        $id  = $this->getRequest()->getParam('id');
        if($id) {
            $templateModelIds[] = $id;
        }
        if(count($templateModelIds) <=0) {
            // select delete
            $templateModelIds = $this->getRequest()->getParam('selected');
        }
        if(count($templateModelIds)<=0) {
            //select all delete
            $excluded = $this->getRequest()->getParam('excluded', false);
            if(isset($excluded) && $excluded) {
                $templateModelIds = $this->filter->getCollection($this->templateCollectionFactory->create())->getAllIds();
            }
        }


        $msg = ' Template Deleted Successfully';
        if(empty($templateModelIds)) {
            $msg = ' Template Truncate Successfully';
            $templateModelIds = $this->templateCollectionFactory->create()->getAllIds();
        }

        if (!empty($templateModelIds)) {
            try {
                foreach ($templateModelIds as $templateModelId) {
                    $templateModel = $this->templateModel->load($templateModelId);
                    $templateModel->delete();
                }
                $this->messageManager->addSuccessMessage(count($templateModelIds).$msg);
            } catch (\Exception $e) {
                return false;
            }
        }
        else {
            $this->messageManager->addErrorMessage('NO template !');
        }
        $this->_redirect('*/*/index');
    }

    /**
     * IsALLowed
     * @return boolean
     */
    public function _isAllowed()
    {
        return $this->_authorization->isAllowed('Ced_Exporter::Exporter');
    }

}

