<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement (EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @category    Ced
 * @package     Ced_Exporter
 * @author 		CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright   Copyright CedCommerce (http://cedcommerce.com/)
 * @license      http://cedcommerce.com/license-agreement.txt
 */
namespace Ced\Exporter\Controller\Adminhtml\AttributeMappingTemplate;
use Magento\Backend\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;


class Save extends \Magento\Backend\App\Action
{

    /**
     * @var PageFactory
     */
    protected $resultPageFactory;
    protected $_coreRegistry;
    Protected $_configFactory;
    protected $_configStructure;
    protected  $_cache;
    public  $fileSystem;

    /**
     * @param Context $context
     * @param PageFactory $resultPageFactory
     */
    public function __construct(
        Context $context,
        \Magento\Framework\Registry $coreRegistry,
        \Magento\Config\Model\Config\Structure\Element\Group $group,
        \Magento\Config\Model\Config\Structure $configStructure,
        \Magento\Config\Model\Config\Factory $configFactory,
        \Ced\Exporter\Helper\Cache $cache,
        \Magento\Framework\Filesystem $fileSystem,
        PageFactory $resultPageFactory
    ) {
        parent::__construct($context);
        $this->scopeConfig = $this->_objectManager->create('\Magento\Framework\App\Config');
        $this->resultPageFactory = $resultPageFactory;
        $this->_configStructure = $configStructure;
        $this->_coreRegistry     = $coreRegistry;
        $this->_configFactory = $configFactory;
        $this->_cache = $cache;
        $this->fileSystem = $fileSystem;

    }
    /**
     *
     * @param string $idFieldName
     * @return mixed
     */
    protected function _initProfile($idFieldName = 'id')
    {
        $templateId = $this->getRequest()->getParam($idFieldName);
        $template = $this->_objectManager->get('Ced\Exporter\Model\AttributeMappingTemplate');
        if ($templateId) {
            $template->load($templateId);
        }
        $this->getRequest()->setParam('is_exporter',1);
        $this->_coreRegistry->register('current_template', $template);
        return $this->_coreRegistry->registry('current_template');
    }


    public function execute()
    {
        $data = $this->_objectManager->create('Magento\Config\Model\Config\Structure\Element\Group')->getData();
        $this->_objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $this->_context = $this->_objectManager->get('Magento\Framework\App\Helper\Context');
        $redirectBack   = $this->getRequest()->getParam('back', false);
        $tab   			= $this->getRequest()->getParam('tab', false);
        $pcode        = $this->getRequest()->getParam('template_code', false);
        $templateId        = $this->getRequest()->getParam('id', false);
        $templateData  = $this->getRequest()->getPostValue();
        $templateData = json_decode(json_encode($templateData),1);

        try {
            $template = $this->_initProfile('id');
//            if (!$template->getId() && $templateId) {
//                $this->messageManager->addError(__('This Template no longer exists.'));
//                $this->_redirect('*/*/');
//                return;
//            }

            if (!$template->getId() && isset($templateData['template_code'])) {
                $pcode = $templateData['template_code'];
                $profileCollection = $this->_objectManager->get('Ced\Exporter\Model\AttributeMappingTemplate')
                    ->getCollection()
                    ->addFieldToFilter('template_code', $templateData['template_code']);
                if (count($profileCollection) > 0) {
                    $this->messageManager->addError(__('This Template Already Exist Please Change Template Code'));
                    $this->_redirect('*/*/edit');
                    return;
                }
            }
            $requriedAttributes = array();
            if (isset($templateData['required_attributes'])){
                $temAttribute = $this->unique_multidim_array($templateData['required_attributes'], 'exporter_attribute_name');
                $requriedAttributes['required_attributes'] = array_filter(array_map(function($n) { if($n['required']) return $n; }, $temAttribute));
                $requriedAttributes['optional_attributes'] = array_filter(array_map(function($n) { if(!$n['required']) return $n; }, $temAttribute));
            }
            if (isset($templateData['variant_attributes'])) {
                $requriedAttributes['variant_attributes'] = $this->unique_multidim_array($templateData['variant_attributes'], 'exporter_attribute_name');
            }

            $fileData = $this->getRequest()->getFiles();
            $file =  isset($fileData['template_file']['name'])? $fileData['template_file']['name']:'';
            $template->setTemplateCode($templateData['template_code'])
                ->setTemplateName($templateData['template_name'])
                ->setTemplateFile($file)
                ->setRequiredAttributes(json_encode($requriedAttributes))
                ->save();
            $this->messageManager->addSuccessMessage(__('Template Save Successfully.'));
            $this->_redirect('*/*/index');
        } catch (\Exception $e) {
            $this->messageManager->addError(__('
		   		Unable to Save Profile Please Try Again.
		   			'. $e->getMessage()));
            $this->_redirect('*/*/edit', array(
                'back' => 'edit',
                'tab' => $tab,
                'active_tab' => null,
                'pcode' => $pcode,
                'section' => 'walmartconfiguration',
            ));
        }

        return;
    }

    /* Identify unique exporter attributes
   */
    function unique_multidim_array($array, $key) {
        $temp_array = array();
        $i = 0;
        $key_array = array();

        foreach($array as $val) {
            if($val['delete']==1)
                continue;

            if (!in_array($val[$key], $key_array)) {
                $key_array[$i] = $val[$key];
                $temp_array[$i] = $val;
            }
            $i++;
        }
        return $temp_array;
    }
}
