<?php

/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement(EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @category  Ced
 * @package   Ced_Exporter
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 */

namespace Ced\Exporter\Controller\Adminhtml\Product;

/**
 * Class Upload
 *
 * @package Ced\Exporter\Controller\Adminhtml\Product
 */
class Export extends \Magento\Backend\App\Action
{
    
    const CHUNK_SIZE = 5;

    /**
     * @var \Magento\Ui\Component\MassAction\Filter
     */
    public $filter;

    /**
     * @var \Ced\Exporter\Helper\Product
     */
    public $exporter;

    /**
     * @var \Magento\Catalog\Model\Product
     */
    public $catalogCollection;

    /**
     * @var \Ced\Exporter\Helper\Config
     */

    public $session;

    public $registry;

    public $resultJsonFactory;

    public $resultPageFactory;

    public $pc;

    public $redirectFactory;

    public $config;
    /**
     * Upload constructor.
     *
     * @param \Magento\Backend\App\Action\Context              $context
     * @param \Magento\Framework\View\Result\PageFactory       $resultPageFactory
     * @param \Magento\Ui\Component\MassAction\Filter          $filter
     * @param \Magento\Catalog\Model\Product                   $collection
     * @param \Ced\Exporter\Helper\Product                       $product
     * @param \Magento\Framework\Registry                      $registry
     * @param \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Magento\Framework\Controller\Result\RedirectFactory $redirectFactory,
        \Magento\Ui\Component\MassAction\Filter $filter,
        \Magento\Catalog\Model\Product $collection,
        \Ced\Exporter\Helper\Product $product,
        \Ced\Exporter\Cron\Product\Feeds $productsCron,
        \Ced\Exporter\Helper\Config $config,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory
    ) {
        parent::__construct($context);
        $this->filter = $filter;
        $this->catalogCollection = $collection;
        $this->exporter = $product;
        $this->session =  $context->getSession();
        $this->pc = $productsCron;
        $this->registry = $registry;
        $this->resultJsonFactory = $resultJsonFactory;
        $this->resultPageFactory = $resultPageFactory;
        $this->redirectFactory = $redirectFactory;
        $this->config = $config;
    }
    /**
     * @return $this|\Magento\Framework\App\ResponseInterface|\Magento\Framework\Controller\ResultInterface|\Magento\Framework\View\Result\Page
     * @throws \Exception
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function execute()
    {
        $redirect = $this->redirectFactory->create();
        $chunkSize = !empty($this->config->getChunkSize()) ? $this->config->getChunkSize() : self::CHUNK_SIZE;
        $batchId = $this->getRequest()->getParam('batchid');
        if (isset($batchId)) {
            $resultJson = $this->resultJsonFactory->create();
            $productIds = $this->session->getExporterProducts();
            $profileIds = $this->session->getProfileIds();
            $otherOptions = $this->session->getOtherOptions();
            if (isset($productIds[$batchId])) {
                //foreach ($profileIds as $profileId) {
                    $response = $this->exporter->insertProductsInAllProfiles($productIds[$batchId], $profileIds, $otherOptions);
                    if (count($productIds) <= $batchId+1) {
                        $this->exporter->generateFeeds($profileIds);
                    }
                //}
                if (isset($productIds[$batchId]) && isset($response) && !empty($response)) {
                    return $resultJson->setData(
                        [
                            'success' => 'Product Ids '.implode(', ', $response).' Exported Successfully',
                            'messages' => $response
                        ]
                    );
                }
            }
            return $resultJson->setData(
                [
                'error' => count($productIds[$batchId]) . " Product(s) Export Failed",
                'messages' => $this->registry->registry('exporter_product_errors'),
                ]
            );
        }

        // case 3 normal uploading and chunk creating
        $collection = $this->filter->getCollection($this->catalogCollection->getCollection());
        $productIds = $collection->getAllIds();
        //$profileIds = $this->getRequest()->getParam('profile_id');
        $profileIds = [];
        $otherOptions = [];
        $array = json_decode($this->session->getArrayPIds(), true);
        $this->session->unsArrayPIds();
        if (isset($array['profileIds'])) {
            $profileIds = $array['profileIds'];
        }
        if (isset($array['others'])) {
            $otherOptions = $array['others'];
        }

        /*$profileIds = [7];
        $otherOptions = [3];
        $productIds = [2172];*/
        if (isset($profileIds) && empty($profileIds)) {
            $this->messageManager->addErrorMessage('Please select a profile');
            return $redirect->setPath(\Ced\Exporter\Controller\Adminhtml\Product\Validate::REDIRECT_PATH);
        }
        if (count($productIds) == 0) {
            $this->messageManager->addErrorMessage('No Product selected to upload.');
            return $redirect->setPath(\Ced\Exporter\Controller\Adminhtml\Product\Validate::REDIRECT_PATH);
        }

        // remove change product data
        $this->exporter->truncateProductChangeTable();
        // case 3.1 normal uploading if current ids are less than chunk size.
        if (count($productIds) <= $chunkSize) {
          //  foreach ($profileIds as $profileId) {
                $response = $this->exporter->insertProductsInAllProfiles($productIds, $profileIds, $otherOptions);
                $this->exporter->generateFeeds($profileIds);
                if (isset($response) && !empty($response)) {
                    $this->messageManager->addSuccessMessage('Product Ids '.implode(', ', $response).' Exported Successfully');
                } else {
                    $message = 'Product(s) Export Failed.';
                    $errors = $this->registry->registry('exporter_product_errors');
                    if (isset($errors)) {
                        $message = "Product(s) Upload Failed. \nErrors: " . (string)json_encode($errors);
                    }
                    $this->messageManager->addError($message);
                }
           // }
            return $redirect->setPath(\Ced\Exporter\Controller\Adminhtml\Product\Validate::REDIRECT_PATH);
        }
        // case 3.2 normal uploading if current ids are more than chunk size.

        $productIds = array_chunk($productIds, $chunkSize);
        $this->registry->register('productids', count($productIds));
        $this->registry->register('profile_ids', $profileIds);
        $this->session->setExporterProducts($productIds);
        $this->session->setProfileIds($profileIds);
        $this->session->setOtherOptions($otherOptions);
        $resultPage = $this->resultPageFactory->create();
        $resultPage->setActiveMenu('Ced_Exporter::Exporter');
        $resultPage->getConfig()->getTitle()->prepend(__('Export Products'));
        return $resultPage;
    }
}
