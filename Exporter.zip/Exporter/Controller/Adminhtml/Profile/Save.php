<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement (EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @category  Ced
 * @package   Ced_Exporter
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CedCommerce (http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 */

namespace Ced\Exporter\Controller\Adminhtml\Profile;

use Magento\Framework\DataObject;

/**
 * Class Save
 *
 * @package Ced\Exporter\Controller\Adminhtml\Profile
 */
class Save extends \Magento\Backend\App\Action
{
    public $config;
    /**
     * @var \Magento\Framework\Registry
     */
    public $registory;

    /**
     * @var \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory
     */
    public $catalogCollection;

    /**
     * @var \Magento\Catalog\Model\ResourceModel\Category\CollectionFactory
     */
    public $categoryCollection;

    /**
     * @var \Ced\Exporter\Model\ProfileProductFactory
     */
    public $profileProduct;

    /**
     * @var \Magento\Framework\Setup\ModuleDataSetupInterface
     */
    public $moduleDataSetup;

    /**
     * @var \Ced\Exporter\Model\ProfileFactory
     */
    public $profileFactory;

    /**
     * @var \Ced\Exporter\Helper\Profile
     */
    public $profileHelper;

    /**
     * @var DataObject
     */
    public $data;

    public $cache;

    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\App\Helper\Context $configContext,
        \Magento\Framework\Registry $registory,
        \Magento\Config\Model\Config\Structure $configStructure,
        \Ced\Exporter\Helper\Config $exporterConfig,
        \Magento\Catalog\Model\ResourceModel\Category\CollectionFactory $categoryCollection,
        \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $catalogCollection,
        \Magento\ConfigurableProduct\Model\Product\Type\ConfigurableFactory $configurable,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Magento\Framework\DataObject $data,
        \Ced\Exporter\Model\ProfileProductFactory $profileProduct,
        \Ced\Exporter\Model\ProfileFactory $profileFactory,
        \Ced\Exporter\Helper\Profile $profileHelper,
        \Magento\Catalog\Model\ResourceModel\Eav\AttributeFactory $eavattribute

    ) {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
        $this->configStructure = $configStructure;
        $this->registory = $registory;
        $this->config = $exporterConfig;
        $this->productConfigFactory = $configurable;
        $this->catalogCollection = $catalogCollection;
        $this->categoryCollection = $categoryCollection;
        $this->profileHelper = $profileHelper;
        $this->profileFactory = $profileFactory;
        $this->profileProduct = $profileProduct;
        $this->data = $data;
    }

    /**
     * @return \Magento\Framework\App\ResponseInterface|\Magento\Framework\Controller\Result\Redirect|\Magento\Framework\Controller\ResultInterface
     * @throws \Exception
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function execute()
    {
        $profileId = null;
        $returnToEdit = true;
        try{
            $resultRedirect = $this->resultRedirectFactory->create();
            if ($this->validate()) {
                $storeId = $this->config->getStore();
                $profile = $this->profileFactory->create()->load($this->data->getProfileId());
                $profile->addData($this->data->getData());
                $profile->save();

                //$profile->removeProducts($storeId);

               // $profile->addProducts($storeId);
                $profileId = $profile->getId();
                $this->profileHelper->setProfile($profileId);
                $this->messageManager->addSuccess(__('
		   		You Saved The Profile And Its Products.
		   		'));
                $resultRedirect->setPath('exporter/profile/index');
            } else {
                $this->messageManager->addError(__('
		   		Profile Having Invalid Data.
		   		'));
                $resultRedirect->setPath(
                    'exporter/profile/edit',
                    ['id' => $profileId, '_current' => true]
                );
            }
        } catch (\Exception $e) {
            $this->messageManager->addError(__($e->getMessage()));
            $resultRedirect->setPath(
                'exporter/profile/edit',
                ['id' => $profileId, '_current' => true]
            );
        }

        return $resultRedirect;
    }

    private function validate()
    {
        $generalInformation = $this->getRequest()->getParam('general_information');
        $profileId = (isset($generalInformation['id']) && !empty($generalInformation['id'])) ? $generalInformation['id'] : false;
        $profileMappings = $this->getRequest()->getParam('profile_mappings');

        $profileProductsFilters = $this->getRequest()->getParam('profile_products_filters');
        $exporterAttributes = $this->getRequest()->getParam('exporter_attributes');
        $basicProductMapping = $this->getRequest()->getParam('product_basic_mappings');
        if (!empty($exporterAttributes) || !empty($profileId)) {
            $exporterAttributes = $this->mergeAttributes($exporterAttributes, 'exporter_attribute_name');
            $requiredAttributes = $optionalAttributes = [];
            foreach ($exporterAttributes as $exporterAttribute_key => $exporterAttribute_value) {
                if (isset($exporterAttribute_value['required']) and $exporterAttribute_value['required'] == 1) {
                    $requiredAttributes[$exporterAttribute_key] = $exporterAttribute_value;
                } elseif (isset($exporterAttribute_value['model_attributes']) and $exporterAttribute_value['model_attributes'] == 1) {
                    $requiredAttributes[$exporterAttribute_key] = $exporterAttribute_value;
                } else {
                    $optionalAttributes[$exporterAttribute_key] = $exporterAttribute_value;
                    $optionalAttributes[$exporterAttribute_key]['required'] = 0;
                    $optionalAttributes[$exporterAttribute_key]['model_attributes'] = 0;
                }
            }

            foreach ($requiredAttributes as $requiredAttribute) {
                $requiredAttribute['options'] = json_decode($requiredAttribute['options'],true);
                $requiredAttribute['option_mapping'] = json_decode($requiredAttribute['option_mapping'],true);
            }
            $this->data->setData('profile_required_attributes', json_encode($requiredAttributes));
            $this->data->setData('profile_optional_attributes', json_encode($optionalAttributes));
            $this->data->setData('product_basic_mappings', json_encode($basicProductMapping));
        }

        if (isset($generalInformation)) {
            $this->data->addData($generalInformation);
        }
        if (isset($profileMappings['profile_category'])) {
            if (isset($profileMappings['profile_category'][0]) and is_array($profileMappings['profile_category'])) {
                // On changing category
                $this->data->setData('profile_category', $profileMappings['profile_category'][0]);
            } else {
                // Saving already saved category
                $this->data->setData('profile_category', $profileMappings['profile_category']);
            }
        }

        if (isset($profileMappings['template'])) {
            if (isset($profileMappings['template'][0]) and is_array($profileMappings['template'])) {
                // On changing category
                $this->data->setData('template_id', $profileMappings['template'][0]);
            } else {
                // Saving already saved category
                $this->data->setData('template_id', $profileMappings['template']);
            }
        }else {
            $this->data->setData('template_id', '');
        }

        if (isset($profileMappings['header_restriction'])) {
            $this->data->setData('header_restriction', $profileMappings['header_restriction']);
        }
        if (isset($profileProductsFilters)) {
            $this->data->setData('profile_products_filters', $profileProductsFilters);
        }

        if (isset($generalInformation['profile_name'])) {
            $this->data->addData($generalInformation);
        }

        if (!$this->data->getProfileCode() or !$this->data->getProfileName()/* or !$this->data->getProfileCategory()*/) {
            return false;
        }

        return true;
    }

    /**
     * @param $array
     * @param $key
     * @return array
     */
    private function mergeAttributes($attributes, $key)
    {

        $tempArray = [];
        $i = 0;
        $keyArray = [];

        if (!empty($attributes) and is_array($attributes)) {
            foreach ($attributes as $val) {
                if (isset($val['delete']) and $val['delete']  == 1) {
                    continue;
                }
                if (!in_array($val[$key], $keyArray)) {
                    $keyArray[$val[$key]] = $val[$key];
                    $tempArray[$val[$key]] = $val;
                }
                $i++;
            }
        }

        return $tempArray;
    }

}
