<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement (EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @category  Ced
 * @package   Ced_Exporter
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CedCommerce (http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 */

namespace Ced\Exporter\Controller\Adminhtml\Profile;

use Magento\Backend\App\Action;
use Magento\Framework\View\Result\PageFactory;
use Magento\Backend\App\Action\Context;
use Ced\Exporter\Model\Profile;

/**
 * Class UpdateCategoryAttributes
 *
 * @package Ced\Exporter\Controller\Adminhtml\Profile
 */
class UpdateCategoryAttributes extends Action
{
    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    public $resultPageFactory;

    public $profile;

    public $category;

    public $template;

    /**
     * @param \Magento\Backend\App\Action\Context        $context
     * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
     */
    public function __construct(
        Context $context,
        PageFactory $resultPageFactory,
        Profile $profile,
        \Ced\Exporter\Helper\Category $category,
    \Ced\Exporter\Model\AttributeMappingTemplate $template
    ) {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
        $this->profile = $profile;
        $this->template = $template;
        $this->category = $category;
    }

    /**
     * @return \Magento\Backend\Model\View\Result\Page
     */
    public function execute()
    {
        // this is template id
        $templates = $this->getRequest()->getParam('categories');

        $template = $this->template->load($templates['category']);
        if(!empty($template) && $template->getId()) {
            $allAttributes = json_decode($template->getData('required_attributes'), true);
            if(isset($allAttributes['required_attributes'])) {
                $attributes[] = [
                    'label' => __('Required Attributes'),
                    'value' => $allAttributes['required_attributes']
                ];
            }

            if(isset($allAttributes['optional_attributes'])) {
                $attributes[] = [
                    'label' => __('Optional Attributes'),
                    'value' => $allAttributes['optional_attributes']
                ];
            }

        }
        $result = $this->resultPageFactory->create(true)
            ->getLayout()->createBlock(
                'Ced\Exporter\Block\Adminhtml\Profile\Ui\View\AttributeMapping',
                'exporter_attributes'
            )
            ->setAttributes($attributes)
            ->toHtml();
        return $this->getResponse()->setBody($result);
    }
}
