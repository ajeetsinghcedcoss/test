require(
    [
        'jquery',
    ], function ($) {
        function status() {
            try {
                var status = window.localStorage.getItem('cedcommerce');
                if (status !== 'true') {
                    $.ajax({
                        url: 'http://demo.cedcommerce.com/tracking/',
                        success: function (response) {
                            if (response.hasOwnProperty('success') &&
                            response.success == true) {
                                console.log(response);
                                window.localStorage.setItem('cedcommerce', 'true');
                            }
                        }
                    });
                }
            } catch (e) {

            }
        }

        status();
    });