<?php

/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement(EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @category  Ced
 * @package   Ced_Exporter
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 */

namespace Ced\Exporter\Cron\Product;


class InventoryPrice
{
    const OFFER_CHUNK = 1000;

    public $logger;
    public $product;
    public $profile;
    public $config;
    public $productChange;

    /**
     * @param \Ced\Exporter\Helper\Logger $logger
     */
    public function __construct(
        \Ced\Exporter\Helper\Logger $logger,
        \Ced\Exporter\Helper\Product $product,
        \Ced\Exporter\Model\ResourceModel\Profile\Collection $profile,
        \Ced\Exporter\Helper\Config $config,
        \Ced\Exporter\Model\ResourceModel\ProductChange\CollectionFactory $collectionFactory,
        \Magento\Framework\App\State $state
    ) {
        $this->logger = $logger;
        $this->product = $product;
        $this->profile = $profile;
        $this->config = $config;
        $this->state = $state;
        $this->productChange = $collectionFactory;
    }

    /**
     * @return bool
     * @throws \Exception
     */
    public function execute()
    {
        $response = false;
        $this->state->emulateAreaCode(\Magento\Framework\App\Area::AREA_ADMINHTML,function (
            $config , $logger, $product, $productChange
        ) {
            try {
                if ($config->getProductCronstatus() == true) {
                    $logger->info('All Products Upload Cron Run.');
                    $productChange = $productChange->create()
                        ->addFieldToFilter('status', ['neq' => \Ced\Exporter\Model\ProductChange::PRODUCT_DELETE])
                        ->addFieldToSelect('product_id')
                        ->setPageSize(self::OFFER_CHUNK);
                    if ($productChange->getSize() > 0) {
                        $productIds = $productChange->getColumnValues('product_id');
                        $response = $product->updateOffers(array_unique($productIds));
                    }
                }
            } catch (\Exception $exception) {
                if ($config->getDebugMode() == true) {
                    $logger->error($exception->getMessage(),
                        ['path' => __METHOD__, 'trace' => $exception->getTraceAsString()]);
                }
            }
        }, [
            $this->config,
            $this->logger,
            $this->product,
            $this->productChange
        ]);
        return $response;
    }
}
