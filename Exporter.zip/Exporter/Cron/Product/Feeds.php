<?php

/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement(EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @category  Ced
 * @package   Ced_Exporter
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 */

namespace Ced\Exporter\Cron\Product;


class Feeds
{
    const FEED_CHUNK_SIZE = 50;
    public $logger;
    public $product;
    public $profile;
    public $config;
    public $feeds;

    /**
     * @param \Ced\Exporter\Helper\Logger $logger
     */
    public function __construct(
        \Ced\Exporter\Helper\Logger $logger,
        \Ced\Exporter\Helper\Product $product,
        \Ced\Exporter\Model\ResourceModel\Profile\Collection $profile,
        \Ced\Exporter\Helper\Config $config,
        \Ced\Exporter\Model\ResourceModel\Feeds\CollectionFactory $collectionFactory
    ) {
        $this->logger = $logger;
        $this->product = $product;
        $this->profile = $profile;
        $this->config = $config;
        $this->feeds = $collectionFactory;
    }

    /**
     * @return bool
     * @throws \Exception
     */
    public function execute()
    {
        $response = false;
            try {
                if ($this->config->getFeedsCronstatus() == true) {
                    $feeds = $this->feeds->create()
                        ->addFieldToFilter('approval_status', ['eq' => \Ced\Exporter\Helper\Product::APPROVAL_STATUS])
                        ->setPageSize(self::FEED_CHUNK_SIZE)
                        ->getAllIds();
                    if (isset($feeds) && !empty($feeds)) {
                        $this->product->approveFeed($feeds);
                    }
                }
            } catch (\Exception $exception) {
                if ($this->config->getDebugMode() == true) {
                    $this->logger->error($exception->getMessage(),
                        ['path' => __METHOD__, 'trace' => $exception->getTraceAsString()]);
                }
            }
        return $response;
    }
}
