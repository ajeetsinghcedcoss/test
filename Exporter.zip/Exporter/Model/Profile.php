<?php

/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement (EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @category  Ced
 * @package   Ced_Exporter
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CedCommerce (http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 */


namespace Ced\Exporter\Model;

class Profile extends \Magento\Framework\Model\AbstractModel
{
    const ATTRIBUTE_CODE_PROFILE_ID = 'exporter_profile_id';

    /**
     * @var \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory
     */
    public $product;

    public $action;

    public $category;

    /**
     * Profile products flipped
     * @var array
     */
    public $productIds = [];

    public $objectManager;

    /**
     * @return void
     */
    public function _construct()
    {
        $this->_init('Ced\Exporter\Model\ResourceModel\Profile');
    }

    //TODO: remove as not needed.
    public function getProductsReadonly()
    {
        return [];
    }

    //@TODO: impliment without object manager
    public function getProductsPosition()
    {
        if (!isset($this->objectManager)) {
            $this->objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        }

        if (!isset($this->product)) {
            $this->product = $this->objectManager->create('\Magento\Catalog\Model\ResourceModel\Product\CollectionFactory');
        }

        $id = $this->getId();
        $ids = $this->product->create()->addAttributeToFilter('exporter_profile_id', ['eq' => $id])
            ->addAttributeToSelect('entity_id')->getAllIds();
        if (is_array($ids) and !empty($ids)) {
            $this->productIds = array_flip($ids);
        }

        return $this->productIds;
    }

    public function removeProducts($storeId)
    {
        if (!isset($this->objectManager)) {
            $this->objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        }

        try {
            $filters = $this->getProfileProductsFilters();

            if (!empty($filters)) {

                if (!isset($this->product)) {
                    $this->product = $this->objectManager
                        ->create('\Magento\Catalog\Model\ResourceModel\Product\CollectionFactory');
                }
                $id = $this->getId();
                $exporter_profile_id  = self::ATTRIBUTE_CODE_PROFILE_ID;//.'_'.$id;
                $products = $this->product->create()
                    ->setStore($storeId)
                   // ->addAttributeToFilter($exporter_profile_id, ['eq' => $id])
                    ->addAttributeToFilter($exporter_profile_id, ['like' => '%' . $id . '%'])
                    ->addAttributeToSelect($exporter_profile_id);
                $productIds = $products->getAllIds();

                $this->action = $this->objectManager->create('\Magento\Catalog\Model\Product\ActionFactory');
                // Removing profile id from already added products
                $this->action->create()->updateAttributes($productIds, [self::ATTRIBUTE_CODE_PROFILE_ID => ''], $storeId);
            }
        } catch (\Exception $e) {

            echo $e->getMessage();
            die;
            $config = $this->objectManager->create('\Ced\Exporter\Helper\Config');
            if ($config->getDebugMode() == true) {
                $config->logger->error($e->getMessage(), ['path' => __METHOD__, 'trace' => $e->getTraceAsString()]);
            }
        }
    }

    /**
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function addProducts($storeId)
    {
        try {
            if (!isset($this->objectManager)) {
                $this->objectManager = \Magento\Framework\App\ObjectManager::getInstance();
            }

            if (!isset($this->product)) {
                $this->product = $this->objectManager->create('\Magento\Catalog\Model\ResourceModel\Product\CollectionFactory');
            }

            $id = $this->getId();

            $this->category = $this->objectManager->create('\Magento\Catalog\Model\CategoryFactory');

            $filters = $this->parseFilters($this->getProfileProductsFilters());
            if (!empty($filters)) {

                $exporter_profile_id = 'exporter_profile_id';
                $products = $this->product->create()
                    ->setStoreId($storeId)
                    // ->addAttributeToFilter('exporter_profile_id', ['neq' => $id])
                    ->addAttributeToSelect($exporter_profile_id);

                // Applying grid filters
                foreach ($filters as $field => $value) {
                    if ($field == 'category_ids') {
                        $categoryFilter = $this->category->create()->load($value);
                        $products->addCategoryFilter($categoryFilter);
                    } elseif (in_array($field, ['sku', 'name'])) {
                        $products->addAttributeToFilter($field, ['like' => '%' . $value . '%']);
                    } else {
                        $products->addAttributeToFilter($field, ['eq' => $value]);
                    }
                }

                $attributeCode = self::ATTRIBUTE_CODE_PROFILE_ID;

                foreach ($products as $product ) {
                    $ids = explode(',', $product->getData(self::ATTRIBUTE_CODE_PROFILE_ID));
                    if(!in_array($id,$ids)) {
                        $value = !empty($ids)? $id.','.$product->getData(self::ATTRIBUTE_CODE_PROFILE_ID): $id;
                        $this->action = $this->objectManager->create('\Magento\Catalog\Model\Product\ActionFactory');
                        $this->action->create()->updateAttributes([$product->getId()], [$attributeCode => $value ], $storeId);
                    }

                }
                // Writing profile id

            }
        } catch (\Exception $e) {

            echo $e->getMessage();
            die;
            $config = $this->objectManager->create('\Ced\Exporter\Helper\Config');
            if ($config->getDebugMode() == true) {
                $config->logger->error($e->getMessage(), ['path' => __METHOD__, 'trace' => $e->getTraceAsString()]);
            }
        }

    }

    //@TODO: handle all types of filters, define fixed filter attribute.
    public function parseFilters($filters)
    {
        $parsedFilter = [];
        if (!empty($filters)) {
            $filtersArray = explode('&', trim($filters));
            foreach ($filtersArray as $item) {
                $filtersValue = explode('=', $item);
                if (isset($filtersValue[0], $filtersValue[1])) {
                    $parsedFilter[trim($filtersValue[0])] = trim($filtersValue[1]);
                }
            }
        }
        return $parsedFilter;
    }

    /**
     * @param $field
     * @param $value
     * @param string $additionalAttributes
     * @return $this
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function loadByField($field, $value, $additionalAttributes = '*')
    {
        $collection = $this->getResourceCollection()->addFieldToSelect($additionalAttributes);
        if (is_array($field) && is_array($value)) {
            foreach ($field as $key => $f) {
                if (isset($value[$key])) {
                    //$f = $helper->getTableKey($f);
                    $collection->addFieldToFilter($f, $value[$key]);
                }
            }
        } else {
            /* echo "{{".$field.' == '.$value."}}"; */
            //$field = $helper->getTableKey($field);
            $collection->addFieldToFilter($field, $value);
            /*  */
        }

        $collection->setCurPage(1)
            ->setPageSize(1);
        foreach ($collection as $object) {
            $this->load($object->getId());
            return $this;
        }
        return $this;
    }


    public function createProfileAttribute($attributeCode, $optionArray, $attributeUpperCase, $frontendInput = 'select')
    {
        $eavCollectionFactory = $this->objectManager->create('Magento\Eav\Model\ResourceModel\Entity\Attribute\Group\CollectionFactory');
        $group = $eavCollectionFactory->create()
            ->addFieldToFilter('attribute_group_id', $this->config->getDefaultAttributeGroup())
            ->addFieldToSelect('attribute_group_name')
            ->setPageSize(1)
            ->getFirstItem()
            ->getDataByKey('attribute_group_name');

        $attributeData = [
            'attribute_code' => $attributeCode,
            'is_global' => 1,
            'frontend_label' => $attributeUpperCase,
            'frontend_input' => $frontendInput,
            'default_value_text' => '',
            'default_value_yesno' => 0,
            'default_value_date' => '',
            'default_value_textarea' => '',
            'is_unique' => 0,
            'attribute_set_id' => $this->config->getDefaultAttributeSet(),
            'attribute_group_id' => $this->config->getDefaultAttributeGroup(),
            'apply_to' => 0,
            'group' => $group,
            'is_required' => 0,
            'is_configurable' => 1,
            'is_searchable' => 1,
            'is_user_defined' => 1,
            'is_comparable' => 0,
            'is_visible_in_advanced_search' => 1,
            'is_used_for_price_rules' => 0,
            'is_wysiwyg_enabled' => 0,
            'is_html_allowed_on_front' => 1,
            'is_visible_on_front' => 0,
            'used_in_product_listing' => 0,
            'used_for_sort_by' => 0,
            'is_filterable' => 0,
            'is_filterable_in_search' => 0,
            'backend_type' => 'varchar',
        ];
        if($frontendInput == 'select' ) {
            $attributeData['option'] = $optionArray;
            $attributeData['default'] = [
                '0' => 'option_0'
            ];
        }

        $entity = $this->objectManager->create('\Magento\Eav\Model\Entity');
        $entityTypeID = $entity->setType('catalog_product')->getTypeId();

        $eavAttributeFactory = $this->objectManager->create('\Magento\Catalog\Model\ResourceModel\Eav\AttributeFactory');
        $eavAttribute = $eavAttributeFactory->create();
        $eavAttribute->addData($attributeData)->setEntityTypeId($entityTypeID)
            ->getResource()->save($eavAttribute);
        return $eavAttribute->getAttributeId();
    }
}
