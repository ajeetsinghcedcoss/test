<?php
/**
 * Created by PhpStorm.
 * User: cedcoss
 * Date: 19/2/18
 * Time: 12:27 PM
 */

namespace Ced\Exporter\Model;


class Categories extends \Magento\Framework\Model\AbstractModel
{

    public function _construct()
    {
        $this->_init('Ced\Exporter\Model\ResourceModel\Category');
    }
}