<?php
/**
 * Created by PhpStorm.
 * User: cedcoss
 * Date: 13/3/18
 * Time: 10:30 AM
 */

namespace Ced\Exporter\Model\Source\ShippingOverrides;

class ShipMethods implements \Magento\Framework\Option\ArrayInterface
{

    /**
     * Return array of options as value-label pairs
     *
     * @return array Format: array(array('value' => '<value>', 'label' => '<label>'), ...)
     */
    public function toOptionArray()
    {
        return [
            [
                'label' => 'Sweden',
                'value' => 'se'
            ],
            [
                'label' => 'Denmark',
                'value' => 'dk'
            ],
            [
                'label' => 'Norway',
                'value' => 'no'
            ],
            [
                'label' => 'Finland',
                'value' => 'fi'
            ]
        ];
    }
}