<?php

/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement (EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @category    Ced
 * @package     Ced_Exporter
 * @author      CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright   Copyright CedCommerce (http://cedcommerce.com/)
 * @license     http://cedcommerce.com/license-agreement.txt
 */


namespace Ced\Exporter\Model\Source\Product;

class FilterId extends \Magento\Eav\Model\Entity\Attribute\Source\AbstractSource
{
    /**
     * @var \Ced\TaobaoImporter\Model\ResourceModel\FiltersData\CollectionFactory
     */
    public $collection;

    public function __construct(
        \Ced\TaobaoImporter\Model\ResourceModel\FiltersData\CollectionFactory $collectionFactory
    ) {
        $this->collection = $collectionFactory;
    }

    /**
     * Retrieve All options
     *
     * @return array
     */
    public function getAllOptions()
    {
        $data = [
            [
                'label' => 'No Profile',
                'value' => ''
            ]
        ];

        /** @var \Ced\TaobaoImporter\Model\ResourceModel\FiltersData\Collection $filters */
        $filters = $this->collection->create()->setOrder('id');
        if ($filters->getSize() > 0) {
            foreach ($filters as $filter) {
                $data[] = [
                    'label' => $filter->getSearchName(),
                    'value' => $filter->getId()
                ];
            }
        }
        return $data;
    }
}