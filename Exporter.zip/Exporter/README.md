# Exporter
+ Docs: https://exporter-sellercenter.readme.io/docs/createproduct
+ API Explorer: https://sellercenter.exporter.com.my/api/index?spm=a2o7i.10605172.0.0.55bba39fDRcmb6

# exporter_profile
+ Remove `profile_categories` and `magento_category` after stable version (Exporter)