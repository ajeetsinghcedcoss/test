<?php


/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement (EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @category    Ced
 * @package     Ced_enterprise
 * @author      CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright   Copyright © 2018 CedCommerce. All rights reserved.
 * @license     EULA http://cedcommerce.com/license-agreement.txt
 */

namespace Ced\Exporter\Ui\Component\Profile\Form\Frieght;

class Options implements \Magento\Framework\Data\OptionSourceInterface
{

    const CLASSES = [
        '0',
        'A',
        'B',
        'C',
        'D',
        'E',
        'F',
        'H',
        'I',
        'J'
    ];


    /**
     * Return array of options as value-label pairs
     *
     * @return array Format: array(array('value' => '<value>', 'label' => '<label>'), ...)
     */
    public function toOptionArray()
    {
        $preparedArray = [];
        foreach (self::CLASSES as $class) {
            $preparedArray[] = [ 'value' => $class,
                'label' => $class
            ];
        }
        return $preparedArray;
    }
}