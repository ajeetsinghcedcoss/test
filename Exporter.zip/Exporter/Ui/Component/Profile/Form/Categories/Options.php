<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement(EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @category  Ced
 * @package   Ced_Exporter
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 */
namespace Ced\Exporter\Ui\Component\Profile\Form\Categories;


use Magento\Framework\Data\OptionSourceInterface;

class Options implements OptionSourceInterface
{
    public $category;

    public $categoryCollectionFactory;

    public function __construct
    (
        \Ced\Exporter\Helper\Category $category,
        \Magento\Catalog\Model\ResourceModel\Category\CollectionFactory $categoryCollectionFactory
    ) {
        $this->category = $category;
        $this->categoryCollectionFactory = $categoryCollectionFactory;
    }

    /**
     * @return array
     */

    public function toOptionArray()
    {
        $preparedArray = [];
        $categories = $this->categoryCollectionFactory->create();
        $categories->addAttributeToSelect('*');
        foreach ($categories as $category) {
            $preparedArray[] = [ 'value' => $category->getId(),
                'label' => $category->getName()
            ];
        }
        return $preparedArray;
    }
}