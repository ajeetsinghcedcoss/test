<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement (EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @category  Ced
 * @package   Ced_Exporter
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE (http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 */

namespace Ced\Exporter\Ui\Component\Listing\Columns\Customer;

use http\Env\Request;
use Magento\Framework\UrlInterface;
use Magento\Framework\View\Element\UiComponent\ContextInterface;
use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Ui\Component\Listing\Columns\Column;

/**
 * Class ProductValidation
 */
class FeedFile extends Column
{
    /**
     * Url path
     */
    const URL_PATH_RESEND = 'exporter/feeds/resend';
    const URL_MEDIA_FEED = 'exporter/feed/';

    /**
     * @var UrlInterface
     */
    public $urlBuilder;
    public $file;
    public $dl;

    /**
     * @param ContextInterface   $context
     * @param UiComponentFactory $uiComponentFactory
     * @param UrlInterface       $urlBuilder
     * @param array              $components
     * @param array              $data
     */
    public function __construct(
        \Magento\Framework\Filesystem\DirectoryList $directoryList,
        \Magento\Framework\Filesystem\Io\File $fileIo,
        ContextInterface $context,
        UiComponentFactory $uiComponentFactory,
        UrlInterface $urlBuilder,
        $components = [],
        $data = []
    ) {
        $this->file = $fileIo;
        $this->dl = $directoryList;
        $this->urlBuilder = $urlBuilder;
        parent::__construct($context, $uiComponentFactory, $components, $data);
    }

    /**
     * @param array $dataSource
     * @return array
     * @throws \Magento\Framework\Exception\FileSystemException
     */
    public function prepareDataSource(array $dataSource)
    {
        if (isset($dataSource['data']['items'])) {
            foreach ($dataSource['data']['items'] as &$item) {
                $name = $this->getData('name');
                $feedFile = $item[$name];
                $item[$name] = [];
                if (isset($item['id'])) {
                    $feedId = $item['feed_id'];
                    if (!empty($this->getFileLink($feedFile, $feedId))) {
                        $item[$name]['download'] = [
                            'href' => $this->getFileLink($feedFile, $feedId),
                            'download' => (isset($feedFile) and !empty($feedFile)) ? basename($feedFile) : '',
                            'label' => __('Download Images'),
                            'class' => 'cedcommerce actions download'
                        ];
                    } else {
                        $item[$name]['download'] = [
                            'href' => 'javascript:void(0)',
                            'download' => (isset($feedFile) and !empty($feedFile)) ? basename($feedFile) : '',
                            'label' => 'X',
                            'class' => 'cedcommerce'
                        ];
                    }




                   /* $fileInfo = $this->file->getPathInfo($csvFile);
                    $fileName = "ced/exporter/" . $fileInfo['basename'];
                    $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
                    $mediaUrl = $objectManager->get('Magento\Store\Model\StoreManagerInterface')->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);
                    $item[$name]['download_csv'] = [
                        'href' => $mediaUrl.$fileName,
                        'download' => (isset($feedFile) and !empty($feedFile)) ? basename($feedFile) : '',
                        'label' => __('Download CSV'),
                        'class' => 'cedcommerce actions download'
                    ];*/

                }
            }
        }
//        echo "<pre>";print_r($dataSource);die();
        return $dataSource;
    }

    public function getFileLink($filePath, $feedId)
    {
        try {
        $url = '';
        if (isset($filePath) and !empty($filePath)) {

            $fileInfo = $this->file->getPathInfo($filePath);
            $fileName = $feedId.$fileInfo['basename'];
            $file = $this->dl->getPath('media') . "/exporter/feed/" . $fileName;
            if ($this->file->fileExists($file)) {
                $url = $this->urlBuilder
                        ->getBaseUrl(['_type' => \Magento\Framework\UrlInterface::URL_TYPE_MEDIA]) .
                    self::URL_MEDIA_FEED . $fileName;
            } else {
                if ($this->file->fileExists($filePath)) {
                    $cpDir = $this->dl->getPath('media') . "/exporter/feed/";
                    if (!$this->file->fileExists($cpDir)) {
                        $this->file->mkdir($cpDir);
                    }
                    $this->file->cp($filePath, $cpDir . $fileName);
                    if ($this->file->fileExists($cpDir . $fileName)) {
                        $url = $this->urlBuilder
                                ->getBaseUrl(['_type' => \Magento\Framework\UrlInterface::URL_TYPE_MEDIA]) .
                            self::URL_MEDIA_FEED . $fileName;
                    }
                }
            }
        }
        //echo $filePath;die();
        if (file_exists($filePath)) {
            if (empty($url) && isset($filePath) and !empty($filePath)) {
                $fileInfo = $this->file->getPathInfo($filePath);
                $fileName = "ced/exporter/" . $fileInfo['basename'];
                $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
                $mediaUrl = $objectManager->get('Magento\Store\Model\StoreManagerInterface')->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);
                $url = $mediaUrl.$fileName;
            }
        }
        }catch (\Exception $e) {
        }
        return $url;
    }
}
