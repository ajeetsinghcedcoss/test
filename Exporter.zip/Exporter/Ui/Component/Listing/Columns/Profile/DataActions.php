<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement (EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @category  Ced
 * @package   Ced_Exporter
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE (http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 */

namespace Ced\Exporter\Ui\Component\Listing\Columns\Profile;

use Magento\Framework\View\Element\UiComponent\ContextInterface;
use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Ui\Component\Listing\Columns\Column;
use Magento\Framework\UrlInterface;

class DataActions extends Column
{
    const URL_PATH_EDIT = 'exporter/profile/edit';
    const URL_PATH_DELETE = 'exporter/profile/massdelete';
    const URL_PATH_UPLOAD = 'exporter/products/index';

    /**
     * URL builder
     *
     * @var \Magento\Framework\UrlInterface
     */
    protected $_urlBuilder;

    /**
     * @param ContextInterface   $context
     * @param UiComponentFactory $uiComponentFactory
     * @param UrlInterface       $urlBuilder
     * @param array              $components
     * @param array              $data
     */
    public function __construct(
        ContextInterface $context,
        UiComponentFactory $uiComponentFactory,
        UrlInterface $urlBuilder,
        array $components = [],
        array $data = []
    ) {
        $this->_urlBuilder = $urlBuilder;
        parent::__construct($context, $uiComponentFactory, $components, $data);
    }

    /**
     * Prepare Data Source
     *
     * @param  array $dataSource
     * @return array
     */
    public function prepareDataSource(array $dataSource)
    {
        if (isset($dataSource['data']['items'])) {
            foreach ($dataSource['data']['items'] as &$item) {
                if (isset($item['id'])) {

                    $item[$this->getData('name')]['edit'] = [
                        'href' => $this->_urlBuilder->getUrl(self::URL_PATH_EDIT, ['id' => $item['id']]),
                        'label' => __('Edit'),
                        'class' => 'cedcommerce actions edit'
                    ];
                    $item[$this->getData('name')]['delete'] = [
                        'href' => $this->_urlBuilder->getUrl(self::URL_PATH_DELETE, ['id' => $item['id']]),
                        'label' => __('Delete'),
                        'class' => 'cedcommerce actions delete'
                    ];

//                    $item[$this->getData('name')] = [
//                        'edit' => [
//                            'href' => $this->_urlBuilder->getUrl(
//                                static::URL_PATH_EDIT,
//                                [
//                                    'id' => $item['id']
//                                ]
//                            ),
//                            'label' => __('Edit')
//                        ]/*,
//                        'delete' => [
//                            'href' => $this->_urlBuilder->getUrl(
//                                static::URL_PATH_UPLOAD,
//                                [
//                                    'profile_id' => $item['id']
//                                ]
//                            ),
//                            'label' => __('Upload Products'),
//                        ]*/
//                    ];
                }
            }
        }
        return $dataSource;
    }
}
