<?php

namespace Ced\Exporter\Ui\Component\Listing\Columns\MassAction;

class Url extends \Magento\Ui\Component\Action
{
    protected $urlBuilder;
    protected $request;

    public function __construct(
        \Magento\Framework\View\Element\UiComponent\ContextInterface $context,
        \Magento\Framework\App\RequestInterface $request,
        \Magento\Framework\UrlInterface $urlBuilder,
        array $components = [],
        array $data = [],
        $actions = null
    ) {
        parent::__construct($context, $components, $data, $actions);

        $this->urlBuilder = $urlBuilder;
        $this->request = $request;
    }

    public function prepare()
    {
        parent::prepare();

        $config = $this->getConfiguration();
        $profileId =  $this->request->getParam('profile_id');
        if ($profileId) {
            $url = explode('key', $config['url']);
            $config['url'] = $url[0] . 'profile_id/' . $profileId . '/key' . $url[1];
        }
        $this->setData('config', $config);
    }
}