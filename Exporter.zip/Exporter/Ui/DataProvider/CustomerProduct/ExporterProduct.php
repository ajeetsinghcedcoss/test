<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement(EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @category  Ced
 * @package   Ced_Exporter
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 */

namespace Ced\Exporter\Ui\DataProvider\CustomerProduct;

use Ced\Exporter\Model\ProfileProduct;
use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory;
use Magento\Framework\Api\FilterBuilder;
use Ced\Exporter\Model\Profile;

/**
 * Class ExporterProduct
 * @package Ced\Exporter\Ui\DataProvider\Product
 */
class ExporterProduct extends \Magento\Ui\DataProvider\AbstractDataProvider
{
    /**
     * @var array
     */
    public $addFieldStrategies;

    /**
     * @var array
     */
    public $addFilterStrategies;

    /**
     * @var FilterBuilder
     */
    public $filterBuilder;

    /**
     * @var Profile
     */
    public $profile;

    public function __construct(
        $name,
        $primaryFieldName,
        $requestFieldName,
        CollectionFactory $collectionFactory,
        FilterBuilder $filterBuilder,
        ProfileProduct $profileProduct,
        Profile $profile,
        \Ced\Exporter\Helper\Config $config,
        \Ced\TaobaoImporter\Model\ResourceModel\InitialProducts\CollectionFactory  $taobaoImporterCollectionFactory,
        \Ced\TaobaoImporter\Model\ResourceModel\Product\CollectionFactory  $taobaoProductCollectionFactory,
        array $addFieldStrategies = [],
        array $addFilterStrategies = [],
        array $meta = [],
        array $data = []
    ) {
        parent::__construct($name, $primaryFieldName, $requestFieldName, $meta, $data);
        $this->filterBuilder = $filterBuilder;
        $this->profile = $profile;
        $this->collection = $collectionFactory->create();
        $this->collection->setStoreId($config->getStore())
            ->joinField(
                'qty',
                'cataloginventory_stock_item',
                'qty',
                'product_id = entity_id',
                '{{table}}.stock_id=1',
                null
            );
        $this->addField('exporter_profile_id');
        $this->addField('exporter_product_status');
        $this->addField('exporter_validation_errors');
        $this->addField('exporter_feed_errors');
        $this->addField('filter_id');

        // Update Attribute
        /* $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
         $resource = $objectManager->get('Magento\Framework\App\ResourceConnection');
         $connection = $resource->getConnection();
         $taobaoProductTable = $resource->getTableName('taobao_importer_product');
         $taobaoImporterSearchProductTable = $resource->getTableName('taobao_importer_search_product');
         $taobaoImporterCollection = $taobaoImporterCollectionFactory->create();
         $taobaoImporterCollection->getSelect()->joinLeft(
             array('select' => $taobaoProductTable ),
             'taobao_product_id = select.taobao_item_id',
             array(
                 'select.product_id'
             )
         );

         $items = $taobaoImporterCollection->getData();
         foreach ($items as $item) {
             if(isset($item['product_id']) && !empty($item['product_id'])) {
                 $product = $objectManager->create('Magento\Catalog\Model\Product')->load($item['product_id']);
                 $product->setData('filter_id',$item['filter_id'])
                     ->getResource()->saveAttribute($product,'filter_id');
             }
         }*/


        // join two table
        /* $this->collection->getSelect()->joinLeft(
             array('tmp' => $taobaoProductTable ),
             'entity_id = tmp.product_id',
             array(
                 'tmp.taobao_item_id'
             )
         );

         $this->collection->getSelect()->joinLeft(
             array('tmp2' => $taobaoImporterSearchProductTable),
             'taobao_item_id = tmp2.taobao_product_id',
             array(
                 'filter_id'
             )
         );*/

        //$profileIds = $this->profile->getCollection()->getAllIds();

        /*$profileId = 1;
        $this->addFilter(
            $this->filterBuilder->setField('exporter_profile_id')->setConditionType('like')
                ->setValue('%'.$profileId.'%')
                ->create()
        );*/

        $this->addFilter(
            $this->filterBuilder->setField('type_id')->setConditionType('in')
                ->setValue(['simple','configurable'])
                ->create()
        );
        /*$this->addFilter(
            $this->filterBuilder->setField('manufacturer')->setConditionType('nin')
                ->setValue($excludedBrands)
                ->create()
        );*/

        $this->addFilter(
            $this->filterBuilder->setField('visibility')->setConditionType('nin')
                ->setValue([1])
                ->create()
        );
        $this->addFieldStrategies = $addFieldStrategies;
        $this->addFilterStrategies = $addFilterStrategies;
    }

    public function addField($field, $alias = null)
    {
        if (isset($this->addFieldStrategies[$field])) {
            $this->addFieldStrategies[$field]->addField($this->getCollection(), $field, $alias);
        } else {
            parent::addField($field, $alias);
        }
    }

    /**
     * @param \Magento\Framework\Api\Filter $filter
     * @return void
     */
    public function addFilter(\Magento\Framework\Api\Filter $filter)
    {

        if (isset($this->addFilterStrategies[$filter->getField()])) {
            $this->addFilterStrategies[$filter->getField()]
                ->addFilter(
                    $this->getCollection(),
                    $filter->getField(),
                    [$filter->getConditionType() => $filter->getValue()]
                );
        } else {
//
            parent::addFilter($filter);
        }
    }

    /**
     * @return array
     */
    public function getData()
    {
        if (!$this->getCollection()->isLoaded()) {
            $this->getCollection()->load();
        }
        $items = $this->getCollection()->toArray();

        return [
            'totalRecords' => $this->getCollection()->getSize(),
            'items' => array_values($items),
        ];
    }
}
