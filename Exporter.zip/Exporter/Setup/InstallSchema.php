<?php

/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement (EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @category  Ced
 * @package   Ced_Exporter
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CedCommerce (http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 */

namespace Ced\Exporter\Setup;

use Magento\Framework\DB\Adapter\AdapterInterface;
use Magento\Framework\DB\Ddl\Table;
use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;

/**
 * Class InstallSchema
 *
 * @package Ced\Exporter\Setup
 */
class InstallSchema implements InstallSchemaInterface
{
    /**
     * @param SchemaSetupInterface   $setup
     * @param ModuleContextInterface $context
     * @throws \Zend_Db_Exception
     */
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;
        $installer->startSetup();

        /**
         * Create table 'exporter_profile'
         */
        $table = $installer->getConnection()->newTable($installer->getTable('exporter_profile'))
            ->addColumn(
                'id',
                Table::TYPE_INTEGER,
                null,
                [
                    'identity' => true,
                    'unsigned' => true,
                    'nullable' => false,
                    'primary' => true
                ],
                'ID'
            )->addColumn(
                'profile_code',
                Table::TYPE_TEXT,
                50,
                [
                    'nullable' => false,
                    'default' => null
                ],
                'Profile Code'
            )
            ->addColumn(
                'profile_status',
                Table::TYPE_INTEGER,
                null,
                [
                    'unsigned' => true,
                    'nullable' => true,
                    'default' => 1
                ],
                'Profile Status'
            )
            ->addColumn(
                'header_restriction',
                Table::TYPE_INTEGER,
                null,
                [
                    'unsigned' => true,
                    'nullable' => true,
                    'default' => 1
                ],
                'Header Restriction'
            )
            ->addColumn(
                'template_id',
                Table::TYPE_INTEGER,
                null,
                [
                    'unsigned' => true,
                    'nullable' => true,
                    'default' => 1
                ],
                'Template Id'
            )
            ->addColumn(
                'profile_name',
                Table::TYPE_TEXT,
                255,
                [
                    'nullable' => false,
                ],
                'Profile Name'
            )
            ->addColumn(
                'profile_category',
                Table::TYPE_TEXT,
                255,
                [
                    'nullable' => true,
                ],
                'Profile Category'
            )
            ->addColumn(
                'product_basic_mappings',
                Table::TYPE_TEXT,
                '1M',
                [
                    'nullable' => true,
                ],
                'Basic Product Information'
            )
            ->addColumn(
                'profile_required_attributes',
                Table::TYPE_TEXT,
                '2M',
                [
                    'nullable' => true
                ],
                'Profile Required Attributes'
            )
            ->addColumn(
                'profile_optional_attributes',
                Table::TYPE_TEXT,
                '2M',
                [
                    'nullable' => true,
                ],
                'Profile Optional Attributes'
            )
            ->addColumn(
                'magento_category',
                Table::TYPE_TEXT,
                200,
                [
                    'nullable' => true,
                ],
                'Magento Category'
            )
            ->addIndex(
                $setup->getIdxName(
                    'exporter_profile',
                    ['profile_code'],
                    AdapterInterface::INDEX_TYPE_UNIQUE
                ),
                ['profile_code'],
                ['type' => AdapterInterface::INDEX_TYPE_UNIQUE]
            )->setComment('Profile Table')->setOption('type', 'InnoDB')->setOption('charset', 'utf8');
        $installer->getConnection()->createTable($table);

        /**
         * Create table 'exporter_profile'
         */
        $table = $installer->getConnection()->newTable($installer->getTable('exporter_profile_products'))
            ->addColumn(
                'id',
                Table::TYPE_INTEGER,
                null,
                ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
                'ID'
            )->addColumn(
                'profile_id',
                Table::TYPE_INTEGER,
                null,
                ['unsigned' => true, 'nullable' => false],
                'Profile Id'
            )->addColumn(
                'product_id',
                Table::TYPE_INTEGER,
                null,
                ['unsigned' => true, 'nullable' => false],
                'Product ID'
            )->addColumn(
                'exporter_item_id',
                Table::TYPE_BIGINT,
                null,
                ['unsigned' => true, 'nullable' => false],
                'Exporter Item ID'
            )
            ->addForeignKey(
                $setup->getFkName('exporter_profile_products', 'profile_id', 'exporter_profile', 'id'),
                'profile_id',
                $setup->getTable('exporter_profile'),
                'id',
                Table::ACTION_CASCADE
            )
            ->addIndex(
                $setup->getIdxName(
                    'exporter_profile_products',
                    ['profile_id', 'product_id'],
                    AdapterInterface::INDEX_TYPE_UNIQUE
                ),
                ['profile_id', 'product_id'],
                ['type' => AdapterInterface::INDEX_TYPE_UNIQUE]
            )
            ->addIndex(
                $setup->getIdxName(
                    'exporter_profile_products',
                    ['product_id'],
                    AdapterInterface::INDEX_TYPE_UNIQUE
                ),
                ['product_id'],
                ['type' => AdapterInterface::INDEX_TYPE_UNIQUE]
            )->setComment('Profile Products Table')->setOption('type', 'InnoDB')->setOption('charset', 'utf8');

        $installer->getConnection()->createTable($table);

        /**
         * exporter_feeds
         */
        $table = $installer->getConnection()->newTable($installer->getTable('exporter_feeds'))
            ->addColumn(
                'id',
                Table::TYPE_INTEGER,
                null,
                [
                    'identity' => true,
                    'unsigned' => true,
                    'nullable' => false,
                    'primary' => true
                ],
                'ID'
            )
            ->addColumn(
                'feed_id',
                Table::TYPE_TEXT,
                '1M',
                [
                    'nullable' => true
                ],
                'Feed Id'
            )
            ->addColumn(
                'type',
                Table::TYPE_TEXT,
                255,
                [
                    'nullable' => true,
                ],
                'Type'
            )
            ->addColumn(
                'feed_response',
                Table::TYPE_TEXT,
                '2M',
                [
                    'nullable' => true,
                ],
                'Operation Type'
            )
            ->addColumn(
                'status',
                Table::TYPE_TEXT,
                20,
                [
                    'nullable' => true
                ],
                'Status'
            )->addColumn(
                'approval_status',
                Table::TYPE_TEXT,
                125,
                [
                    'nullable' => true
                ],
                'Status'
            )
            ->addColumn(
                'feed_file',
                Table::TYPE_TEXT,
                500,
                [
                    'nullable' => true,
                ],
                'Feed File Path'
            )
            ->addColumn(
                'response_file',
                Table::TYPE_TEXT,
                500,
                [
                    'nullable' => true,
                ],
                'Response File Path'
            )

            ->addColumn(
                'feed_created_date',
                Table::TYPE_DATE,
                null,
                [
                    'nullable' => false
                ],
                'Feed Created Date'
            )
            ->addColumn(
                'feed_executed_date',
                Table::TYPE_DATE,
                null,
                [
                    'nullable' => false
                ],

                'Feed Executed Date'
            )
            ->addColumn(
                'product_ids',
                Table::TYPE_TEXT,
                '2M',
                [
                    'nullable' => true
                ],
                'Product IDs'
            )->setComment('Exporter Feeds')->setOption('type', 'InnoDB')->setOption('charset', 'utf8');

        $installer->getConnection()->createTable($table);


        try {
            $tableName = $installer->getTable('exporter_attributemappingtemplate');
            // Check if the table already exists
            if ($setup->getConnection()->isTableExists($tableName) != true) {
                // Create tutorial_simplenews table
                $table = $installer->getConnection()
                    ->newTable($tableName)
                    ->addColumn(
                        'id',
                        \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                        null,
                        [
                            'identity' => true,
                            'unsigned' => true,
                            'nullable' => false,
                            'primary' => true
                        ],
                        'ID'
                    )
                    ->addColumn(
                        'template_code',
                        \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                        null,
                        ['unsigned' => true, 'nullable' => false],
                        'Template Code'
                    )
                    ->addColumn(
                        'template_name',
                        \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                        null,
                        ['unsigned' => true, 'nullable' => false],
                        'Template Name'
                    )->addColumn(
                        'template_file',
                        \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                        null,
                        ['unsigned' => true, 'nullable' => false],
                        'Template file'
                    )
                    ->addColumn(
                        'required_attributes',
                        \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                        null,
                        ['unsigned' => true, 'nullable' => false],
                        'Required Attributes'
                    )
                    ->addColumn(
                        'optional_attributes',
                        \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                        null,
                        ['unsigned' => true, 'nullable' => false],
                        'Optional Attributes'
                    )
                    ->setComment('Exporter Attribute Template')
                    ->setOption('type', 'InnoDB')
                    ->setOption('charset', 'utf8');
                $installer->getConnection()->createTable($table);
            }

        } catch (\Exception $e) {
            print_r($e->getMessage());
            // die;

        }
    }
}
