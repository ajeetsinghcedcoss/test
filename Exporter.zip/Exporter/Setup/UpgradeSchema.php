<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement(EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @category  Ced
 * @package   Ced_Exporter
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 */

namespace Ced\Exporter\Setup;

use Magento\Framework\Setup\UpgradeSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\DB\Ddl\Table;
use Magento\Framework\DB\Adapter\AdapterInterface;

class UpgradeSchema implements UpgradeSchemaInterface
{
    /**
     * @param SchemaSetupInterface $setup
     * @param ModuleContextInterface $context
     * @throws \Zend_Db_Exception
     */

    public function upgrade(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();
        if (version_compare($context->getVersion(), '0.0.8', '<')) {
            // Get module table
            $tableName = $setup->getTable('exporter_product_change');
            if ($setup->getConnection()->isTableExists($tableName)) {
                $setup->getConnection()->dropTable($tableName);
            }
            // Check if the table already exists
            if (!$setup->getConnection()->isTableExists($tableName)) {
                $table = $setup->getConnection()
                    ->newTable($tableName)
                    ->addColumn(
                        'id',
                        Table::TYPE_INTEGER,
                        null,
                        [
                            'identity' => true,
                            'unsigned' => true,
                            'nullable' => false,
                            'primary' => true
                        ],
                        'ID'
                    )
                    ->addColumn(
                        'product_id',
                        Table::TYPE_INTEGER,
                        null,
                        [
                            'unsigned' => true,
                            'nullable' => false
                        ],
                        'Product Id'
                    )
                    ->addColumn(
                        'action',
                        Table::TYPE_TEXT,
                        50,
                        ['nullable' => true, 'default' => ''],
                        'Action'
                    )
                    ->addColumn(
                        'status',
                        Table::TYPE_TEXT,
                        50,
                        ['nullable' => true, 'default' => ''],
                        'Status'
                    )->addColumn(
                        'type',
                        Table::TYPE_TEXT,
                        50,
                        ['nullable' => true, 'default' => ''],
                        'Type'
                    )->addColumn(
                        'product_type',
                        Table::TYPE_TEXT,
                        50,
                        ['nullable' => true, 'default' => ''],
                        'Product Type'
                    )->addColumn(
                        'product_data',
                        Table::TYPE_TEXT,
                        null,
                        ['nullable' => true, 'default' => ''],
                        'Product Data'
                    )
                    ->setComment('Exporter Product Change')
                    ->setOption('type', 'InnoDB')
                    ->setOption('charset', 'utf8');
                $setup->getConnection()->createTable($table);
            }

            $tableName = $setup->getTable('exporter_profile');
            $connection = $setup->getConnection();

            if (!$connection->tableColumnExists($tableName, 'profile_products_filters')) {
                $connection->addColumn(
                    $tableName,
                    'profile_products_filters',
                    [
                        'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                        'nullable' => true,
                        'comment' => 'Products Filters',
                        'after' => 'profile_optional_attributes'
                    ]
                );
            }

            $tableName = $setup->getTable('exporter_product_change');
            $connection = $setup->getConnection();

            if (!$connection->tableColumnExists($tableName, 'profile_id')) {
                $connection->addColumn(
                    $tableName,
                    'profile_id',
                    [
                        'type' => \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                        'nullable' => true,
                        'comment' => 'Profile Id',
                        'after' => 'product_id'
                    ]
                );
            }

            // Check if the table already exists
            if ($setup->getConnection()->isTableExists($setup->getTable('ced_logs')) != true) {
                // Create ced_logs table
                $table = $setup->getConnection()
                    ->newTable($setup->getTable('ced_logs'))
                    ->addColumn(
                        'id',
                        Table::TYPE_INTEGER,
                        null,
                        [
                            'identity' => true,
                            'unsigned' => true,
                            'nullable' => false,
                            'primary' => true
                        ],
                        'ID'
                    )
                    ->addColumn(
                        'message',
                        Table::TYPE_TEXT,
                        null,
                        [
                            'nullable' => true
                        ],
                        'Message'
                    )
                    ->addColumn(
                        'context',
                        Table::TYPE_TEXT,
                        '2M',
                        [
                            'nullable' => true
                        ],
                        'Context'
                    )
                    ->addColumn(
                        'level',
                        Table::TYPE_TEXT,
                        null,
                        [
                            'nullable' => true
                        ],
                        'Level'
                    )
                    ->addColumn(
                        'level_name',
                        Table::TYPE_TEXT,
                        null,
                        [
                            'nullable' => true
                        ],
                        'Level Name'
                    )
                    ->addColumn(
                        'channel',
                        Table::TYPE_TEXT,
                        null,
                        [
                            'nullable' => true
                        ],
                        'Channel'
                    )
                    ->addColumn(
                        'datetime',
                        Table::TYPE_DATETIME,
                        null,
                        [
                            'nullable' => true
                        ],
                        'Date'
                    )
                    ->setComment('Cedcommerce Logs');
                $setup->getConnection()->createTable($table);
            }
            $setup->endSetup();
        }
        if (version_compare($context->getVersion(), '0.0.9', '<')) {
            $setup->startSetup();

            // Check if the table already exists
            /*if ($setup->getConnection()->isTableExists($setup->getTable('ced_customer')) != true) {
                // Create ced_logs table
                $table = $setup->getConnection()
                    ->newTable($setup->getTable('ced_customer'))
                    ->addColumn(
                        'id',
                        Table::TYPE_INTEGER,
                        null,
                        [
                            'identity' => true,
                            'unsigned' => true,
                            'nullable' => false,
                            'primary' => true
                        ],
                        'ID'
                    )
                    ->addColumn(
                        'customer_id',
                        \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                        null,
                        ['identity' => false, 'unsigned' => true, 'nullable' => false, 'primary' => false],
                        'Customer Id'
                    )
                    ->addColumn(
                        'product_id',
                        Table::TYPE_TEXT,
                        null,
                        [
                            'nullable' => true
                        ],
                        'Product Id'
                    )
                    ->addColumn(
                        'datetime',
                        Table::TYPE_DATETIME,
                        null,
                        [
                            'nullable' => true
                        ],
                        'Date'
                    )
                    ->addForeignKey(
                        $setup->getFkName('ced_customer', 'customer_id', 'customer_entity', 'entity_id'),
                        'customer_id',
                        $setup->getTable('customer_entity'),
                        'entity_id',
                        \Magento\Framework\DB\Ddl\Table::ACTION_CASCADE
                    )
                    ->addIndex(
                        $setup->getIdxName(
                            'ced_customer',
                            ['customer_id'],
                            AdapterInterface::INDEX_TYPE_INDEX
                        ),
                        ['customer_id'],
                        ['type' => AdapterInterface::INDEX_TYPE_INDEX]
                    )
                    ->setComment('Ced Custom Customer');
                $setup->getConnection()->createTable($table);
            }*/
            $tableName = $setup->getTable('exporter_feeds');
            $connection = $setup->getConnection();

            if (!$connection->tableColumnExists($tableName, 'customer_id')) {
                $connection->addColumn(
                    $tableName,
                    'customer_id',
                    [
                        'type' => \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                        'identity' => false,
                        'unsigned' => true,
                        'nullable' => false,
                        'primary' => false,
                        'after' => 'product_ids',
                        'comment' => 'Customer Id',
                    ]
                );
            }

            $tableName = $setup->getTable('exporter_product_change');
            $connection = $setup->getConnection();

            if (!$connection->tableColumnExists($tableName, 'customer_id')) {
                $connection->addColumn(
                    $tableName,
                    'customer_id',
                    [
                        'type' => \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                        'identity' => false,
                        'unsigned' => true,
                        'nullable' => false,
                        'primary' => false,
                        'after' => 'product_id',
                        'comment' => 'Customer Id',
                    ]
                );
            }

            $setup->endSetup();
        }
    }
}